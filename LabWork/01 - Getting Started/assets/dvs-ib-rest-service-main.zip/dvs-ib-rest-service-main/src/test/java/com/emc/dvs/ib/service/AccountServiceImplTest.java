package com.emc.dvs.ib.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class AccountServiceImplTest {
	
	private String accountBaseUri;
	
	private String siteSearch;
    @Mock
    private RestTemplate restTemplate;

    private AccountServiceImpl accountService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        accountService = new AccountServiceImpl(restTemplate);
    }

    @Test
    public void testGetSiteDetailsValidResponse() {
        // Mocked response
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> content = new HashMap<>();
        List<Object> siteList = new ArrayList<>();
        siteList.add("Site1");
        siteList.add("Site2");
        content.put("SiteList", siteList);
        response.put("content", content);

        ResponseEntity<Map> mockResponseEntity = ResponseEntity.ok(response);

        // Mocking the RestTemplate behavior
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
                .thenReturn(mockResponseEntity);

        List<Object> sites = accountService.getSiteDetails("Site123", "User123");

        // Assertions
        // Verify that the method returned the expected list of sites
        assertEquals(2, sites.size());
    }

    @Test
    public void testGetSiteDetailsInvalidResponse() {
        // Mocked response with valid data
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> content = new HashMap<>();
        List<Object> siteList = new ArrayList<>();
        siteList.add("Site1");
        siteList.add("Site2");
        content.put("SiteList", siteList);
        response.put("content", content);

        ResponseEntity<Map> mockResponseEntity = ResponseEntity.ok(response);

        // Mocking the RestTemplate behavior
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
                .thenReturn(mockResponseEntity);

        List<Object> sites = accountService.getSiteDetails("Site123", "User123");

        // Assertions
        // Verify that the method returned a list with the expected size
        assertEquals(2, sites.size());
    }
    @Test
    void testGetSiteDetails() {
        // Mocking the dependencies

        // Create the input and expected output
        String siteNumber = "123";
        String uid = "user_id";

        Map<String, Object> response = new HashMap<>();
        response.put("content", Collections.singletonMap("SiteList", Arrays.asList("site1", "site2")));

        ResponseEntity<Map> webSupportResponse = new ResponseEntity<>(response, HttpStatus.OK);

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(Map.class)))
                .thenReturn(webSupportResponse);

        // Test 1: When 'response' map has content
        List<Object> siteDetails = accountService.getSiteDetails(siteNumber, uid);

        assertNotNull(siteDetails);
        assertEquals(2, siteDetails.size());
        assertTrue(siteDetails.contains("site1"));
        assertTrue(siteDetails.contains("site2"));

        // Test 2: When 'response' map doesn't have content
        response.put("content", null);
        webSupportResponse = new ResponseEntity<>(response, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(Map.class)))
                .thenReturn(webSupportResponse);

        List<Object> emptySiteDetails = accountService.getSiteDetails(siteNumber, uid);

        assertNotNull(emptySiteDetails);
        assertEquals(0, emptySiteDetails.size());
        // Write assertions based on your code logic to validate the return value
    }
}
