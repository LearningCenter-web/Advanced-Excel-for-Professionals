package com.emc.dvs.ib.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AdvisoriesExceptionTests {

    @Test
    public void testExceptionWithMessage() {
        // Arrange
        String errorMessage = "Advisories Exception Message";

        // Act
        AdvisoriesException exception = new AdvisoriesException(errorMessage);

        // Assert
        assertEquals(errorMessage, exception.getMessage());
    }

    @Test
    public void testExceptionWithMessageAndCause() {
        // Arrange
        String errorMessage = "Advisories Exception Message";
        Throwable cause = new RuntimeException("Root cause");

        // Act
        AdvisoriesException exception = new AdvisoriesException(errorMessage, cause);

        // Assert
        assertEquals(errorMessage, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}

