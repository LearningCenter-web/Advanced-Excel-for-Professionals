package com.emc.dvs.ib.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public class AccessExceptionTests {

    @Test
    public void testException() {
        // Act
        AccessException exception = new AccessException();

        // Assert
        ResponseStatus responseStatus = AccessException.class.getAnnotation(ResponseStatus.class);
        assertEquals(HttpStatus.FORBIDDEN, responseStatus.value());
        assertEquals("access denied", responseStatus.reason());
    }
}

