package com.emc.dvs.ib.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class PersistenceExceptionTests {

    @Test
    public void testExceptionWithMessage() {
        // Arrange
        String errorMessage = "Persistence Exception Message";

        // Act
        PersistenceException exception = new PersistenceException(errorMessage);

        // Assert
        assertEquals(errorMessage, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testExceptionWithMessageAndCause() {
        // Arrange
        String errorMessage = "Persistence Exception Message";
        Throwable cause = new RuntimeException("Root cause");

        // Act
        PersistenceException exception = new PersistenceException(errorMessage, cause);

        // Assert
        assertEquals(errorMessage, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}

