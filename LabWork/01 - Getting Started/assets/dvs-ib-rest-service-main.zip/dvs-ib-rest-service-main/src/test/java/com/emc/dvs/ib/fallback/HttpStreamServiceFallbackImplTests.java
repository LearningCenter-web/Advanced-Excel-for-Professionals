package com.emc.dvs.ib.fallback;

import java.util.HashMap;
import java.util.Map;
 
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
 
public class HttpStreamServiceFallbackImplTests {
 
    @InjectMocks
    private HttpStreamServiceFallbackImpl httpStreamServiceFallback;
 
    @Mock
    private Throwable cause;
 
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
 
    @Test
    public void testUpdateProductAlias() {
        Map<String, Object> body = new HashMap<>();
        body.put("serialNumber", "12345");
 
        httpStreamServiceFallback.updateProductAlias(body);
 
        // Verify that the log.info and log.error methods are called
        Mockito.verify(cause, Mockito.times(1)).getMessage();
    }
 
    @Test
    public void testSiteChangeEvent() {
        Map<String, Object> body = new HashMap<>();
        body.put("serialNumber", "54321");
 
        httpStreamServiceFallback.siteChangeEvent(body);
 
        // Verify that the log.info and log.error methods are called
        Mockito.verify(cause, Mockito.times(1)).getMessage();
    }
 
    @Test
    public void testProductChangeEvent() {
        Map<String, Object> body = new HashMap<>();
        body.put("serialNumber", "98765");
 
        httpStreamServiceFallback.productChangeEvent(body);
 
        // Verify that the log.info and log.error methods are called
        Mockito.verify(cause, Mockito.times(1)).getMessage();
    }
 
    @Test
    public void testRenewContract() {
        Map<String, Object> body = new HashMap<>();
        body.put("serialNumber", "45678");
 
        httpStreamServiceFallback.renewContract(body);
 
        // Verify that the log.info and log.error methods are called
        Mockito.verify(cause, Mockito.times(1)).getMessage();
    }
}
