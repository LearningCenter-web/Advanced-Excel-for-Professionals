package com.emc.dvs.ib.web;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsAggregateResponseBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractCategoryResponseBean;
import com.emc.dvs.ib.domain.ContractInventoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.Entitlement;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.MilestoneStatsBean;
import com.emc.dvs.ib.domain.PagedResponseBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.domain.WarrantyResponse;
import com.emc.dvs.ib.service.InstallBaseService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class InstallBaseControllerTests {

	@InjectMocks
	private InstallBaseController controller;

	@Mock
	private InstallBaseService installBaseService;
	
	@Mock
	private HttpServletRequest request;
	
	private MockMvc mockMvc;
	
	@Mock
	private ObjectMapper mapper; 
	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
		controller.setCpsdFilter(true);
		LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel(Logger.ROOT_LOGGER_NAME, LogLevel.TRACE);
		
	}

	@Test
	public void testGetSerialNumbersForSites() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		
		InstallBaseFilterValuesBean bean = new InstallBaseFilterValuesBean();
		List<String> ibStatus = new ArrayList<String>();
		ibStatus.add("ibStatus");
		bean.setIbStatus(ibStatus);
		
		List<String> productName = new ArrayList<String>();
		List<String> contractStatus = new ArrayList<String>();
		List<String> servicePlanLevels = new ArrayList<>();
 		productName.add("productName");
		contractStatus.add("contractStatus");
		servicePlanLevels.add("servicePlan1");
		servicePlanLevels.add("servicePlan2");
		
		bean.setServicePlanLevel(servicePlanLevels);
		
		when(installBaseService.getInstallBaseFilterValues(filterParams)).thenReturn(new AsyncResult<InstallBaseFilterValuesBean>(bean));
		when(installBaseService.getProductNames(filterParams)).thenReturn(new AsyncResult<List<String>>(productName));
		when(installBaseService.getContractStatus(filterParams)).thenReturn(new AsyncResult<List<String>>(contractStatus));
		
		this.mockMvc.perform(post("/filters")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"ibStatus\":[\"ibStatus\"]")))
				.andExpect(content().string(containsString("\"productName\":[\"productName\"]")))
				.andExpect(content().string(containsString("\"contractStatus\":[\"contractStatus\"]")))
				.andExpect(content().string(containsString("\"servicePlanLevel\":[\"servicePlan1\",\"servicePlan2\"]")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getInstallBaseFilterValues(filterParams);
		verify(installBaseService, times(1)).getProductNames(filterParams);
		verify(installBaseService, times(1)).getContractStatus(filterParams);
	}
//	@Test
//    public void testDownloadCodeLevelProducts() throws Exception {
//        // Arrange
//        Map<String, Object> filterParams = new HashMap<>();
//        HttpServletRequest request = new MockHttpServletRequest();
//        HttpServletResponse response = new MockHttpServletResponse();
//        filterParams.put("columns", "your_column_data_here");
//
//        // Mock the behavior of installBaseService.getCodeLevelsProducts
//        OutputStream outputStream = response.getOutputStream();
//        Mockito.doNothing().when(installBaseService).getCodeLevelsProducts(outputStream, filterParams, yourColumnData);
//
//        // Act
//        controller.downloadCodeLevelProducts(filterParams, request, response);
//
//        // Assert
//        assertEquals("attachment;filename=CodeLevelProducts_Export.csv", response.getHeader("Content-disposition"));
//        assertEquals("txt/csv", response.getContentType());
//        // You can add further assertions if needed
//    }
	
	
//	@Test
//    public void testDownloadConnectivityList() throws Exception {
//        Map<String, Object> filterParams = new HashMap<>();
//        filterParams.put("siteNumberIsIn", "1234|5678");
//        filterParams.put("cpsdFilter", "false");
// 
//        List<String> serialNumbers = new ArrayList<>();
//        serialNumbers.add("serialNumber");
// 
//        when(installBaseService.getSerialNumbers(filterParams)).thenReturn(serialNumbers);
// 
//        mockMvc.perform(post("/filters/serialnumber")
//                .param("siteNumberIsIn", "1234|5678"))
//                .andExpect(status().isOk())
//                .andExpect(content().string(containsString("\"serialNumber\"")))
//                .andDo(print());
// 
//        verify(installBaseService, times(1)).getSerialNumbers(filterParams);
//    }
	
	
	@Test
	public void testGetSerialFilterValues() throws Exception{
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		
		List<String> serialNumber = new ArrayList<String>();
		serialNumber.add("serialNumber");
		
		when(installBaseService.getSerialNumbers(filterParams)).thenReturn(serialNumber);
		
		this.mockMvc.perform(post("/filters/serialnumber")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"serialNumber\"")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getSerialNumbers(filterParams);
		
	}
	
	@Test
	public void testGetInstanceFilterValues() throws Exception{
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		
		List<String> instanceNumber = new ArrayList<String>();
		instanceNumber.add("instanceNumber");
		
		when(installBaseService.getInstanceIds(filterParams)).thenReturn(instanceNumber);
		
		this.mockMvc.perform(post("/filters/instancenumber")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"instanceNumber\"")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getInstanceIds(filterParams);
		
	}
	
	@Test
	public void testGetInstallBase() throws Exception {
		// Test the @RequestMapping URL and check the @PathVariable is passed to
		// the service

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		
		InstallBaseStatsBean stats = new InstallBaseStatsBean();
		stats.setConnected(19);
		stats.setConnectedPercent(19);
		stats.setTotal(100);
		stats.setExpired(15);
		stats.setNotConnectedEligible(10);
		when(installBaseService.getInstallBaseStats(filterParams))
				.thenReturn(new AsyncResult<InstallBaseStatsBean>(stats));

		List<InstallBaseGeoBean> geos = new ArrayList<InstallBaseGeoBean>();
		InstallBaseGeoBean geo = new InstallBaseGeoBean();
		geo.setLatitude("100.00");
		geo.setLongitude("50.00");
		geo.setProductCount(25);
		geo.setSiteName("siteName");
		geo.setSiteNumber("siteNumber");
		geo.setCity("Cork");
		geos.add(geo);
		when(installBaseService.getInstallBaseGeoDetails(filterParams))
				.thenReturn(new AsyncResult<List<InstallBaseGeoBean>>(geos));

		this.mockMvc.perform(post("/").param("siteNumberIsIn", "1234|5678")).andExpect(status().isOk())
				.andExpect(content().string(containsString(
						"\"stats\":{\"total\":100,\"connected\":19,\"notConnectedEligible\":10,\"connectedPercent\":19,\"expired\":15,\"partsReplacement\":0")))
				.andExpect(content().string(containsString(
						"\"geo\":[{\"siteNumber\":\"siteNumber\",\"siteName\":\"siteName\",\"latitude\":\"100.00\",\"longitude\":\"50.00\",\"city\":\"Cork\",\"productCount\":25}]")))
				.andDo(print());

		verify(installBaseService, times(1)).getInstallBaseStats(filterParams);
		verify(installBaseService, times(1)).getInstallBaseGeoDetails(filterParams);

	}
	
	@Test
	public void testGetConnectivityAggregate() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("connectivity", "true");
		filterParams.put("cpsdFilter", "false");
		
		InstallBaseStatsBean stats = new InstallBaseStatsBean();
		stats.setConnected(19);
		stats.setConnectedPercent(19);
		stats.setTotal(100);
		stats.setExpired(15);
		stats.setNotConnectedEligible(10);
		when(installBaseService.getInstallBaseStats(filterParams)).thenReturn(new AsyncResult<InstallBaseStatsBean>(stats));
		
		Map<String, Object> aggMap = new HashMap<String, Object>();
		aggMap.put("connected", new HashMap<String, Object>());
		aggMap.put("notConnected", new HashMap<String, Object>());
		when(installBaseService.getConnectivityAggregate(filterParams)).thenReturn(new AsyncResult<Map<String, Object>>(aggMap));
		
		this.mockMvc.perform(post("/connectivity/aggregate")
				.param("siteNumberIsIn", "1234|5678"))
		.andExpect(status().isOk())
		.andExpect(content().string(containsString(
				"\"stats\":{\"total\":100,\"connected\":19,\"notConnectedEligible\":10,\"connectedPercent\":19,\"expired\":15,\"partsReplacement\":0")))
		.andExpect(content().string(containsString("\"aggMap\":")))
		.andExpect(content().string(containsString("\"connected\":")))
		.andExpect(content().string(containsString("\"notConnected\":")))
		.andDo(print());
		
		verify(installBaseService, times(1)).getConnectivityAggregate(filterParams);
		verify(installBaseService, times(1)).getInstallBaseStats(filterParams);
	}
	
	@Test
	public void testGetConnectivityListPost() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 1000);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "siteDisplayName");
		filterParams.put("sortDir", "desc");
		filterParams.put("connectivity", "true");
		filterParams.put("cpsdFilter", "false");

		List<ConnectivityProductBean> list = new ArrayList<ConnectivityProductBean>();
		ConnectivityProductBean p1 = new ConnectivityProductBean();
		p1.setConnectFlag("Connected");
		p1.setSerialNumber("2FA0752003");
		p1.setProductFamily("DATADOMAIN");
		p1.setProductName("DD860 Appliance");
		p1.setSiteDisplayName("7667883, JP MORGAN CHASE");
		p1.setConnectionType("M&A CONNECTION");
		p1.setLastConnectHome("2015-08-11 16:48:15");
		p1.setInstanceNumber("123456");
		list.add(p1);
		
		when(installBaseService.getConnectivityList(filterParams)).thenReturn(new AsyncResult<List<ConnectivityProductBean>>(list));
		when(installBaseService.getConnectivityTotalRecord(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		this.mockMvc.perform(post("/connectivity")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "1000")
				.param("number", "1"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":1000")))
				.andExpect(content().string(containsString("\"totalElements\":100000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":101")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andExpect(content().string(containsString(
						"\"serialNumber\":\"2FA0752003\",\"productName\":\"DD860 Appliance\",\"productFamily\":\"DATADOMAIN\",\"siteDisplayName\":\"7667883, JP MORGAN CHASE\",\"connectionType\":\"M&A CONNECTION\",\"lastConnectHome\":\"2015-08-11 16:48:15\",\"connectFlag\":\"Connected\",\"instanceNumber\":\"123456\"")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getConnectivityList(filterParams);
			verify(installBaseService, times(1)).getConnectivityTotalRecord(filterParams);
	}
	@Test
	public void testGetConnectivityList() throws Exception {
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("siteNumberIsIn", "1234|5678");
	    filterParams.put("size", 200); // Size of 200 as per the default
	    filterParams.put("number", 0); // Number 0 as per the default
	    filterParams.put("sortBy", "siteDisplayName");
	    filterParams.put("sortDir", "desc");
	    filterParams.put("connectivity", "true");
	    filterParams.put("cpsdFilter", "false");
 
	    List<ConnectivityProductBean> connectivityList = new ArrayList<>();
	    // Add ConnectivityProductBean objects to the list
 
	    when(installBaseService.getConnectivityTotalRecord(filterParams)).thenReturn(CompletableFuture.completedFuture(connectivityList.size()));
	    when(installBaseService.getConnectivityList(filterParams)).thenReturn(CompletableFuture.completedFuture(connectivityList));
 
	    mockMvc.perform(post("/connectivity")
	            .param("siteNumberIsIn", "1234|5678")
	            .param("number", "0")) // Additional parameters as needed
	            .andExpect(status().isOk())
	            .andExpect(content().string(containsString("\"page\":")))
	            .andExpect(content().string(containsString("\"size\":200"))) // Ensure the default size is used
	            .andExpect(content().string(containsString("\"totalElements\":" + connectivityList.size())))
	            .andExpect(content().string(containsString("\"number\":0"))) // Ensure the default number is used
	            .andExpect(content().string(containsString("\"totalPages\":1"))) // Total pages should be 1 with the default size
	            .andExpect(content().string(containsString("\"rows\":")))
	            .andDo(print());
 
	    verify(installBaseService, times(1)).getConnectivityTotalRecord(filterParams);
	    verify(installBaseService, times(1)).getConnectivityList(filterParams);
	}
	@Test
	public void testGetCodeLevelsProducts() throws IOException {
	    // Arrange
	    Map<String, Object> filterParams = new HashMap<>();
	    List<Column> columns = mock(List.class);

	    // Create a sample list of data that you expect to be returned by the mapper
	    List<Map<String, Object>> sampleData = new ArrayList<>();
	}
	@Test
	public void testDownloadConnectivityListWithCpsdFilterTrue() throws Exception {
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("siteNumberIsIn", "1234|5678");

	    // Mock the behavior of installBaseService with appropriate expectations
	    // For example, return a different list of serial numbers

	    mockMvc.perform(post("/filters/serialnumber")
	            .param("siteNumberIsIn", "1234|5678"))
	            .andExpect(status().isOk())
	            // Assert the response content based on your expectations
	            .andDo(print());
	    
	}
	@Test
	public void testDownloadConnectivityListWithCustomColumns() throws Exception {
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("siteNumberIsIn", "1234|5678");
	    filterParams.put("columns", "custom_columns_data_here");

	    // Mock the behavior of installBaseService with appropriate expectations
	    // For example, return a different list of serial numbers

	    mockMvc.perform(post("/filters/serialnumber")
	            .param("siteNumberIsIn", "1234|5678")
	            .param("columns", "custom_columns_data_here"))
	            .andExpect(status().isOk())
	            // Assert the response content based on your expectations
	            .andDo(print());
	}

	@Test
	public void testGetCodeLevelProductsForSites1() throws Exception {
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("siteNumberIsIn", "1234|5678");
	    filterParams.put("size", 5000); // Size of 5000 as per the default
	    filterParams.put("number", 0); // Number 0 as per the default
	    filterParams.put("sortBy", "siteDisplayName");
	    filterParams.put("sortDir", "desc");
	    filterParams.put("cpsdFilter", "false");
 
	    List<CodeLevelsProductBean> codeLevels = new ArrayList<>();
	    // Add CodeLevelsProductBean objects to the list
 
	    when(installBaseService.getCodeLevelsTotalRecord(filterParams)).thenReturn(CompletableFuture.completedFuture(codeLevels.size()));
	    when(installBaseService.getCodeLevelsProducts(filterParams)).thenReturn(CompletableFuture.completedFuture(codeLevels));
 
	    mockMvc.perform(post("/codelevels")
	            .param("siteNumberIsIn", "1234|5678")
	            .param("number", "0")) // Additional parameters as needed
	            .andExpect(status().isOk())
	            .andExpect(content().string(containsString("\"page\":")))
	            .andExpect(content().string(containsString("\"size\":5000"))) // Ensure the default size is used
	            .andExpect(content().string(containsString("\"totalElements\":" + codeLevels.size())))
	            .andExpect(content().string(containsString("\"number\":0"))) // Ensure the default number is used
	            .andExpect(content().string(containsString("\"totalPages\":1"))) // Total pages should be 1 with the default size
	            .andExpect(content().string(containsString("\"rows\":")))
	            .andDo(print());
 
	    verify(installBaseService, times(1)).getCodeLevelsTotalRecord(filterParams);
	    verify(installBaseService, times(1)).getCodeLevelsProducts(filterParams);
	}
	

	@Test
	public void testGetCodeLevelProductsForSites() throws Exception {
		// Test the @RequestMapping URL and check the @PathVariable is passed to the service
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", "5000");
		filterParams.put("number", "1");

		List<CodeLevelsProductBean> table = new ArrayList<CodeLevelsProductBean>();
		CodeLevelsProductBean p1 = new CodeLevelsProductBean();
		p1.setSerialNumber("1030093184");
		table.add(p1);
		when(installBaseService.getCodeLevelsProducts(filterParams)).thenReturn(new AsyncResult<List<CodeLevelsProductBean>>(table));
		when(installBaseService.getCodeLevelsTotalRecord(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		PagedResponseBean<CodeLevelsProductBean> response = controller.getCodeLevelProductsForSites(filterParams, request);
		assertEquals(100000,response.getPage().getTotalElements());
		assertEquals(5000,response.getPage().getSize());
		assertEquals(1,response.getPage().getNumber());
		assertEquals(21,response.getPage().getTotalPages());
		assertEquals("1030093184",response.getRows().get(0).getSerialNumber());

		verify(installBaseService, times(1)).getCodeLevelsProducts(filterParams);
		verify(installBaseService, times(1)).getCodeLevelsTotalRecord(filterParams);
	}

	@Test
	public void testGetCodeLevelProductsForSitesPost() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 1000);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "siteDisplayName");
		filterParams.put("sortDir", "desc");
		filterParams.put("cpsdFilter", "false");

		List<CodeLevelsProductBean> table = new ArrayList<CodeLevelsProductBean>();
		
		CodeLevelsProductBean codeLevelsProductBean = new CodeLevelsProductBean();
		codeLevelsProductBean.setInstanceNumber("2466783");
		table.add(codeLevelsProductBean);
		
		when(installBaseService.getCodeLevelsProducts(filterParams)).thenReturn(new AsyncResult<List<CodeLevelsProductBean>>(table));
		when(installBaseService.getCodeLevelsTotalRecord(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		this.mockMvc.perform(post("/codelevels")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "1000")
				.param("number", "1"))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":1000")))
				.andExpect(content().string(containsString("\"totalElements\":100000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":101")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andExpect(content().string(containsString("\"instanceNumber\":\"2466783\"")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getCodeLevelsProducts(filterParams);
			verify(installBaseService, times(1)).getCodeLevelsTotalRecord(filterParams);
	}
	
	@Test
	public void testGetCodeLevelsAggregateForSitesPost() throws Exception{
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		
		List<CodeLevelsAggBean> agg = new ArrayList<CodeLevelsAggBean>();
		CodeLevelsAggBean agg1 = new CodeLevelsAggBean();
		agg1.setCategory("CodeCat1");
		agg1.setCodeReleases(1);
		agg1.setProductFamily("ProductFamily1");
		agg1.setSystems(1);
		agg.add(agg1);
		when(installBaseService.getCodeLevelsAggregate((filterParams))).thenReturn(agg);
		

		this.mockMvc.perform(post("/codelevels/aggregate")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())				
				.andExpect(content().string("{\"total\":1,\"categories\":{\"CodeCat1\":{\"totalSystems\":1,\"productFamilies\":[{\"familyName\":\"ProductFamily1\",\"totalSystems\":1,\"codeReleases\":1}]}}}"))				
				.andDo(print());
				
			verify(installBaseService, times(1)).getCodeLevelsAggregate(filterParams);
	}
	
	@Test
	public void testGetCodeLevelsAggregateForSites() throws Exception{
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		
		List<CodeLevelsAggBean> agg = new ArrayList<CodeLevelsAggBean>();
		CodeLevelsAggBean agg1 = new CodeLevelsAggBean();
		agg1.setCategory("CodeCat1");
		agg1.setCodeReleases(1);
		agg1.setProductFamily("ProductFamily1");
		agg1.setSystems(1);
		agg.add(agg1);
		CodeLevelsAggBean agg2 = new CodeLevelsAggBean();
		agg2.setCategory("CodeCat1");
		agg2.setCodeReleases(2);
		agg2.setProductFamily("ProductFamily2");
		agg2.setSystems(5);
		agg.add(agg2);
		CodeLevelsAggBean agg3 = new CodeLevelsAggBean();
		agg3.setCategory("CodeCat2");
		agg3.setCodeReleases(1);
		agg3.setProductFamily("ProductFamily1");
		agg3.setSystems(10);
		agg.add(agg3);
		when(installBaseService.getCodeLevelsAggregate((filterParams))).thenReturn(agg);
		
		CodeLevelsAggregateResponseBean response = controller.getCodeLevelsAggregateForSites(filterParams, request);
		
		
		verify(installBaseService, times(1)).getCodeLevelsAggregate(filterParams);
		assertEquals(16, response.getTotal());
		assertEquals(2, response.getCategories().keySet().size());
		assertEquals(6, response.getCategories().get("CodeCat1").getTotalSystems());
		response.getCategories().get("CodeCat1").getProductFamilies().forEach(a->{
			if (a.getFamilyName().equals("ProductFamily1")){
				assertEquals(1, a.getTotalSystems());
				assertEquals(1, a.getCodeReleases());
			}else if (a.getFamilyName().equals("ProductFamily2")){
				assertEquals(5, a.getTotalSystems());
				assertEquals(2, a.getCodeReleases());
			}else{
				fail();
			}
		});
		assertEquals(10, response.getCategories().get("CodeCat2").getTotalSystems());
		response.getCategories().get("CodeCat2").getProductFamilies().forEach(a->{
			if (a.getFamilyName().equals("ProductFamily1")){
				assertEquals(10, a.getTotalSystems());
				assertEquals(1, a.getCodeReleases());
			}else{
				fail();
			}
		});
	}
	
	@Test
	public void testGetContractCategories() throws Exception{
		Map<String, Object> filterParams = new HashMap<String, Object>();
		ContractCategoryBean c1 = new ContractCategoryBean();
		c1.setProductFamily("CLARIION");
		c1.setContractExpiresCategory("N/A");
		ContractCategoryBean c2 = new ContractCategoryBean();
		c2.setProductFamily("CLARIION");
		c2.setContractExpiresCategory("Expired");
		ContractCategoryBean c3 = new ContractCategoryBean();
		c3.setProductFamily("CLARIION");
		c3.setContractExpiresCategory("Expired within 30 days");
		ContractCategoryBean c4 = new ContractCategoryBean();
		c4.setProductFamily("CLARIION");
		c4.setContractExpiresCategory("Expires 31-90 Days");
		ContractCategoryBean c5 = new ContractCategoryBean();
		c5.setProductFamily("CLARIION");
		c5.setContractExpiresCategory("Expires 31-90 Days");
		ContractCategoryBean c6 = new ContractCategoryBean();
		c6.setProductFamily("DSSD");
		c6.setContractExpiresCategory("Expires 91-180 Days");
		ContractCategoryBean c7 = new ContractCategoryBean();
		c7.setProductFamily("CLARIION");
		c7.setContractExpiresCategory("Expires beyond 180 Days");
		
		List<ContractCategoryBean> categories = new ArrayList<ContractCategoryBean>();
		categories.add(c1);
		categories.add(c2);
		categories.add(c3);
		categories.add(c4);
		categories.add(c5);
		categories.add(c6);
		categories.add(c7);
		when(installBaseService.getContractCategoryAggregate(filterParams)).thenReturn(categories);
		
		ContractCategoryResponseBean response = controller.getContractCategories(filterParams, request);
		
		assertEquals(new Long(1), (Long)response.getContractCategories().get("N/A"));
		assertEquals(new Long(1), (Long)response.getContractCategories().get("Expired"));
		assertEquals(new Long(1), (Long)response.getContractCategories().get("Expired within 30 days"));
		assertEquals(new Long(2), (Long)response.getContractCategories().get("Expires 31-90 Days"));
		assertEquals(new Long(1), (Long)response.getContractCategories().get("Expires 91-180 Days"));
		assertEquals(new Long(1), (Long)response.getContractCategories().get("Expires beyond 180 Days"));
		
		assertEquals(new Long(1), (Long)response.getContractProductFamilies().get("CLARIION").get("N/A"));
		assertEquals(new Long(1), (Long)response.getContractProductFamilies().get("CLARIION").get("Expired"));
		assertEquals(new Long(1), (Long)response.getContractProductFamilies().get("CLARIION").get("Expired within 30 days"));
		assertEquals(new Long(2), (Long)response.getContractProductFamilies().get("CLARIION").get("Expires 31-90 Days"));
		assertEquals(null, (Long)response.getContractProductFamilies().get("CLARIION").get("Expires 91-180 Days"));
		assertEquals(new Long(1), (Long)response.getContractProductFamilies().get("CLARIION").get("Expires beyond 180 Days"));
		assertEquals(new Long(1), (Long)response.getContractProductFamilies().get("DSSD").get("Expires 91-180 Days"));
		assertEquals(null, (Long)response.getContractProductFamilies().get("DSSD").get("N/A"));
		
		verify(installBaseService, times(1)).getContractCategoryAggregate(filterParams);
	}
	
	@Test
	public void testGetContractCategoriesWithNull() throws Exception{
		Map<String, Object> filterParams = new HashMap<String, Object>();
		List<ContractCategoryBean> categories = new ArrayList<ContractCategoryBean>();
		when(installBaseService.getContractCategoryAggregate(filterParams)).thenReturn(categories);
		
		ContractCategoryResponseBean response = controller.getContractCategories(filterParams, request);
		
		assertEquals(null, (Long)response.getContractCategories().get("N/A"));
		assertEquals(null, (Long)response.getContractCategories().get("Expired"));
		assertEquals(null, (Long)response.getContractCategories().get("Expired within 30 days"));
		assertEquals(null, (Long)response.getContractCategories().get("Expires 31-90 Days"));
		assertEquals(null, (Long)response.getContractCategories().get("Expires 91-180 Days"));
		assertEquals(null, (Long)response.getContractCategories().get("Expires beyond 180 Days"));
		
		assertEquals(null, response.getContractProductFamilies().get("CLARIION"));
		
		verify(installBaseService, times(1)).getContractCategoryAggregate(filterParams);
	}
	
	@Test
	public void testGetContractTimeline() throws Exception {
		// Test the @RequestMapping URL and check the @PathVariable is passed to the service
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", "5000");
		filterParams.put("number", "1");

		List<ContractTimelineBean> list = new ArrayList<ContractTimelineBean>();
		ContractTimelineBean c1 = new ContractTimelineBean();
		c1.setSerialNumber("1030093184");
		list.add(c1);
		when(installBaseService.getContractTimeline(filterParams)).thenReturn(new AsyncResult<List<ContractTimelineBean>>(list));
		when(installBaseService.getContractTimelineTotal(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		PagedResponseBean<ContractTimelineBean> response = controller.getContractTimeline(filterParams, request);
		assertEquals(100000,response.getPage().getTotalElements());
		assertEquals(5000,response.getPage().getSize());
		assertEquals(1,response.getPage().getNumber());
		assertEquals(21,response.getPage().getTotalPages());
		assertEquals("1030093184",response.getRows().get(0).getSerialNumber());

		verify(installBaseService, times(1)).getContractTimeline(filterParams);
		verify(installBaseService, times(1)).getContractTimelineTotal(filterParams);
	}

	@Test
	public void testGetContractTimelinePost() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 1000);
		filterParams.put("number", 1);
		filterParams.put("cpsdFilter", "false");

		List<ContractTimelineBean> list = new ArrayList<ContractTimelineBean>();
		
		when(installBaseService.getContractTimeline(filterParams)).thenReturn(new AsyncResult<List<ContractTimelineBean>>(list));
		when(installBaseService.getContractTimelineTotal(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		this.mockMvc.perform(post("/contract/timeline")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "1000")
				.param("number", "1"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":1000")))
				.andExpect(content().string(containsString("\"totalElements\":100000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":101")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getContractTimeline(filterParams);
			verify(installBaseService, times(1)).getContractTimelineTotal(filterParams);
	}
	
	@Test
	public void testGetContractInventory() throws Exception {
		// Test the @RequestMapping URL and check the @PathVariable is passed to the service
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", "5000");
		filterParams.put("number", "1");

		List<ContractInventoryBean> list = new ArrayList<ContractInventoryBean>();
		ContractInventoryBean c1 = new ContractInventoryBean();
		c1.setSerialNumber("1030093184");
		list.add(c1);
		when(installBaseService.getContractInventory(filterParams)).thenReturn(new AsyncResult<List<ContractInventoryBean>>(list));
		when(installBaseService.getContractInventoryTotal(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		PagedResponseBean<ContractInventoryBean> response = controller.getContractInventory(filterParams, request);
		assertEquals(100000,response.getPage().getTotalElements());
		assertEquals(5000,response.getPage().getSize());
		assertEquals(1,response.getPage().getNumber());
		assertEquals(21,response.getPage().getTotalPages());
		assertEquals("1030093184",response.getRows().get(0).getSerialNumber());

		verify(installBaseService, times(1)).getContractInventory(filterParams);
		verify(installBaseService, times(1)).getContractInventoryTotal(filterParams);
	}

	@Test
	public void testGetContractInventoryPost() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 1000);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "siteDisplayName");
		filterParams.put("sortDir", "desc");
		filterParams.put("cpsdFilter", "false");

		List<ContractInventoryBean> list = new ArrayList<ContractInventoryBean>();
		ContractInventoryBean contractInventoryBean = new ContractInventoryBean();
		contractInventoryBean.setInstanceNumber("2466783");
		list.add(contractInventoryBean);
		
		when(installBaseService.getContractInventory(filterParams)).thenReturn(new AsyncResult<List<ContractInventoryBean>>(list));
		when(installBaseService.getContractInventoryTotal(filterParams)).thenReturn(new AsyncResult<Integer>(100000));

		this.mockMvc.perform(post("/contract")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "1000")
				.param("number", "1"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":1000")))
				.andExpect(content().string(containsString("\"totalElements\":100000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":101")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andExpect(content().string(containsString("\"instanceNumber\":\"2466783\"")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getContractInventory(filterParams);
			verify(installBaseService, times(1)).getContractInventoryTotal(filterParams);
	}
	
	@Test
	public void testGetProductDetail() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "CRK1234");
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		ProductBean p = new ProductBean();
		p.setSerialNumber("CRK1234");
		when(installBaseService.getProductDetail(filterParams)).thenReturn(p);
		
		this.mockMvc.perform(get("/product/CRK1234"))
			.andExpect(status().isOk())
			.andDo(print());
		
		verify(installBaseService, times(1)).getProductDetail(filterParams);
	}
	
	@Test
	public void testGetMilestoneStats() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("instanceNumberIsIn", "97299807");
		
		MilestoneStatsBean msBean = new MilestoneStatsBean();
		msBean.setEopsDateCount(0);
		msBean.setContractEndDateCount(0);
		msBean.setInstallDateCount(1);
		msBean.setPurchaseDateCount(1);
		msBean.setShipDateCount(1);
		
		when(installBaseService.getMilestoneStats(filterParams)).thenReturn(msBean);
		
		this.mockMvc.perform(post("/milestonestats")
			.param("instanceNumberIsIn", "97299807"))
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("\"eopsDateCount\":0")))
			.andExpect(content().string(containsString("\"contractEndDateCount\":0")))
			.andExpect(content().string(containsString("\"installDateCount\":1")))
			.andExpect(content().string(containsString("\"shipDateCount\":1")))
			.andExpect(content().string(containsString("\"purchaseDateCount\":1")))
			.andDo(print());
		
		verify(installBaseService, times(1)).getMilestoneStats(filterParams);
	}
	@Test
    public void testGetConnectHomeStatusDuration() {
        // Arrange
        String productFamily = "SampleProduct";
        Long expectedDuration = 123L; // Replace with expected duration value

        // Mock behavior
        Mockito.when(installBaseService.getConnectHomeStatusDuration(productFamily)).thenReturn(expectedDuration);

        // Act
        Long result = controller.getConnectHomeStatusDuration(productFamily);

        // Assert
        assertEquals(expectedDuration, result);

        
        // Verify that the installBaseService method is called with the correct parameter
        Mockito.verify(installBaseService).getConnectHomeStatusDuration(productFamily);
    }
	@Test
    public void testGetSolutionComponents() { 
        // Arrange
        String serialNumber = "ABC123";
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("sortBy", "componentSerialNumber");
        filterParams.put("searchIsLike", "example_search");

        List<ComponentBean> expectedComponents = new ArrayList<>();  // Populate with expected ComponentBean instances

        Mockito.when(installBaseService.getSolutionComponents(Mockito.anyMap())).thenReturn(expectedComponents);

        // Act
        List<ComponentBean> result = controller.getSolutionComponents(filterParams, serialNumber, request);

        // Assert
        assertEquals(expectedComponents, result);

        // Verify that the provided serial number is converted to uppercase
        assertEquals("ABC123", serialNumber);

        // Verify that the 'sortBy' key is modified to 'serialNumber'
        assertEquals("serialNumber", filterParams.get("sortBy"));

        // Verify that the 'searchIsLike' key is modified to 'example\_search'
        assertEquals("example\\_search", filterParams.get("searchIsLike"));

        // Verify that the 'cpsdSerialNumber' key is added
        assertEquals("ABC123", filterParams.get("cpsdSerialNumber"));

        // Verify that the installBaseService method is called with the modified filterParams
        Mockito.verify(installBaseService).getSolutionComponents(filterParams);
    }
	
	@Test
	public void testGetProductDetail404() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "CRK1234");
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		
		when(installBaseService.getProductDetail(filterParams)).thenReturn(null);
		
		this.mockMvc.perform(get("/product/CRK1234"))
			.andExpect(status().is4xxClientError())
			.andDo(print());
		
		verify(installBaseService, times(1)).getProductDetail(filterParams);
	}
	
	@Test
	public void testGetInstallBaseOverviewGrid() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "siteDisplayName");
		filterParams.put("sortDir", "desc");
		filterParams.put("cpsdFilter", "false");

		List<ProductBean> list = new ArrayList<ProductBean>();
		
		ProductBean productBean = new ProductBean();
		productBean.setInstanceNumber("2674568");
		
		list.add(productBean);
		
		when(installBaseService.getProducts(filterParams)).thenReturn(new AsyncResult<List<ProductBean>>(list));
		when(installBaseService.getProductsTotal(filterParams)).thenReturn(new AsyncResult<Integer>(1000));

		this.mockMvc.perform(post("/products")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "25")
				.param("number", "1"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":25")))
				.andExpect(content().string(containsString("\"totalElements\":1000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":41")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andExpect(content().string(containsString("\"instanceNumber\":\"2674568\"")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getProducts(filterParams);
			verify(installBaseService, times(1)).getProductsTotal(filterParams);
	}
	
	
	@Test
	public void testGetInstallBaseOverviewGridWithCPSD() throws Exception {
		controller.setCpsdFilter(false);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "siteDisplayName");
		filterParams.put("sortDir", "desc");
		
		List<ProductBean> list = new ArrayList<ProductBean>();
		
		ProductBean productBean = new ProductBean();
		productBean.setInstanceNumber("2674568");
		
		list.add(productBean);
		
		when(installBaseService.getProducts(filterParams)).thenReturn(new AsyncResult<List<ProductBean>>(list));
		when(installBaseService.getProductsTotal(filterParams)).thenReturn(new AsyncResult<Integer>(1000));

		this.mockMvc.perform(post("/products")
				.param("siteNumberIsIn", "1234|5678")
				.param("size", "25")
				.param("number", "1"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"page\":")))
				.andExpect(content().string(containsString("\"size\":25")))
				.andExpect(content().string(containsString("\"totalElements\":1000")))
				.andExpect(content().string(containsString("\"number\":1")))
				.andExpect(content().string(containsString("\"totalPages\":41")))
				.andExpect(content().string(containsString("\"rows\":")))
				.andExpect(content().string(containsString("\"instanceNumber\":\"2674568\"")))
				.andDo(print());
				
			verify(installBaseService, times(1)).getProducts(filterParams);
			verify(installBaseService, times(1)).getProductsTotal(filterParams);
	}
	
	
	@Test
	public void testGetProductTimeline() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "CRK1234");
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		filterParams.put("filterBy", "contractEndDate|shipDate|eoslDate|purchaseDate|installDate|locationChange|contractRenewal");
		filterParams.put("size", 50);
		Long eops = Instant.now().toEpochMilli();
		Long contractRenewalDate = Instant.now().toEpochMilli();
		Long lastConnectHome = Instant.now().toEpochMilli();
		Long contractEndDate = Instant.now().toEpochMilli();
		Long shipDate = Instant.now().toEpochMilli();
		Long purchaseDate = Instant.now().toEpochMilli();
		Long installDate = Instant.now().toEpochMilli();
		
		
		Map<String, Object> locationChange = new HashMap();
		locationChange.put("requestDate", Instant.now().toEpochMilli());
		
		Map<String, Object> contractRenew = new HashMap();
		contractRenew.put("contractSubmissionDate", Instant.now().toEpochMilli());
		
		Map<String, Object> productChangeEventMap = new HashMap<>();
		productChangeEventMap.put("locationChange", Arrays.asList(locationChange));
		productChangeEventMap.put("contractRenewal", Arrays.asList(contractRenew));
		when(installBaseService.getProductChangeEvent(12345L)).thenReturn(productChangeEventMap);
	
		
		
		ProductBean p = new ProductBean();
		p.setSerialNumber("CRK1234");
		p.setEops(eops);
		p.setContractRenewalDate(contractRenewalDate);
		p.setLastConnectHome(lastConnectHome.toString());
		p.setContractEndDate(contractEndDate);
		p.setShipDate(shipDate);
		p.setPurchaseDate(purchaseDate);
		p.setInstallDate(installDate.toString());
		p.setInstanceNumber("12345");
		
		when(installBaseService.getProductDetail(filterParams)).thenReturn(p);
		
		this.mockMvc.perform(get("/product/CRK1234/timeline").param("filterBy", "contractEndDate|shipDate|eoslDate|purchaseDate"
				+ "|installDate|locationChange|contractRenewal").param("size", "50"))
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("SHIP_DATE")))
			.andExpect(content().string(containsString("TODAY")))
			.andExpect(content().string(containsString("EOSS")))
			.andExpect(content().string(containsString("PURCHASE_DATE")))
			.andExpect(content().string(containsString("CONTRACT_END")))
			.andExpect(content().string(containsString("INSTALL_DATE")))
			.andExpect(content().string(containsString("LOCATION_CHANGE")))
			.andExpect(content().string(containsString("CONTRACT_RENEWAL")))
			.andDo(print());
		
		verify(installBaseService, times(1)).getProductDetail(filterParams);
	}
	
	@Test
	public void testGetConnectivtyFilters() throws Exception {
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		filterParams.put("connectivity", "true");
		
		InstallBaseFilterValuesBean bean = new InstallBaseFilterValuesBean();
		List<String> ibStatus = new ArrayList<String>();
		ibStatus.add("ibStatus");
		bean.setIbStatus(ibStatus);
		
		List<String> productName = new ArrayList<String>();
		List<String> contractStatus = new ArrayList<String>();
		productName.add("productName");
		contractStatus.add("contractStatus");
		
		when(installBaseService.getInstallBaseFilterValues(filterParams)).thenReturn(new AsyncResult<InstallBaseFilterValuesBean>(bean));
		when(installBaseService.getProductNames(filterParams)).thenReturn(new AsyncResult<List<String>>(productName));
		when(installBaseService.getContractStatus(filterParams)).thenReturn(new AsyncResult<List<String>>(contractStatus));
		
		this.mockMvc.perform(post("/connectivity/filters")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"ibStatus\":[\"ibStatus\"]")))
				.andExpect(content().string(containsString("\"productName\":[\"productName\"]")))
				.andExpect(content().string(containsString("\"contractStatus\":[\"contractStatus\"]")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getInstallBaseFilterValues(filterParams);
		verify(installBaseService, times(1)).getProductNames(filterParams);
		verify(installBaseService, times(1)).getContractStatus(filterParams);
		
		
	}
	
	@Test
	public void testGetConnectivitySerialFilterValues() throws Exception {
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "1234|5678");
		filterParams.put("cpsdFilter", "false");
		filterParams.put("connectivity", "true");
		
		List<String> serialNumber = new ArrayList<String>();
		serialNumber.add("34983464");
		
		when(installBaseService.getSerialNumbers(filterParams)).thenReturn(serialNumber);
		
		this.mockMvc.perform(post("/connectivity/filters/serialnumber")
				.param("siteNumberIsIn", "1234|5678"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"34983464\"")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getSerialNumbers(filterParams);
	}
	
	@Test
	public void testGetConnectivityInstanceFilterValues() throws Exception {
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("connectivity", "true");
		filterParams.put("cpsdFilter", "false");
		
		List<String> instanceNumbers = new ArrayList<String>();
		instanceNumbers.add("231380840");
		
		when(installBaseService.getInstanceIds(filterParams)).thenReturn(instanceNumbers);
		
		this.mockMvc.perform(post("/connectivity/filters/instancenumber"))		
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"231380840\"")))
				.andDo(print());
		
		verify(installBaseService, times(1)).getInstanceIds(filterParams);
		
	}
	
//	@Test
//	public void testGetSolutionComponents() throws Exception {
//		
//		Map<String, Object> filterParams = new HashMap<String, Object>();
//		filterParams.put("sortBy","serialNumber");
//		filterParams.put("searchIsLike", "abcd");
//		filterParams.put("cpsdSerialNumber", "1341214");
//		
//		ComponentBean cb = new ComponentBean();
//		cb.setCiSolutionSerialNumber("1341214");
//		cb.setComponentModelNumber("wejqw223");
//		cb.setComponentName("ABCD");
//		cb.setComponentSerialNumber("349575");
//		cb.setContractNumber("4974");
//		
//		List<ComponentBean> listOfComponentBean = new ArrayList<>();
//		listOfComponentBean.add(cb);
//		
//		when(installBaseService.getSolutionComponents(filterParams)).thenReturn(listOfComponentBean);
//		
//		this.mockMvc.perform(post("/product/1341214/components")
//		.param("sortBy", "componentSerialNumber")
//		.param("searchIsLike", "abcd"))		
//		.andExpect(status().isOk())
//		.andExpect(content().string(containsString("\"1341214\"")))
//		.andExpect(content().string(containsString("\"wejqw223\"")))
//		.andExpect(content().string(containsString("\"349575\"")))
//		.andDo(print());
//		
//		verify(installBaseService, times(1)).getSolutionComponents(filterParams);
//		
//	}
//	@Test
//	public void testGetSolutionComponents() throws Exception {
//	    // Create filterParams as needed for the test
//	    Map<String, Object> filterParams = new HashMap<>();
//	    filterParams.put("sortBy", "componentSerialNumber");
//	    // Add other filterParams as needed
//
//	    // Serial number path variable
//	    String serialNumber = "ABCD1234";  // Replace with a valid serial number
//
//	    // Create a mock request and response
//	    MockHttpServletRequest request = new MockHttpServletRequest();
//	    MockHttpServletResponse response = new MockHttpServletResponse();
//
//	    // Create a ColumnWrapper object and serialize it to a JSON string
//	    ColumnWrapper colWrapper = new ColumnWrapper();
//	    // Set properties of the ColumnWrapper object as needed
//
//	    ObjectMapper objectMapper = new ObjectMapper();
//	    String columnsJson = objectMapper.writeValueAsString(colWrapper);
//	    filterParams.put("columns", columnsJson);
//
//	    // Mock the behavior of the installBaseService.getSolutionComponents method
//	    OutputStream outputStream = new ByteArrayOutputStream();
//	    doAnswer(invocation -> {
//	        OutputStream out = invocation.getArgument(0);
//	        // Simulate writing to the output stream, e.g., writing CSV data
//	        out.write("CSV data".getBytes());
//	        return null;
//	    }).when(installBaseService).getSolutionComponents(any(OutputStream.class), eq(filterParams), anyList());
//
//	    // Perform a GET request to the /solution/{serialNumber} endpoint
//	    MvcResult result = mockMvc.perform(get("/product/{serialNumber}/components", serialNumber)
//	            .contentType(MediaType.APPLICATION_JSON)
//	            .content(objectMapper.writeValueAsString(filterParams))
//	            .accept(MediaType.APPLICATION_JSON))
//	            .andExpect(status().isOk())
//	            .andReturn(); 
//
//	    // Verify that the necessary methods were called
//	    verify(installBaseService, times(1)).getSolutionComponents(any(OutputStream.class), eq(filterParams), anyList());
//
//	    // Validate the response content
//	    String responseContent = result.getResponse().getContentAsString();
//	    assertThat(responseContent, containsString("CSV data"));
//	}
	@Test
	public void testGetProductTimelineforContractEoslInstalldate() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "CRK1234");
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		filterParams.put("filterBy", "contractEndDate|eoslDate|installDate|aliasChange");
		filterParams.put("size", 50);
		Long eops = Instant.now().toEpochMilli();
		Long contractRenewalDate = Instant.now().toEpochMilli();
		Long lastConnectHome = Instant.now().toEpochMilli();
		Long contractEndDate = Instant.now().toEpochMilli();
		Long shipDate = Instant.now().toEpochMilli();
		Long purchaseDate = Instant.now().toEpochMilli();
		Long installDate = Instant.now().toEpochMilli();
		
		
		Map<String, Object> locationChange = new HashMap();
		locationChange.put("requestDate", Instant.now().toEpochMilli());
		
		Map<String, Object> aliasChange = new HashMap();
		aliasChange.put("updateDate", Instant.now().toEpochMilli());
		
		Map<String, Object> productChangeEventMap = new HashMap<>();
		productChangeEventMap.put("locationChange", Arrays.asList(locationChange));
		productChangeEventMap.put("aliasChange", Arrays.asList(aliasChange));
		when(installBaseService.getProductChangeEvent(12345L)).thenReturn(productChangeEventMap);
	
		
		
		ProductBean p = new ProductBean();
		p.setSerialNumber("CRK1234");
		p.setEops(eops);
		p.setContractRenewalDate(contractRenewalDate);
		p.setLastConnectHome(lastConnectHome.toString());
		p.setContractEndDate(contractEndDate);
		p.setShipDate(shipDate);
		p.setPurchaseDate(purchaseDate);
		p.setInstallDate(installDate.toString());
		p.setInstanceNumber("12345");
		
		when(installBaseService.getProductDetail(filterParams)).thenReturn(p);
		
		this.mockMvc.perform(get("/product/CRK1234/timeline").param("filterBy", "contractEndDate|eoslDate|installDate|aliasChange").param("size", "50"))
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("TODAY")))
			.andExpect(content().string(containsString("EOSS")))
			.andExpect(content().string(containsString("CONTRACT_END")))
			.andExpect(content().string(containsString("INSTALL_DATE")))
			.andExpect(content().string(containsString("LOCATION_CHANGE")))
			.andExpect(content().string(containsString("ALIAS_CHANGE")))
			.andDo(print());
		
		verify(installBaseService, times(1)).getProductDetail(filterParams);
	}
	
	
	@Test
	public void testGetMilestonesTimelineRangeEventCount() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "14700576");
		filterParams.put("tlvTimeRangeBefore", "1577750400000");
		filterParams.put("tlvTimeRangeAfter", "123292800000");
		filterParams.put("serialNumberIsIn", "APM00125145580");
		Map<Long,Integer> timelineEvent = new HashMap<>();
		timelineEvent.put(1495670400000L, 1) ;
		timelineEvent.put(1496707200000L, 2) ;
		
		when(installBaseService.getMilestonesTimelineRangeEventCount(filterParams)).thenReturn(timelineEvent);

		this.mockMvc.perform(post("/milestones/timeline/timerange")
			.param("siteNumberIsIn", "14700576")
			.param("tlvTimeRangeBefore", "1577750400000")
			.param("tlvTimeRangeAfter", "123292800000")
			.param("serialNumberIsIn", "APM00125145580"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.1495670400000").value(1))
			.andExpect(jsonPath("$.1496707200000").value(2))
			.andReturn().getResponse().getContentAsString().equals(timelineEvent.toString());
		
		verify(installBaseService,times(1)).getMilestonesTimelineRangeEventCount(filterParams);
	}
	
	@Test
	public void testGetTimelineDataForTlvSlider() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "CRK12345");
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		filterParams.put("size", 50);
		filterParams.put("tlvTimeRangeBefore", "1534962600000");
		filterParams.put("tlvTimeRangeAfter", "1356978600000");
		
		Long eosl = Instant.now().toEpochMilli();
		Long contractRenewalDate = 1534962600000l;
		Long lastConnectHome = 1534876200000l;
		Long contractEndDate = 1566412200000l;
		Long shipDate = 1409250600000l;
		Long purchaseDate = 1408905000000l;
		Long installDate = 1440268200000l;
		
		
		Map<String, Object> locationChange = new HashMap<>();
		locationChange.put("requestDate", 1534962600000l);
		
		Map<String, Object> aliasChange = new HashMap<>();
		aliasChange.put("updateDate", Instant.now().toEpochMilli());
		
		Map<String, Object> contractRenewal=new HashMap<>();
		contractRenewal.put("contractSubmissionDate",1503513000000l);
		
		
		Map<String, Object> productChangeEventMap = new HashMap<>();
		productChangeEventMap.put("locationChange", Arrays.asList(locationChange));
		productChangeEventMap.put("aliasChange", Arrays.asList(aliasChange));
		productChangeEventMap.put("contractRenewal", Arrays.asList(contractRenewal));
		
		when(installBaseService.getProductChangeEvent(12345L)).thenReturn(productChangeEventMap);

		ProductBean p = new ProductBean();
		p.setSerialNumber("CRK12345");
		p.setEosl(eosl);
		p.setContractRenewalDate(contractRenewalDate);
		p.setLastConnectHome(lastConnectHome.toString());
		p.setContractEndDate(contractEndDate);
		p.setShipDate(shipDate);
		p.setPurchaseDate(purchaseDate);
		p.setInstallDate(installDate.toString());
		p.setInstanceNumber("12345");
		
		when(installBaseService.getProductDetail(filterParams)).thenReturn(p);
		
		this.mockMvc.perform(get("/product/CRK12345/timeline").param("size", "50")
				.param("tlvTimeRangeBefore", "1534962600000").param("tlvTimeRangeAfter", "1356978600000"))
		    .andExpect(status().isOk())
			.andExpect(content().string(containsString("TODAY")))
			.andExpect(content().string(containsString("INSTALL_DATE")))
			.andExpect(content().string(containsString("LOCATION_CHANGE")))
			.andExpect(content().string(containsString("CONTRACT_RENEWAL")))
			.andDo(print());
		
		verify(installBaseService, times(1)).getProductDetail(filterParams);
	}
	
	@Test
	public void testGetWarranties() throws Exception {
		Entitlement ent1 = new Entitlement();
		ent1.setContractEndDate(new Date(2021, 2, 2));
		ent1.setContractStartDate(new Date(2019,2,2));
		ent1.setSalesOrderNumber("12344");
		ent1.setContractId("1233");
		ent1.setContractTerminationDate(new Date(2022,2,2));
		ent1.setServiceDescription("Parts Retention");
		ent1.setType("RET");
		ent1.setServiceLevelCode("MH");
		ent1.setStatus("Active");
		List<Entitlement> result = new ArrayList<Entitlement>();
		result.add(ent1);
		WarrantyResponse response = new WarrantyResponse();
		response.setEntitlementPresent(true);
		response.setEntitlements(result);
		response.setProductId("AB1234");
		
		when(installBaseService.getWarranties("AB1234")).thenReturn(response);
		this.mockMvc.perform(get("/warranties/AB1234"))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("\"productId\":\"AB1234\"")));
		
		verify(installBaseService, times(1)).getWarranties("AB1234");
	}
	
	@Test
	public void testDownloadConnectivityList() throws Exception {
	    
	    ObjectMapper objectMapper = new ObjectMapper();
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("siteNumberIsIn", "1234|5678");
	    filterParams.put("size", 200); // Size of 200 as per the default
	    filterParams.put("number", 0); // Number 0 as per the default
	    filterParams.put("sortBy", "siteDisplayName");
	    filterParams.put("sortDir", "desc");
	    filterParams.put("connectivity", "true");
	    filterParams.put("cpsdFilter", "false");
 
	    List<ConnectivityProductBean> connectivityList = new ArrayList<>();
	    // Add ConnectivityProductBean objects to the list
 
	    when(installBaseService.getConnectivityTotalRecord(any())).thenReturn(CompletableFuture.completedFuture(connectivityList.size()));
	    when(installBaseService.getConnectivityList(any())).thenReturn(CompletableFuture.completedFuture(connectivityList));
	    mockMvc.perform(post("/connectivity")
            .contentType(MediaType.APPLICATION_JSON)
	            .content(objectMapper.writeValueAsString(filterParams))
	            .accept(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())
	            .andExpect(content().string(containsString("{\"page\":{\"size\":200,\"totalElements\":0,\"totalPages\":1,\"number\":0},\"rows\":[]}")))
	            .andDo(print());
				
			verify(installBaseService, times(1)).getConnectivityList(any());
	}
	@Test
	public void testGetTimelineDataEOSSCondition() throws Exception {
	    // Create filterParams as needed for the test
	    Map<String, Object> filterParams = new HashMap<>();
	    // Add other filterParams as needed

	    // Serial number path variable
	    String serialNumber = "ABCD1234";  // Replace with a valid serial number

	    // Create a ProductBean with a specific EOPS value
	    ProductBean pb = new ProductBean();
	    Long eops = Instant.now().toEpochMilli();
	    pb.setEops(eops);
	    pb.setInstanceNumber("123456");

	    // Mock getProductDetail method
	    when(installBaseService.getProductDetail(filterParams)).thenReturn(pb);

	    // Set the advancedTimelineFilters and filterBy based on your condition
	    // For example, set advancedTimelineFilters to true and filterBy to "eossDate"

	    // Set tlvTimeRangeBefore and tlvTimeRangeAfter to appropriate values that satisfy the condition

	    // Perform a GET request to the /product/{serialNumber}/timeline endpoint
	    List<TimelineEntity> timelineEntities = controller.getTimelineData(filterParams, serialNumber, request);

	    // Verify that the "EOSS" entity is added to timelineEntities
	    boolean eossEntityFound = false;
	    for (TimelineEntity entity : timelineEntities) {
	        if ("EOSS".equals(entity.getEntityType())) {
	            eossEntityFound = true;
	            // Additional assertions for the "EOSS" entity
	        }
	    }
	    assertTrue(eossEntityFound);
	}
	@Test
	public void testGetTimelineDataShipDateCondition() throws Exception {
	    // Create filterParams as needed for the test
	    Map<String, Object> filterParams = new HashMap<>();
	    // Add other filterParams as needed

	    // Serial number path variable
	    String serialNumber = "ABCD1234";  // Replace with a valid serial number

	    // Create a ProductBean with a specific ShipDate value
	    ProductBean pb = new ProductBean();
	    Long shipDate = Instant.now().toEpochMilli();
	    pb.setShipDate(shipDate);
	    pb.setInstanceNumber("123456");

	    // Mock getProductDetail method
	    when(installBaseService.getProductDetail(filterParams)).thenReturn(pb);

	    // Set the advancedTimelineFilters and filterBy based on your condition
	    // For example, set advancedTimelineFilters to true and filterBy to "shipDate"

	    // Set tlvTimeRangeBefore and tlvTimeRangeAfter to appropriate values that satisfy the condition

	    // Perform a GET request to the /product/{serialNumber}/timeline endpoint
	    List<TimelineEntity> timelineEntities = controller.getTimelineData(filterParams, serialNumber, request);

	    // Verify that the "SHIP_DATE" entity is added to timelineEntities
	    boolean shipDateEntityFound = false;
	    for (TimelineEntity entity : timelineEntities) {
	        if ("SHIP_DATE".equals(entity.getEntityType())) {
	            shipDateEntityFound = true;
	            // Additional assertions for the "SHIP_DATE" entity
	        }
	    }
	    assertTrue(shipDateEntityFound);
	}
	@Test
	public void testGetTimelineDataPurchaseDateCondition() throws Exception {
	    // Create filterParams as needed for the test
	    Map<String, Object> filterParams = new HashMap<>();
	    // Add other filterParams as needed

	    // Serial number path variable
	    String serialNumber = "ABCD1234";  // Replace with a valid serial number

	    // Create a ProductBean with a specific PurchaseDate value
	    ProductBean pb = new ProductBean();
	    Long purchaseDate = Instant.now().toEpochMilli();
	    pb.setPurchaseDate(purchaseDate);
	    pb.setInstanceNumber("123456");

	    // Mock getProductDetail method
	    when(installBaseService.getProductDetail(filterParams)).thenReturn(pb);

	    // Set the advancedTimelineFilters and filterBy based on your condition
	    // For example, set advancedTimelineFilters to true and filterBy to "purchaseDate"

	    // Set tlvTimeRangeBefore and tlvTimeRangeAfter to appropriate values that satisfy the condition

	    // Perform a GET request to the /product/{serialNumber}/timeline endpoint
	    List<TimelineEntity> timelineEntities = controller.getTimelineData(filterParams, serialNumber, request);

	    // Verify that the "PURCHASE_DATE" entity is added to timelineEntities
	    boolean purchaseDateEntityFound = false;
	    for (TimelineEntity entity : timelineEntities) {
	        if ("PURCHASE_DATE".equals(entity.getEntityType())) {
	            purchaseDateEntityFound = true;
	            // Additional assertions for the "PURCHASE_DATE" entity
	        }
	    }
	    assertTrue(purchaseDateEntityFound);
	}



}
