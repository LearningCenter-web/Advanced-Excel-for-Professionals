package com.emc.dvs.ib.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.emc.dvs.ib.exception.AccessException;
import com.emc.dvs.ib.service.AccountService;

public class SiteRelationServiceTests {

    @InjectMocks
    private SiteRelationService siteRelationService;

    @Mock
    private AccountService accountService;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetSiteRelationShip() {
        String siteNumber = "site123";
        String deviceId = "device123";
        String uid = "uid123";
        String loginName = "user123";

        // Mock the behavior of the accountService
        List<Object> mockResult = Collections.singletonList(
                Collections.singletonMap("Relation", "partner123")
        );
        Mockito.when(accountService.getSiteDetails(siteNumber, loginName)).thenReturn(mockResult);

        // Call the method under test
        String result = siteRelationService.getSiteRelationShip(siteNumber, deviceId, uid, loginName);

        // Verify the result
        assertEquals("partner123", result);
    }
    @Test
    public void testGetSiteRelationShip_NonEmptyResponse() {
        // Arrange
        String siteNumber = "123";
        String deviceId = "device123";
        String uid = "user123";
        String loginName = "user@example.com";
        Map<String, Object> siteDetails = new HashMap<>();
        siteDetails.put("Relation", "Some Relation");

        List<Object> response = new ArrayList<>();
        response.add(siteDetails);

        // Mock the accountService
        AccountService accountService = Mockito.mock(AccountService.class);
        Mockito.when(accountService.getSiteDetails(siteNumber, loginName)).thenReturn(response);
        siteRelationService = new SiteRelationService(accountService);

        // Act
        String relation = siteRelationService.getSiteRelationShip(siteNumber, deviceId, uid, loginName);

        // Assert
        assertEquals("Some Relation", relation);
    }
    
    @Test
    public void testGetSiteRelationShipWithValidData() throws Exception {
        // Create mock data
        String siteNumber = "123";
        String deviceId = "device123";
        String uid = "user123";
        String loginName = "john.doe";
        Map<String, Object> siteDetails = new HashMap<>();
        siteDetails.put("Relation", "CustomerPartner");

        // Mock the behavior of accountService
        when(accountService.getSiteDetails(siteNumber, loginName)).thenReturn(List.of(siteDetails));
        
        // Call the method under test
        String result = siteRelationService.getSiteRelationShip(siteNumber, deviceId, uid, loginName);

        // Verify that the method returns the expected result
        assertEquals("CustomerPartner", result);
    }
    @Test
    public void testGetSiteRelationShipMissingRelation() {
        String siteNumber = "site123";
        String deviceId = "device123";
        String uid = "uid123";
        String loginName = "user123";

        // Mock the behavior of the accountService to return a list without the "Relation" key
        List<Object> mockResult = Collections.singletonList(
                Collections.singletonMap("OtherField", "value123")
        );
        Mockito.when(accountService.getSiteDetails(siteNumber, loginName)).thenReturn(mockResult);

        // Ensure that an AccessException is thrown when "Relation" is missing
        assertThrows(AccessException.class,
                () -> siteRelationService.getSiteRelationShip(siteNumber, deviceId, uid, loginName));
    }
    
   
}
