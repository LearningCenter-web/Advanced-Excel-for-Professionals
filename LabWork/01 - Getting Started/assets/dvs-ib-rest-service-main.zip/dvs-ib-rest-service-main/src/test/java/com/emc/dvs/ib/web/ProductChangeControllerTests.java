package com.emc.dvs.ib.web;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.emc.dvs.ib.service.DvsAuditService;
import com.emc.dvs.ib.service.HttpStreamService;
import com.emc.dvs.ib.service.InstallBaseService;
import com.emc.dvs.ib.service.MailService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class ProductChangeControllerTests {
	
	@InjectMocks
	private ProductChangeController controller;
	
	@Mock
	private InstallBaseService installBaseService;
	
	@Mock
	MailService mailService;
	
	@Mock
	DvsAuditService dvsAuditService;

	@Mock
	private HttpServletRequest request;
	
	@Mock
	private OAuth2RestOperations oAuthRestTemplate;
	
	private DefaultOAuth2AccessToken token;
	
	@Mock
	private HttpStreamService httpStreamService;
	
	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
		token = new DefaultOAuth2AccessToken("");
		Map<String,Object> i = new HashMap<String,Object>();
		i.put("instance_url", "http://baseUrl");
		token.setAdditionalInformation(i);
		
		controller.setEditProductAliasUrl("/editAlias");
		controller.setSfdcRestTemplate(oAuthRestTemplate);
		LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel(Logger.ROOT_LOGGER_NAME, LogLevel.TRACE);
	}
	
	@Test
	public void testInsertContractRenewalRecord() throws Exception {
		UserBean userBean = new UserBean();
		userBean.setIdentityType("C");
		userBean.setUid("12345");
		userBean.setFlname("Firstname Lastname");
		
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("model", "ABC");
		contractDetails.put("serialNumber", "1000");
		contractDetails.put("dunsNumber", "1001");
		contractDetails.put("siteId", "1002");
		contractDetails.put("companyName", "PQR");
		contractDetails.put("contactName", "XYZ");
		contractDetails.put("contactPhone", "0123456789");
		contractDetails.put("contactEmail", "xyz@pqr.com");
		contractDetails.put("comments", "Test Comment");
		contractDetails.put("contractRenewalAction", "renewContract");
		contractDetails.put("siteAddress", "siteAddress");
		contractDetails.put("country", "country");
		contractDetails.put("theater", "theater");
		contractDetails.put("contractRequestType", "servicePlan");

		ObjectMapper mapper = new ObjectMapper();

		this.mockMvc.perform(post("/renewcontract")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(contractDetails))
				.requestAttr("USER_BEAN", userBean))
				.andExpect(status().isOk());

		verify(mailService, times(1)).sendContractRenewalMail(contractDetails);
		verify(installBaseService, times(1)).insertContractRenewalRecord(contractDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
	}
	
	@Test
	public void testInsertContractRenewalRecordForRefreshEquipment() throws Exception {
		UserBean userBean = new UserBean();
		userBean.setIdentityType("C");
		userBean.setUid("12345");
		userBean.setFlname("Firstname Lastname");
		
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("model", "ABC");
		contractDetails.put("serialNumber", "1000");
		contractDetails.put("dunsNumber", "1001");
		contractDetails.put("siteId", "1002");
		contractDetails.put("companyName", "PQR");
		contractDetails.put("contactName", "XYZ");
		contractDetails.put("contactPhone", "0123456789");
		contractDetails.put("contactEmail", "xyz@pqr.com");
		contractDetails.put("comments", "Test Comment");
		contractDetails.put("contractRenewalAction", "refreshEquipment");
		contractDetails.put("siteAddress", "siteAddress");
		contractDetails.put("country", "country");
		contractDetails.put("theater", "theater");
		contractDetails.put("contractRequestType", "refreshEquipment");

		ObjectMapper mapper = new ObjectMapper();

		this.mockMvc.perform(post("/renewcontract")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(contractDetails))
				.requestAttr("USER_BEAN", userBean))
				.andExpect(status().isOk());

		verify(mailService, times(1)).sendContractRenewalMail(contractDetails);
		verify(installBaseService, times(1)).insertContractRenewalRecord(contractDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
	}
	
	@Test
	public void testInsertContractRenewalRecordForOFS() throws Exception {
		UserBean userBean = new UserBean();
		userBean.setIdentityType("C");
		userBean.setUid("12345");
		userBean.setFlname("Firstname Lastname");
		
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("model", "ABC");
		contractDetails.put("serialNumber", "1000");
		contractDetails.put("dunsNumber", "1001");
		contractDetails.put("siteId", "1002");
		contractDetails.put("companyName", "PQR");
		contractDetails.put("contactName", "XYZ");
		contractDetails.put("contactPhone", "0123456789");
		contractDetails.put("contactEmail", "xyz@pqr.com");
		contractDetails.put("comments", "Test Comment");
		contractDetails.put("contractRenewalAction", "renewContract");
		contractDetails.put("siteAddress", "siteAddress");
		contractDetails.put("country", "country");
		contractDetails.put("theater", "theater");
		contractDetails.put("contractRequestType", "optimizeForStorage");

		ObjectMapper mapper = new ObjectMapper();

		this.mockMvc.perform(post("/renewcontract")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(contractDetails))
				.requestAttr("USER_BEAN", userBean))
				.andExpect(status().isOk());

		verify(mailService, times(1)).sendContractRenewalMail(contractDetails);
		verify(installBaseService, times(1)).insertContractRenewalRecord(contractDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
	}
//	 @Test
//	    public void testDownloadAliasChangeData() throws Exception {
//	        // Set up the MockMvc
//	        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
//
//	        // Create a sample filterParams (as a JSON string)
//	        String filterParams = "{\"columns\": {\"column1\": true, \"column2\": true}, \"otherParam\": \"value\"}";
//
//	        // Mock the service behavior
//	        doNothing().when(installBaseService).getAliasChanges(any(OutputStream.class), anyMap(), any());
//
//	        mockMvc.perform(MockMvcRequestBuilders.get("/yourEndpoint/{instanceNumber}", 123L)
//	                .param("filterParams", filterParams))
//	                .andExpect(MockMvcResultMatchers.status().isOk())
//	                .andExpect(MockMvcResultMatchers.header().string("Content-disposition", "attachment;filename=AliasChange_Export.csv"))
//	                .andExpect(MockMvcResultMatchers.content().contentType("txt/csv"))
//	                .andExpect(MockMvcResultMatchers.content().string("Sample CSV Data"));
//
//	        // Verify interactions with the service
//	        verify(installBaseService, times(1)).getAliasChanges(any(OutputStream.class), anyMap(), any());
//
//	        // You can add more assertions based on your specific requirements and expected behavior.
//	    }
	 @Test
	    public void testValidIdentityTypes() {
	        assertEquals("Employee", getUserIdentityTypeValue("E"));
	        assertEquals("Customer", getUserIdentityTypeValue("C"));
	        assertEquals("Partner", getUserIdentityTypeValue("P"));
	        assertEquals("Vendor", getUserIdentityTypeValue("V"));
	        assertEquals("Temp", getUserIdentityTypeValue("T"));
	    }

	    @Test
	    public void testMultipleIdentityTypes() {
	        assertEquals("Partner,Customer", getUserIdentityTypeValue("P,C"));
	        assertEquals("Customer,Partner", getUserIdentityTypeValue("C,P"));
	    }

	    @Test
	    public void testInvalidIdentityTypes() {
	        assertNull(getUserIdentityTypeValue("X"));
	        assertNull(getUserIdentityTypeValue(""));
	        assertNull(getUserIdentityTypeValue(null));
	    }

	    @Test
	    public void testEdgeCases() {
	        assertNull(getUserIdentityTypeValue(" "));
	        assertNull(getUserIdentityTypeValue("EC"));
	        assertNull(getUserIdentityTypeValue("C,P,V,E"));
	    }
	 public String getUserIdentityTypeValue(String identityType) {
	        String identityTypeValue = null;
	        if (identityType == null) {
	            return null; // Handle null input by returning null
	        }
	        switch (identityType) {
	            case "E":
	                identityTypeValue = "Employee";
	                break;
	            case "C":
	                identityTypeValue = "Customer";
	                break;
	            case "P":
	                identityTypeValue = "Partner";
	                break;
	            case "P,C":
	                identityTypeValue = "Partner,Customer";
	                break;
	            case "C,P":
	                identityTypeValue = "Customer,Partner";
	                break;
	            case "V":
	                identityTypeValue = "Vendor";
	                break;
	            case "T":
	                identityTypeValue = "Temp";
	                break;
	        }
	        return identityTypeValue;
	    }
	
	@Test
	public void testEditProductAlias() throws Exception{
		String assetId = "123456";
		String productAlias = "{\"Product_Alias__C\":\"Test Alias\", \"assetId\": \"123456\", \"instanceNumber\": \"789123\", \"convergedInfrastructure\": false, \"instanceId\": \"123456\"}";
		
		UserBean userBean = new UserBean();
		userBean.setIdentityType("E");
		userBean.setUid("12345");
		userBean.setLoginName("loginName");
		userBean.setFlname("Firstname Lastname");
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		Map<String, String> sfdcBody = new HashMap<>();
		sfdcBody.put("Product_Alias__C", "Test Alias");
		HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(sfdcBody, headers);
		ResponseEntity<Object> response = new ResponseEntity<Object>(null, HttpStatus.NO_CONTENT);
		when(oAuthRestTemplate.getAccessToken()).thenReturn(token);
		when(oAuthRestTemplate.exchange("http://baseUrl/editAlias", HttpMethod.PATCH, requestEntity, Object.class, assetId)).thenReturn(response);
		
		Map<String, Object> streamMap = new HashMap<>();
		streamMap.put("productAlias", "Test Alias");
		streamMap.put("instanceNumber", "789123");
		streamMap.put("instanceId", "123456");
		streamMap.put("serialNumber", "123ABC");
		doNothing().when(httpStreamService).updateProductAlias(streamMap);
		this.mockMvc.perform(post("/productalias/123ABC")
				.content(productAlias).contentType("application/json").requestAttr("USER_BEAN", userBean)).andExpect(status().isOk());
		
		verify(oAuthRestTemplate, times(1)).exchange("http://baseUrl/editAlias", HttpMethod.PATCH, requestEntity, Object.class, assetId);
		verify(httpStreamService).updateProductAlias(streamMap);
	}
	
	@Test
	public void testUpdateSiteLocation() throws Exception {
		
		ObjectMapper mapper = new ObjectMapper();
		UserBean userBean = new UserBean();
		userBean.setIdentityType("E");
		userBean.setUid("12345");
		userBean.setLoginName("user1");
		userBean.setPhoneNumber("123456789");
		userBean.setEmail("email");
		userBean.setFlname("flname");
		
		Map<String, Object> siteDetails = new HashMap<>();
		siteDetails.put("serialNumber", "BRCAHX1941G02G");
	    siteDetails.put("productName", "Connectrix DS-5300B");
	    siteDetails.put("connectFlag", "Not Connected");
	    siteDetails.put("connectionType", "OTHER");
	    siteDetails.put("productAlias", "Test Alias");
	    siteDetails.put("originalSiteNumber" , "1234567899");
	    siteDetails.put("originalSiteName" , "XYZ Company");
	    siteDetails.put("originalAddress1" , "620 16th Street");
	    siteDetails.put("originalAddress2" , "Suite 3103");
	    siteDetails.put("originalCity", "Denver");
	    siteDetails.put("originalState", "Colorado");
	    siteDetails.put("originalCountry", "United States");
	    siteDetails.put("originalZipcode", "80202");
	    siteDetails.put("updatedSiteNumber" , "82639881237");
	    siteDetails.put("updatedSiteName" , "ABC Company");
	    siteDetails.put("updatedAddress1" , "126-130 Regent Street");
	    siteDetails.put("updatedAddress2" , "5th Floor");
	    siteDetails.put("updatedCity", "London");
	    siteDetails.put("updatedState", "Greater London");
	    siteDetails.put("updatedCountry", "United Kingom");
	    siteDetails.put("updatedZipcode", "W1B5SE");
	    siteDetails.put("siteAddressChanged", "true");
	    siteDetails.put("productLocationChanged", "true");
	    siteDetails.put("instanceNumber", "123456s");
	    siteDetails.put("name", "flname");
		siteDetails.put("designation", "Employee");
		siteDetails.put("phone", "123456789");
		siteDetails.put("email","email");

	    
	    Map<String,Object> body = new HashMap<>();
		body.put("siteId", siteDetails.get("originalSiteNumber"));
		body.put("userName", userBean.getFlname());
		doNothing().when(httpStreamService).siteChangeEvent(body);
	    
		this.mockMvc.perform(post("/sitelocation")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(siteDetails))
				.requestAttr("USER_BEAN", userBean))
				.andExpect(status().isOk());
		
		verify(mailService, times(1)).sendUpdateSiteLocationMail(anyMap());
		verify(dvsAuditService, times(1)).insertAuditRecord(anyMap());
		verify(installBaseService, times(1)).insertSiteChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		verify(installBaseService, times(1)).insertProductChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		verify(httpStreamService).siteChangeEvent(body);
		
	}
	
	@Test
	public void testUpdateSiteLocationForDell() throws Exception {
		
		ObjectMapper mapper = new ObjectMapper();
		UserBean userBean = new UserBean();
		userBean.setIdentityType("E");
		userBean.setUid("12345");
		userBean.setLoginName("user1");
		userBean.setPhoneNumber("123456789");
		userBean.setEmail("email");
		userBean.setFlname("flname");
		
		Map<String, Object> siteDetails = new HashMap<>();
		siteDetails.put("serialNumber", "BRCAHX1941G02G");
	    siteDetails.put("productName", "Connectrix DS-5300B");
	    siteDetails.put("connectFlag", "Not Connected");
	    siteDetails.put("connectionType", "OTHER");
	    siteDetails.put("productAlias", "Test Alias");
	    siteDetails.put("originalSiteNumber" , "1234567899");
	    siteDetails.put("originalSiteName" , "XYZ Company");
	    siteDetails.put("originalAddress1" , "620 16th Street");
	    siteDetails.put("originalAddress2" , "Suite 3103");
	    siteDetails.put("originalCity", "Denver");
	    siteDetails.put("originalState", "Colorado");
	    siteDetails.put("originalCountry", "United States");
	    siteDetails.put("originalZipcode", "80202");
	    siteDetails.put("updatedSiteNumber" , "82639881237");
	    siteDetails.put("updatedSiteName" , "ABC Company");
	    siteDetails.put("updatedAddress1" , "126-130 Regent Street");
	    siteDetails.put("updatedAddress2" , "5th Floor");
	    siteDetails.put("updatedCity", "London");
	    siteDetails.put("updatedState", "Greater London");
	    siteDetails.put("updatedCountry", "United Kingom");
	    siteDetails.put("updatedZipcode", "W1B5SE");
	    siteDetails.put("siteAddressChanged", "true");
	    siteDetails.put("productLocationChanged", "true");
	    siteDetails.put("instanceNumber", "123456s");
	    siteDetails.put("name", "flname");
		siteDetails.put("designation", "Employee");
		siteDetails.put("phone", "123456789");
		siteDetails.put("email","email");
		siteDetails.put("identityType", "E");
		siteDetails.put("uid", "12345");
		siteDetails.put("flname", "flname");
		siteDetails.put("phoneNumber","123456789");
	    
	    Map<String,Object> body = new HashMap<>();
		body.put("siteId", siteDetails.get("originalSiteNumber"));
		body.put("userName", userBean.getFlname());
		doNothing().when(httpStreamService).siteChangeEvent(body);
	    
		this.mockMvc.perform(post("/sitelocation")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(siteDetails)))
				.andExpect(status().isOk());
		
		siteDetails.remove("identityType");
		siteDetails.remove("uid");
		siteDetails.remove("flname");
		siteDetails.remove("phoneNumber");
		
		verify(mailService, times(1)).sendUpdateSiteLocationMail(anyMap());
		verify(dvsAuditService, times(1)).insertAuditRecord(anyMap());
		verify(installBaseService, times(1)).insertSiteChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		verify(installBaseService, times(1)).insertProductChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		verify(httpStreamService).siteChangeEvent(body);
		
	}
	
	@Test
	public void testGetProductChangeEvent() throws Exception {
		Map<String, Object> productChangeEventMap = new HashMap<>();
		productChangeEventMap.put("locationChange", "[]");
		productChangeEventMap.put("contractRenewal", "[]");
		when(installBaseService.getProductChangeEvent(12345L)).thenReturn(productChangeEventMap);
		this.mockMvc.perform(get("/productchangeevent/12345")).andExpect(status().isOk());
		verify(installBaseService, times(1)).getProductChangeEvent(12345L);
	}
	
	@Test
	public void testGetChangesAndSubmissionsStats() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("instanceNumberIsIn", "198419011");
		
		Map<String, Object> changesStats=new HashMap<>();
		changesStats.put("aliasChangeCount", 6);
		changesStats.put("contractRenewalCount", 54);
		changesStats.put("locationChangeCount", 7);
		
		when(installBaseService.getChangesAndSubmissionsStats(filterParams)).thenReturn(changesStats);
		
		this.mockMvc.perform(get("/changesandsubmissionsstats")
			.param("instanceNumberIsIn", "198419011"))
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("\"aliasChangeCount\":6")))
			.andExpect(content().string(containsString("\"contractRenewalCount\":54")))
			.andExpect(content().string(containsString("\"locationChangeCount\":7")))
			.andDo(print());
		
		verify(installBaseService, times(1)).getChangesAndSubmissionsStats(filterParams);
	}
	
	
	@Test
	public void testGetChangesAndSubmissionsTimelineRangeEventCount() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("instanceNumberIsIn", "181935658");
		filterParams.put("tlvTimeRangeBefore", "1577750400000");
		filterParams.put("tlvTimeRangeAfter", "123292800000");
		Map<Long,Integer> timelineEvent = new HashMap<>();
		timelineEvent.put(1495670400000L, 1) ;
		timelineEvent.put(1496707200000L, 2) ;
		
		when(installBaseService.getChangesAndSubmissionTimelineRangeEventCount(filterParams)).thenReturn(timelineEvent);

		this.mockMvc.perform(post("/changesAndSubmission/timeline/timerange")
			.param("tlvTimeRangeBefore", "1577750400000")
			.param("tlvTimeRangeAfter", "123292800000")
			.param("instanceNumberIsIn", "181935658"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.1495670400000").value(1))
			.andExpect(jsonPath("$.1496707200000").value(2))
			.andReturn().getResponse().getContentAsString().equals(timelineEvent.toString());
		
		verify(installBaseService,times(1)).getChangesAndSubmissionTimelineRangeEventCount(filterParams);
	}

	@Test
	public void testInsertContractRenewalRecordForDell() throws Exception {
		UserBean userBean = new UserBean();
		userBean.setIdentityType("C");
		userBean.setUid("12345");
		userBean.setFlname("Firstname Lastname");
		
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("model", "ABC");
		contractDetails.put("serialNumber", "1000");
		contractDetails.put("dunsNumber", "1001");
		contractDetails.put("siteId", "1002");
		contractDetails.put("companyName", "PQR");
		contractDetails.put("contactName", "XYZ");
		contractDetails.put("contactPhone", "0123456789");
		contractDetails.put("contactEmail", "xyz@pqr.com");
		contractDetails.put("comments", "Test Comment");
		contractDetails.put("contractRenewalAction", "renewContract");
		contractDetails.put("siteAddress", "siteAddress");
		contractDetails.put("country", "country");
		contractDetails.put("theater", "theater");
		contractDetails.put("contractRequestType", "servicePlan");
		contractDetails.put("identityType", "C");
		contractDetails.put("uid", "12345");
		contractDetails.put("flname", "Firstname Lastname");
		ObjectMapper mapper = new ObjectMapper();

		this.mockMvc.perform(post("/renewcontract")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(contractDetails)))
				.andExpect(status().isOk());
		contractDetails.remove("identityType");
		contractDetails.remove("uid");
		contractDetails.remove("flname");
		verify(mailService, times(1)).sendContractRenewalMail(contractDetails);
		verify(installBaseService, times(1)).insertContractRenewalRecord(contractDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
	}
	
	
}
