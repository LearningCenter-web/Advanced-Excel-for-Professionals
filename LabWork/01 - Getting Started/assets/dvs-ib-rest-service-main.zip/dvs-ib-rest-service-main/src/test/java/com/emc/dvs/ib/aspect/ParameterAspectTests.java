package com.emc.dvs.ib.aspect;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.HttpClientErrorException;

import com.emc.dvs.ib.persistance.InstallBaseMapper;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class ParameterAspectTests {
	@InjectMocks
	private ParameterAspect aspect;

	@Mock
	private InstallBaseMapper mapper;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetCurrentPartitionIdBefore() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		
		when(mapper.getCurrentPartitions()).thenReturn(Arrays.asList("ib_p1", "component_p2","esa_p1","eta_p1"));
		aspect.addCurrentPartition(filterParams);
				
		assertEquals("1", filterParams.get("currentPartitionId"));
		assertEquals("ib_p1", filterParams.get("ibCurrentPartition"));
		assertEquals("component_p2", filterParams.get("componentCurrentPartition"));
		assertEquals("esa_p1", filterParams.get("esaPartition"));
		assertEquals("eta_p1", filterParams.get("etaPartition"));
		verify(mapper, times(1)).getCurrentPartitions();
	}
	@Test
    public void testValidateRequiredParameters_AllRequiredParamsPresent() {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("customerVisibilityIsIn", "exampleValue");
        filterParams.put("instanceNumberIsIn", "exampleValue");
        filterParams.put("siteNumberIsIn", "exampleValue");
        filterParams.put("orSerialNumber", "exampleValue");
        filterParams.put("andSiteNumber", "exampleValue");
        filterParams.put("serialNumberIsIn", "exampleValue");
        filterParams.put("tagIdIsIn", "exampleValue");
        filterParams.put("locationIdIsIn", "exampleValue");
        filterParams.put("preferredIdIsIn", "exampleValue");

        try {
        	aspect.validateRequiredParameters(filterParams);
        } catch (HttpClientErrorException ex) {
            fail("Should not throw an exception for valid parameters");
        }
    }
	@Test
    public void testValidateRequiredParameters_ValidParams() {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("serviceProviderIsIn", "exampleValue");

        try {
            aspect.validateRequiredParameters(filterParams);
        } catch (HttpClientErrorException ex) {
            fail("Should not throw an exception for valid parameters");
        }

        // Verify that no error message was logged or other interactions with external dependencies
        // You might need to use a logging framework or mock dependencies for this verification
    }
	@Test
    public void testValidateRequiredParameters_MissingParams() {
        Map<String, Object> filterParams = new HashMap<>();

        try {
            aspect.validateRequiredParameters(filterParams);
            fail("Should throw HttpClientErrorException for missing parameters");
        } catch (HttpClientErrorException ex) {
            // Expected behavior
            // You can verify the exception message or status code if needed
        }

        // Verify that an error message was logged or other interactions with external dependencies
        // You might need to use a logging framework or mock dependencies for this verification
    }
	@Test
    public void testValidateRequiredParameters_AllParamsPresent() {

        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("serviceProviderIsIn", "exampleValue");
        filterParams.put("customerVisibilityIsIn", "exampleValue");
        filterParams.put("instanceNumberIsIn", "exampleValue");
        filterParams.put("siteNumberIsIn", "exampleValue");
        filterParams.put("orSerialNumber", "exampleValue");
        filterParams.put("andSiteNumber", "exampleValue");
        filterParams.put("serialNumberIsIn", "exampleValue");
        filterParams.put("tagIdIsIn", "exampleValue");
        filterParams.put("locationIdIsIn", "exampleValue");
        filterParams.put("preferredIdIsIn", "exampleValue");

        try {
            aspect.validateRequiredParameters(filterParams);
        } catch (HttpClientErrorException ex) {
            fail("Should not throw an exception for valid parameters");
        }

        // Verify that no error message was logged or other interactions with external dependencies
        // You might need to use a logging framework or mock dependencies for this verification
    }
	
	@Test
	public void testValidParams() {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "212");
		aspect.validateRequiredParameters(filterParams);
	}
	
	@Test(expected=HttpClientErrorException.class)
	public void testInvalidParams() {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		aspect.validateRequiredParameters(filterParams);
	}
	@Test
	public void testValidateRequiredParameters_MissingSpecificParams() {
	    Map<String, Object> filterParams = new HashMap<>();
	    // Add other non-required parameters

	    try {
	        aspect.validateRequiredParameters(filterParams);
	        fail("Should throw HttpClientErrorException for missing specific parameters");
	    } catch (HttpClientErrorException ex) {
	        // Expected behavior
	        // You can verify the exception message or status code if needed
	    }

	    // Verify that an error message was logged or other interactions with external dependencies
	    // You might need to use a logging framework or mock dependencies for this verification
	}
	
}
