package com.emc.dvs.ib.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.ZoneOffset;

import org.junit.jupiter.api.Test;

public class CommonUtilsTests {

	public CommonUtilsTests() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Test
    public void testIsDateInBetween() {
        // Define some LocalDate values for testing
        LocalDate beforeDate = LocalDate.of(2023, 12, 31);
        LocalDate afterDate = LocalDate.of(2023, 1, 1); // Note the reversed order

        // Test when inputDate is null
        assertFalse(CommonUtils.isDateInBetween(beforeDate, afterDate, null, true));
        
        // Test when isTimeRangeExist is false, should always return true
        assertTrue(CommonUtils.isDateInBetween(beforeDate, afterDate, 1234567890L, false));
        
        // Test when inputDate is outside the range
        assertFalse(CommonUtils.isDateInBetween(beforeDate, afterDate, 1640995200000L, true)); // January 1, 2022
        
        // Test when inputDate is exactly equal to beforeDate
        assertTrue(CommonUtils.isDateInBetween(beforeDate, afterDate, beforeDate.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(), true));
        
        // Test when inputDate is exactly equal to afterDate
        assertTrue(CommonUtils.isDateInBetween(beforeDate, afterDate, afterDate.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(), true));
        
        // Test when inputDate is within the range
        assertTrue(CommonUtils.isDateInBetween(beforeDate, afterDate, 1696137600000L, true)); // June 1, 2023
    }
}
