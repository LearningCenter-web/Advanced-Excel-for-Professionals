package com.emc.dvs.ib.web;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClient.ResponseSpec;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.server.ResponseStatusException;

import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.KpiBean;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.Page;
import com.emc.dvs.ib.domain.PagedResponseBean;
import com.emc.dvs.ib.domain.SerializedResponseBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.exception.AdvisoriesException;
import com.emc.dvs.ib.service.AdvisoriesService;
import com.emc.dvs.ib.service.FilterParamsService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.netty.util.concurrent.Future;
import jakarta.servlet.http.HttpServletRequest;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class AdvisoriesControllerTests {

	@InjectMocks
	private AdvisoriesController controller;

	@Mock
	private AdvisoriesService advisoriesService;
	
	@Mock
	private HttpServletRequest request;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String content;
	
	private WebTestClient client;

	private MockMvc mockMvc;
	@Mock
	private FilterParamsService fliter;
	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
		ObjectMapper objectMapper = new ObjectMapper();
		client = WebTestClient.bindToController(new AdvisoriesController(advisoriesService, fliter)).build();
		LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel(Logger.ROOT_LOGGER_NAME, LogLevel.TRACE);
	}
	@Test
    public void testGetEsaTimelineStats_ExceptionHandling() throws Exception {
        Map<String, Object> filterParams = new HashMap<>();
        MockHttpServletRequest request = new MockHttpServletRequest();

        // Simulate an exception (e.g., InterruptedException)
        ExecutionException simulatedException = new ExecutionException(new InterruptedException("Simulated exception"));

        // Mock the advisoriesService to throw the exception
        CompletableFuture<Integer> future = new CompletableFuture<>();
        future.completeExceptionally(simulatedException);
        when(advisoriesService.getEsaEventsCount(filterParams)).thenReturn(future);

        // Verify that the catch block handles the exception
        try {
            controller.getEsaTimelineStats(filterParams, request);
        } catch (Exception ex) {
            // Verify that the caught exception is the same as the simulated exception
//        	  ex.printStackTrace();
        }
        
    }
	
	 @Test
	    public void testGetEsaAggregateWithLocationIdIsIn() throws InterruptedException {
	        // Arrange
	        Map<String, Object> filterParams = new HashMap<>();
	        filterParams.put("locationIdIsIn", "123");  // Include locationIdIsIn
	        // Add other required filterParams as needed

	        // Mock the advisoriesService to return the expected response
	        PagedResponseBean<AdvisoryBean> expectedResponse = new PagedResponseBean<>();
	        List<AdvisoryBean> expectedList = new ArrayList<>();
	        Page page = new Page(25, 0, 1, 0);
	        expectedResponse.setPage(page);
	        expectedResponse.setRows(expectedList);
	        when(advisoriesService.getEsaAggregate(filterParams)).thenAnswer(invocation -> {
	            // Create a PagedResponseBean<AdvisoryBean> and return it
	            PagedResponseBean<AdvisoryBean> response = new PagedResponseBean<>();
	            List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
	            // Populate esaAggBeanList with your data
	            response.setPage(new Page(25, 0, 1, 0));
	            response.setRows(esaAggBeanList);
	            return new AsyncResult<>(response);
	        });

	        // Act
	        PagedResponseBean<AdvisoryBean> result = controller.getEsaAggregate(filterParams, request);

	        // Assert
	        assertEquals(expectedResponse, result);
	    }
	 @Test
	    public void testGetEtaAggregateWithLocationIdIsIn() throws InterruptedException {
	        // Arrange
	        Map<String, Object> filterParams = new HashMap<>();
	        filterParams.put("locationIdIsIn", "123");  // Include locationIdIsIn
	        // Add other required filterParams as needed

	        // Mock the advisoriesService to return the expected response
	        PagedResponseBean<AdvisoryBean> expectedResponse = new PagedResponseBean<>();
	        List<AdvisoryBean> expectedList = new ArrayList<>();
	        Page page = new Page(25, 0, 1, 0);
	        expectedResponse.setPage(page);
	        expectedResponse.setRows(expectedList);
	        when(advisoriesService.getEtaAggregate(filterParams)).thenAnswer(invocation -> {
	            // Create a PagedResponseBean<AdvisoryBean> and return it
	            PagedResponseBean<AdvisoryBean> response = new PagedResponseBean<>();
	            List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
	            // Populate esaAggBeanList with your data
	            response.setPage(new Page(25, 0, 1, 0));
	            response.setRows(etaAggBeanList);
	            return new AsyncResult<>(response);
	        });

	        // Act
	        PagedResponseBean<AdvisoryBean> result = controller.getEsaAggregate(filterParams, request);

	        // Assert
	        assertEquals(expectedResponse, result);
	    }
	 @Test
	    public void testGetRemediationStatus_LocationIdIsInWithoutSiteNumberIsIn() {
	        Map<String, Object> filterParams = new HashMap<>();
	        filterParams.put("locationIdIsIn", "someValue");
	        MockHttpServletRequest request = new MockHttpServletRequest();

	        Map<String, Object> response = controller.getRemediationStatus(filterParams, request);

	        // Verify that the response contains "kpiCounts" with a KpiBean when locationIdIsIn is present
	        assertTrue(response.containsKey("kpiCounts"));
	        Object kpiCounts = response.get("kpiCounts");
	        assertTrue(kpiCounts instanceof KpiBean);

	        // Ensure that no additional keys are present
	        assertEquals(1, response.size());
	    }
	 @Test
	    public void testGetEtaRemediationStatusForKpiWithCondition() {
	        // Create filterParams with the necessary condition
	        Map<String, Object> filterParams = new HashMap<>();
	        filterParams.put("locationIdIsIn", "yourValue");

	        // Create a mock HttpServletRequest
	        MockHttpServletRequest request = new MockHttpServletRequest();

	        // Call the method and get the response
	        Map<String, Object> response = controller.getEtaRemediationStatusForKpi(filterParams, request);

	        // Verify that the condition is met and the response contains the expected data
	        Object kpi = response.get("kpiCounts");

	        // You can assert the kpi object or its properties based on your specific KpiBean implementation
	        // For example, if KpiBean has a property named 'value', you can assert it like this:
	        // assertEquals(expectedValue, ((KpiBean) kpi).getValue());

	        // Perform your assertions as needed
	    }

	@Test
	public void testGetEsaAggregate() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esaAggBean.setAge("433 days");
		esaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esaAggBean.setProductFamily("1");
		esaAggBean.setLastReviewedBy("User");
		esaAggBean.setLastUpdatedBy("User");
		esaAggBean.setLastReviewTime(1530774202);
		esaAggBean.setStatus("new");
		esaAggBean.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean.setPublished(1492086796000L);
		esaAggBean.setFirstPublished(1592086796000L);
		esaAggBean.setEmcProprietaryCode(null);
		esaAggBean.setUpdated(true);
		esaAggBean.setEmail("James.Mckenna@emc.com");

		esaAggBeanList.add(esaAggBean);
		when(advisoriesService.getEsaTotalRecord(filterParams)).thenReturn(new AsyncResult<Integer>(150));
		when(advisoriesService.getEsaAggregate(filterParams))
				.thenReturn(new AsyncResult<List<AdvisoryBean>>(esaAggBeanList));

		final String jsonresponse = "{\"page\":{\"size\":25,\"totalElements\":150,\"totalPages\":7,\"number\":1},\"rows\":[{\"products\":\"3\",\"title\":\"ESA-2015-025: EMC ProSphere Security Update for GNU";

		ResponseSpec response = this.client.post().uri("/srs")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.parseMediaType("text/csv"))
				.bodyValue(filterParams)
				.exchange();
		
		MvcResult result = this.mockMvc
				.perform(post("/esaAggregate").param("siteNumberIsIn", "7478|8691").param("size", "25")
						.param("number", "1").param("sortBy", "severity").param("sortDir", "desc"))
				.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))

				.andDo(print())
				.andReturn();
		String content = result.getResponse().getContentAsString();
		assertThat(content, containsString("\"age\":\"433 days\""));
		assertThat(content, containsString(
				"\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"]"));
		assertThat(content, containsString("\"productFamily\":\"1\""));
		assertThat(content, containsString(
				"\"cveIdList\":[\"CVE-2015-0458\",\"CVE-2015-0459\",\"CVE-2015-0460\",\"CVE-2015-0469\"]"));
		assertThat(content, containsString("\"published\":1492086796000"));
		assertThat(content, containsString("\"emcProprietaryCode\":null"));
		verify(advisoriesService, times(1)).getEsaAggregate(filterParams);

	}
	@Test
    public void testDownloadAffectedProductsETA() throws InterruptedException {
        // Mock your service to return valid data for ETA
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("advisoryType", "ETA");

        List<AffectedProductsBean> affectedProductsETA = Collections.singletonList(new AffectedProductsBean());
        List<Note> notesETA = Collections.singletonList(new Note());

        when(advisoriesService.getAffectedProducts(filterParams, "ETA")).thenReturn(CompletableFuture.completedFuture(affectedProductsETA));
        when(advisoriesService.getNotes(filterParams, "ETA")).thenReturn(CompletableFuture.completedFuture(notesETA));
        MockHttpServletResponse response = new MockHttpServletResponse();

        // Call the controller method
        Map<String, List> result = controller.downloadAffectedProducts(filterParams, request,response);
	}
	@Test
    public void testGetEtaAggregateValidParams() throws InterruptedException {
        // Prepare valid filterParams and request
        Map<String, Object> filterParams = new HashMap<>();
        HttpServletRequest request = mock(HttpServletRequest.class);
        filterParams.put("locationIdIsIn", "7478|8691");
        // Execute the method and assert the result
        PagedResponseBean<AdvisoryBean> result = controller.getEtaAggregate(filterParams, request);
        assertNotNull(result);
        // Add more assertions as needed
    }
	@Test
	public void testGetEtaAggregateInvalidParams() throws Exception {
	    // Prepare invalid filterParams and request
	    Map<String, Object> filterParams = new HashMap<>();
	    HttpServletRequest request = mock(HttpServletRequest.class);

	    // Get the private method using reflection
	    Method validateFilterParamsMethod = AdvisoriesController.class.getDeclaredMethod("validateFilterParams", Map.class);
	    validateFilterParamsMethod.setAccessible(true);
	    filterParams.put("locationIdIsIn", "7478|8691");
	    
	}
	@Test
	public void testGetEsaTimelineData() throws Exception{
		final Map<String, Object> filterParams = new LinkedHashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("sortBy", "firstPublished");
		filterParams.put("number", 0);
		filterParams.put("size", 25);
		filterParams.put("sortDir", "desc");
		List<TimelineEntity> timelineEntities = new ArrayList<>();		
		TimelineEntity esaEntity = new TimelineEntity();
		esaEntity.setEntityType("ESA");
		esaEntity.setTimeStamp(123456789L);
		esaEntity.setEntity(new HashMap());
		timelineEntities.add(esaEntity);
		
		when(advisoriesService.getEsaTimelineData(filterParams)).thenReturn(timelineEntities);
		
		final String jsonresponse = "[{\"entityType\":\"ESA\",\"timeStamp\":123456789,\"entity\":{}}]";
		
		this.mockMvc
		.perform(post("/esa/timeline").param("siteNumberIsIn", "7478|8691").param("sortBy", "firstPublished"))
		.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))
		.andDo(print());
		
		verify(advisoriesService, times(1)).getEsaTimelineData(filterParams);
	}
	
	
	@Test
	public void testGetEtaTimelineData() throws Exception{
		final Map<String, Object> filterParams = new LinkedHashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("sortBy", "firstPublished");
		filterParams.put("number", 0);
		filterParams.put("size", 25);
		filterParams.put("sortDir", "desc");
		List<TimelineEntity> timelineEntities = new ArrayList<>();		
		TimelineEntity etaEntity = new TimelineEntity();
		etaEntity.setEntityType("ETA");
		etaEntity.setTimeStamp(123456789L);
		etaEntity.setEntity(new HashMap());
		timelineEntities.add(etaEntity);
		
		when(advisoriesService.getEtaTimelineData(filterParams)).thenReturn(timelineEntities);
		
		final String jsonresponse = "[{\"entityType\":\"ETA\",\"timeStamp\":123456789,\"entity\":{}}]";
		
		this.mockMvc
		.perform(post("/eta/timeline").param("siteNumberIsIn", "7478|8691").param("sortBy", "firstPublished"))
		.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))
		.andDo(print());
		
		verify(advisoriesService, times(1)).getEtaTimelineData(filterParams);
	}

	@Test
	public void testGetEsaTimelineFilterStats() throws Exception {
		final Map<String, Object> filterParams = new LinkedHashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		
		when(advisoriesService.getEsaEventsCount(filterParams)).thenReturn(new AsyncResult<Integer>(150));
		
		final String jsonresponse = "{\"esaCount\":150}";
		
		this.mockMvc
			.perform(post("/esa/timeline/stats").param("siteNumberIsIn", "7478|8691"))
			.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))
			.andDo(print());
		
		verify(advisoriesService, times(1)).getEsaEventsCount(filterParams);
	}
	
	@Test
	public void testGetEtaTimelineFilterStats() throws Exception{
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		
		when(advisoriesService.getEtaEventsCount(filterParams)).thenReturn(new AsyncResult<Integer>(150));
		
		final String jsonresponse = "{\"etaCount\":150}";
		
		this.mockMvc
		.perform(post("/eta/timeline/stats").param("siteNumberIsIn", "7478|8691"))
		.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))
		.andDo(print());
		
		verify(advisoriesService, times(1)).getEtaEventsCount(filterParams);
	}
	
	@Test
	public void testMarkAsReviewd() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/markDsaAsReviewed").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).markDsaAsReviewed(filterParams, user);
	}

	@Test
	public void testMarkAsDisregarded() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/markDsaAsDisregarded").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).markDsaAsDisregarded(filterParams, user);
	}

	@Test
	public void testAffectedProducts() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("articleIdsIsIn", "kA3j0000000XZg0CAG");
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("advisoryType", "ESA");
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093218");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886583");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);
		final Note note1 = new Note();
		note1.setAdvisoryNote("test");
		note1.setInstanceId("1030093219");
		final Note note2 = new Note();
		note2.setInstanceId("1030093218");
		note2.setAdvisoryNote("test");
		final List<Note> notes = new ArrayList<>();
		notes.add(note1);
		notes.add(note2);
		when(advisoriesService.getAffectedProducts(filterParams, "ESA"))
				.thenReturn(new AsyncResult<List<AffectedProductsBean>>(products));
		when(advisoriesService.getNotes(filterParams, "ESA")).thenReturn(new AsyncResult<List<Note>>(notes));
		this.mockMvc
				.perform(post("/affectedProducts/kA3j0000000XZg0CAG").param("siteNumberIsIn", "7478|8691").param("articleIdsIsIn", "kA3j0000000XZg0CAG").param("advisoryType", "ESA"))
				.andExpect(status().isOk());
		verify(advisoriesService, times(1)).getAffectedProducts(filterParams, "ESA");
		verify(advisoriesService, times(1)).getNotes(filterParams, "ESA");
	}

	@Test
	public void testUpdateResolutionTracking() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15");
		filterParams.put("resolution", "Not Scheduled");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/resolutionTracking").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15")
						.param("resolution", "Not Scheduled").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).updateResolutionTracking(filterParams, user, "Not Scheduled");
	}

	@Test
	public void testRemediatedCounts() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ESA-2017-11|ESA-2017-19|ESA-2017-15");
		final KpiBean kpiBean = new KpiBean();
		kpiBean.setCompleteCount(17);
		kpiBean.setNewCount(36);
		kpiBean.setNotApplicableCount(13);
		kpiBean.setPendingCount(125);
		kpiBean.setRemediatedCount(4);
		kpiBean.setReviewedCount(64);
		kpiBean.setWorkInProgressCount(25);

		when(advisoriesService.getRemediationStatus(filterParams)).thenReturn(kpiBean);

		this.mockMvc.perform(post("/remediationStatus").param("siteNumberIsIn", "7478|8691").param("articleIdIsIn",
				"ESA-2017-11|ESA-2017-19|ESA-2017-15")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getRemediationStatus(filterParams);
	}
	

	@Test
	public void testAffectedProductsCounts() throws Exception {
		
		
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleStatusIsIn", "Complete");
		final List<AffectedProductsKpi> affectedProductsKpiBean = new ArrayList<>();
		final AffectedProductsKpi productCountEmea = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("EMEA");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		final AffectedProductsKpi productCountAsia = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("Asia");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		final AffectedProductsKpi productCountAmericas = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("Americas");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		affectedProductsKpiBean.add(productCountEmea);
		affectedProductsKpiBean.add(productCountAsia);
		affectedProductsKpiBean.add(productCountAmericas);
		filterParams.put("articleStatusIsIn", "Not Applicable|Remediated");
		when(advisoriesService.getAffectedProductsForKpi(filterParams)).thenReturn(affectedProductsKpiBean);

		this.mockMvc.perform(post("/affectedProductsForKpi").param("siteNumberIsIn", "7478|8691")
				.param("articleStatusIsIn", "Not Applicable|Remediated")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getAffectedProductsForKpi(filterParams);
	}

	@Test
	public void getEsas() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esaAggBean.setAge("433 days");
		esaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esaAggBean.setProductFamily("1");
		esaAggBean.setLastReviewedBy("User");
		esaAggBean.setLastUpdatedBy("User");
		esaAggBean.setLastReviewTime(1530774202);
		esaAggBean.setStatus("new");
		esaAggBean.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean.setPublished(1492086796000L);
		esaAggBean.setFirstPublished(1592086796000L);
		esaAggBean.setEmcProprietaryCode(null);
		esaAggBean.setUpdated(true);
		esaAggBean.setEmail("James.Mckenna@emc.com");

		esaAggBeanList.add(esaAggBean);
		when(advisoriesService.getEsaAggregate(filterParams))
				.thenReturn(new AsyncResult<List<AdvisoryBean>>(esaAggBeanList));

		String jsonresponse = "[{\"products\":\"3\",\"title\":\"ESA-2015-025: EMC ProSphere Security Update for GNU C";
		
		MvcResult result = this.mockMvc.perform(post("/esas").param("siteNumberIsIn", "7478|8691")).andExpect(status().isOk())
				.andExpect(content().string(containsString(jsonresponse)))
				.andDo(print())
				.andReturn();
		
		String content = result.getResponse().getContentAsString();
		assertThat(content, containsString("\"age\":\"433 days\""));
		assertThat(content, containsString(
				"\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"]"));
		assertThat(content, containsString("\"productFamily\":\"1\""));
		assertThat(content, containsString(
				"\"cveIdList\":[\"CVE-2015-0458\",\"CVE-2015-0459\",\"CVE-2015-0460\",\"CVE-2015-0469\"]"));
		assertThat(content, containsString("\"published\":1492086796000"));
		assertThat(content, containsString("\"emcProprietaryCode\":null"));
		verify(advisoriesService, times(1)).getEsaAggregate(filterParams);

	}
	

	@Test
	public void testGetEtaAggregate() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean etaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
		etaAggBean.setProducts("3");
		etaAggBean.setDocumentId("ETA 201502");
		etaAggBean.setSeverity("Critical");
		etaAggBean.setTitle("ETA 201502: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		etaAggBean.setAge("433 days");
		etaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		etaAggBean.setProductFamily("1");
		etaAggBean.setLastReviewedBy("User");
		etaAggBean.setLastUpdatedBy("User");
		etaAggBean.setLastReviewTime(1530774202);
		etaAggBean.setStatus("new");
		etaAggBean.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean.setPublished(1492086796000L);
		etaAggBean.setFirstPublished(1592086796000L);
		etaAggBean.setEmcProprietaryCode(null);
		etaAggBean.setUpdated(true);
		etaAggBean.setImpact(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		etaAggBean.setSeverityDescription("severity description");
		etaAggBean.setEmail("James.Mckenna@emc.com");

		etaAggBeanList.add(etaAggBean);
		when(advisoriesService.getEtaTotalRecord(filterParams)).thenReturn(new AsyncResult<Integer>(150));
		when(advisoriesService.getEtaAggregate(filterParams))
				.thenReturn(new AsyncResult<List<AdvisoryBean>>(etaAggBeanList));

		//final String jsonresponse = "{\"page\":{\"size\":25,\"totalElements\":150,\"totalPages\":7,\"number\":1},\"rows\":[{\"products\":\"3\",\"title\":\"ETA 201502: EMC ProSphere Security Update for GNU C Library \\\"GHOST\\\" Vulnerability\",\"documentId\":\"ETA 201502\",\"age\":\"433 days\",\"severity\":\"Critical\",\"productFamily\":\"1\",\"productFamilyList\":null,\"status\":\"new\",\"articleId\":\"kA3j0000000PEhrCAG\",\"published\":1492086796000,\"firstPublished\":1592086796000,\"updated\":true,\"siteNumber\":null,\"latitude\":null,\"longitude\":null,\"siteName\":null,\"city\":null,\"summary\":null,\"resolution\":\"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\\\n\\\\n\\\\n\\\\tEMC Documentum Content Server 7.0\\\\n\\\\n\\\\t\\\\n\\\\t\\\\tP20 and later (POODLE)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\tP21 and later  (Oracle JRE updates)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.1 P18 and later\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.2 P02 and later\\\\n\\\\t\\\\n\\\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.\",\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"],\"lastReviewedBy\":\"User\",\"lastReviewTime\":1530774202,\"lastUpdatedBy\":\"User\",\"lastUpdatedDate\":0,\"articleNumber\":null,\"cveIdList\":null,\"emcProprietaryCode\":null,\"impact\":\"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.\",\"severityDescription\":\"severity description\",\"email\":\"James.Mckenna@emc.com\",\"urlName\":null,\"newArticleNumber\":null,\"accessLevel\":null,\"lastPublishedDate\":null}]}";

		final String jsonresponse = "{\"page\":{\"size\":25,\"totalElements\":150";
		
		MvcResult result = this.mockMvc
				.perform(post("/etaAggregate").param("siteNumberIsIn", "7478|8691").param("size", "25")
						.param("number", "1").param("sortBy", "severity").param("sortDir", "desc"))
				.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))
				.andDo(print())
				.andReturn();
		String content = result.getResponse().getContentAsString();
		assertThat(content, containsString("\"age\":\"433 days\""));
		assertThat(content, containsString("\"severityDescription\":\"severity description\""));
		assertThat(content, containsString(
				"\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"]"));
		assertThat(content, containsString("\"productFamily\":\"1\""));
		assertThat(content, containsString(
				"\"impact\":\"The buffer overflow vulnerability in glibc"));
		assertThat(content, containsString("\"published\":1492086796000"));
		assertThat(content, containsString("\"emcProprietaryCode\":null"));
		verify(advisoriesService, times(1)).getEtaAggregate(filterParams);
	}

	@Test
	public void getEtas() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		final AdvisoryBean etaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
		etaAggBean.setProducts("3");
		etaAggBean.setDocumentId("ETA-2015-025");
		etaAggBean.setSeverity("Critical");
		etaAggBean.setTitle("ETA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		etaAggBean.setAge("433 days");
		etaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		etaAggBean.setProductFamily("1");
		etaAggBean.setLastReviewedBy("User");
		etaAggBean.setLastUpdatedBy("User");
		etaAggBean.setLastReviewTime(1530774202);
		etaAggBean.setStatus("new");
		etaAggBean.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean.setPublished(1492086796000L);
		etaAggBean.setFirstPublished(1592086796000L);
		etaAggBean.setEmcProprietaryCode(null);
		etaAggBean.setUpdated(true);
		etaAggBean.setImpact(null);
		etaAggBean.setSeverityDescription(null);
		etaAggBean.setEmail("James.Mckenna@emc.com");

		etaAggBeanList.add(etaAggBean);
		when(advisoriesService.getEtaAggregate(filterParams))
				.thenReturn(new AsyncResult<List<AdvisoryBean>>(etaAggBeanList));

		final String jsonresponse = "[{\"products\":\"3\",\"title\":\"ETA-2015-025: EMC ProSphere Security Update for GNU C Library \\\"GHOST\\\" Vulnerability\",\"documentId\":\"ETA-2015-025\",\"age\":\"433 days\",\"severity\":\"Critical\",\"productFamily\":\"1\",\"productFamilyList\":null,\"status\":\"new\",\"articleId\":\"kA3j0000000PEhrCAG\",\"published\":1492086796000,\"firstPublished\":1592086796000,\"updated\":true,\"siteNumber\":null,\"latitude\":null,\"longitude\":null,\"siteName\":null,\"city\":null,\"summary\":null,\"resolution\":\"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\\\n\\\\n\\\\n\\\\tEMC Documentum Content Server 7.0\\\\n\\\\n\\\\t\\\\n\\\\t\\\\tP20 and later (POODLE)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\tP21 and later  (Oracle JRE updates)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.1 P18 and later\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.2 P02 and later\\\\n\\\\t\\\\n\\\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.\",\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"],\"lastReviewedBy\":\"User\",\"lastReviewTime\":1530774202,\"lastUpdatedBy\":\"User\",\"lastUpdatedDate\":0,\"articleNumber\":null,\"cveIdList\":null,\"emcProprietaryCode\":null,\"impact\":null,\"severityDescription\":null,\"email\":\"James.Mckenna@emc.com\",\"urlName\":null,\"newArticleNumber\":null,\"accessLevel\":null,\"lastPublishedDate\":null}]";

		this.mockMvc.perform(post("/etas").param("siteNumberIsIn", "7478|8691")).andExpect(status().isOk())
				.andExpect(content().string(containsString(jsonresponse)))

				.andDo(print());
		assertThat(jsonresponse, containsString("\"age\":\"433 days\""));
		assertThat(jsonresponse, containsString(
				"\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"]"));
		assertThat(jsonresponse, containsString("\"productFamily\":\"1\""));
		assertThat(jsonresponse, containsString("\"published\":1492086796000"));
		assertThat(jsonresponse, containsString("\"emcProprietaryCode\":null"));
		verify(advisoriesService, times(1)).getEtaAggregate(filterParams);
	}

	@Test
	public void testDtaMarkAsReviewd() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ETA 2017111|ETA 2017193|ETA 2017152");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/markDtaAsReviewed").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ETA 2017111|ETA 2017193|ETA 2017152").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).markDtaAsReviewed(filterParams, user);
	}

	@Test
	public void testDtaMarkAsNotApplicable() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ETA 2017111|ETA 2017193|ETA 2017152");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/markDtaAsNotApplicable").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ETA 2017111|ETA 2017193|ETA 2017152").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).markDtaAsNotApplicable(filterParams, user);
	}

	@Test
	public void testEtaAffectedProducts() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("articleIdsIsIn", "kA3j0000000XZg0CAG");
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("advisoryType", "ETA");
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093218");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886583");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);
		final Note note1 = new Note();
		note1.setAdvisoryNote("test");
		note1.setInstanceId("1030093219");
		final Note note2 = new Note();
		note2.setInstanceId("1030093218");
		note2.setAdvisoryNote("test");
		final List<Note> notes = new ArrayList<>();
		notes.add(note1);
		notes.add(note2);
		when(advisoriesService.getAffectedProducts(filterParams,"ETA"))
				.thenReturn(new AsyncResult<List<AffectedProductsBean>>(products));
		when(advisoriesService.getNotes(filterParams, "ETA")).thenReturn(new AsyncResult<List<Note>>(notes));
		this.mockMvc
				.perform(post("/etaAffectedProducts/kA3j0000000XZg0CAG").param("siteNumberIsIn", "7478|8691").param("articleIdsIsIn", "kA3j0000000XZg0CAG").param("advisoryType", "ETA"))
				.andExpect(status().isOk());
		verify(advisoriesService, times(1)).getAffectedProducts(filterParams, "ETA");
		verify(advisoriesService, times(1)).getNotes(filterParams, "ETA");
	}

	@Test
	public void testEtaResolutionTracking() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ETA 2017111|ETA 2017196|ETA 2017151");
		filterParams.put("resolution", "Work-around Applied");
		final UserBean user = new UserBean();
		user.setEmail("email@dellemc.com");
		user.setUid("1234");
		this.mockMvc
				.perform(post("/etaResolutionTracking").param("siteNumberIsIn", "7478|8691")
						.param("articleIdIsIn", "ETA 2017111|ETA 2017196|ETA 2017151")
						.param("resolution", "Work-around Applied").requestAttr("USER_BEAN", user))
				.andExpect(status().isNoContent());
		verify(advisoriesService, times(1)).updateEtaResolutionTracking(filterParams, user, "Work-around Applied");
	}

	@Test
	public void testEtaRemediatedCounts() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleIdIsIn", "ETA 2017111|ETA 2017196|ETA 2017151");
		final KpiBean kpiBean = new KpiBean();
		kpiBean.setCompleteCount(17);
		kpiBean.setNewCount(36);
		kpiBean.setNotApplicableCount(13);
		kpiBean.setPendingCount(125);
		kpiBean.setRemediatedCount(4);
		kpiBean.setReviewedCount(64);
		kpiBean.setWorkInProgressCount(25);

		when(advisoriesService.getEtaRemediationStatusCount(filterParams)).thenReturn(kpiBean);

		this.mockMvc.perform(post("/etaRemediationStatusForKpi").param("siteNumberIsIn", "7478|8691")
				.param("articleIdIsIn", "ETA 2017111|ETA 2017196|ETA 2017151")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getEtaRemediationStatusCount(filterParams);
	}

	@Test
	public void testEtaAffectedProductsCounts() throws Exception {

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("articleStatusIsIn", "Complete");
		final List<AffectedProductsKpi> affectedProductsKpiBean = new ArrayList<>();
		final AffectedProductsKpi productCountEmea = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("EMEA");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		final AffectedProductsKpi productCountAsia = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("Asia");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		final AffectedProductsKpi productCountAmericas = new AffectedProductsKpi();
		productCountEmea.setCritical("50");
		productCountEmea.setMedium("50");
		productCountEmea.setRegion("Americas");
		productCountEmea.setLow("50");
		productCountEmea.setHigh("50");
		affectedProductsKpiBean.add(productCountEmea);
		affectedProductsKpiBean.add(productCountAsia);
		affectedProductsKpiBean.add(productCountAmericas);
		filterParams.put("articleStatusIsIn", "Not Applicable|Remediated");
		when(advisoriesService.getEtaAffectedProductsForKpi(filterParams)).thenReturn(affectedProductsKpiBean);

		this.mockMvc.perform(post("/etaAffectedProductsForKpi").param("siteNumberIsIn", "7478|8691")
				.param("articleStatusIsIn", "Not Applicable|Remediated")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getEtaAffectedProductsForKpi(filterParams);
	}

	@Test
	public void testEsaDownloadAdvisories() throws Exception {
		final List<String> sites = Arrays.asList("12345", "67890");
		final Map<String, Object> filterParams = new HashMap<String, Object>();

		filterParams.putIfAbsent("sortBy", "severity");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.put("siteIdsIn", String.join(",", sites));
		filterParams.put("srStatusIsIn", "open");
		filterParams.put("columns", "{\"columns\":[{\"title\":\"Advisory ID\",\"field\":\"advisoryId\"}]}");
		final UserBean userBean = new UserBean();
		userBean.setUid("uid");
		userBean.setIdentityType("P");
		userBean.setLoginName("loginName");
		userBean.setSessionId("sessionId");

		doNothing().when(advisoriesService).getEsaAggregate(Mockito.any(), Mockito.any(), Mockito.any());

		this.mockMvc.perform(post("/esaAggregate").param("siteIdsIn", "12345,67890").param("sortBy", "severity")
				.param("sortDir", "desc")
				.param("columns", "{\"columns\":[{\"title\":\"Advisory ID\",\"field\":\"advisoryId\"}]}")
				.requestAttr("USER_BEAN", userBean).accept("text/csv")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getEsaAggregate(Mockito.any(), Mockito.any(), Mockito.any());
		verifyNoMoreInteractions(advisoriesService);
	}

	@Test
	public void testEtaDownloadAdvisories() throws Exception {
		final List<String> sites = Arrays.asList("12345", "67890");
		final Map<String, Object> filterParams = new HashMap<String, Object>();

		filterParams.putIfAbsent("sortBy", "severity");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.put("siteIdsIn", String.join(",", sites));
		filterParams.put("srStatusIsIn", "open");
		filterParams.put("columns", "{\"columns\":[{\"title\":\"Advisory ID\",\"field\":\"advisoryId\"}]}");
		final UserBean userBean = new UserBean();
		userBean.setUid("uid");
		userBean.setIdentityType("P");
		userBean.setLoginName("loginName");
		userBean.setSessionId("sessionId");

		doNothing().when(advisoriesService).getEtaAggregate(Mockito.any(), Mockito.any(), Mockito.any());

		this.mockMvc.perform(post("/etaAggregate").param("siteIdsIn", "12345,67890").param("sortBy", "severity")
				.param("sortDir", "desc")
				.param("columns", "{\"columns\":[{\"title\":\"Advisory ID\",\"field\":\"advisoryId\"}]}")
				.requestAttr("USER_BEAN", userBean).accept("text/csv")).andExpect(status().isOk());

		verify(advisoriesService, times(1)).getEtaAggregate(Mockito.any(), Mockito.any(), Mockito.any());
		verifyNoMoreInteractions(advisoriesService);
	}


	@Test
	public void getEtaDetailTest() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("advisoryType", "ETA");
		final AdvisoryBean etaAggBean = new AdvisoryBean();
		etaAggBean.setProducts("3");
		etaAggBean.setDocumentId("ETA-2015-025");
		etaAggBean.setSeverity("Critical");
		etaAggBean.setTitle("ETA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		etaAggBean.setAge("433 days");
		etaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		etaAggBean.setProductFamily("1");
		etaAggBean.setLastReviewedBy("User");
		etaAggBean.setLastUpdatedBy("User");
		etaAggBean.setLastReviewTime(1530774202);
		etaAggBean.setStatus("new");
		etaAggBean.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean.setPublished(1492086796000L);
		etaAggBean.setFirstPublished(1592086796000L);
		etaAggBean.setEmcProprietaryCode(null);
		etaAggBean.setUpdated(true);
		etaAggBean.setImpact(null);
		etaAggBean.setSeverityDescription(null);
		etaAggBean.setEmail(null);
		when(advisoriesService.getAdvisoryDetail(filterParams)).thenReturn(etaAggBean);

		final String jsonresponse = "{\"products\":\"3\",\"title\":\"ETA-2015-025: EMC ProSphere Security Update for GNU C Library \\\"GHOST\\\" Vulnerability\",\"documentId\":\"ETA-2015-025\",\"age\":\"433 days\",\"severity\":\"Critical\",\"productFamily\":\"1\",\"productFamilyList\":null,\"status\":\"new\",\"articleId\":\"kA3j0000000PEhrCAG\",\"published\":1492086796000,\"firstPublished\":1592086796000,\"updated\":true,\"siteNumber\":null,\"latitude\":null,\"longitude\":null,\"siteName\":null,\"city\":null,\"summary\":null,\"resolution\":\"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\\\n\\\\n\\\\n\\\\tEMC Documentum Content Server 7.0\\\\n\\\\n\\\\t\\\\n\\\\t\\\\tP20 and later (POODLE)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\tP21 and later  (Oracle JRE updates)\\\\n\\\\t\\\\t\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.1 P18 and later\\\\n\\\\t\\\\n\\\\tEMC Documentum Content Server 7.2 P02 and later\\\\n\\\\t\\\\n\\\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.\",\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"],\"lastReviewedBy\":\"User\",\"lastReviewTime\":1530774202,\"lastUpdatedBy\":\"User\",\"lastUpdatedDate\":0,\"articleNumber\":null,\"cveIdList\":null,\"emcProprietaryCode\":null,\"impact\":null,\"severityDescription\":null,\"email\":null,\"urlName\":null,\"newArticleNumber\":null,\"accessLevel\":null,\"lastPublishedDate\":null}";

		this.mockMvc
				.perform(post("/getAdvisoryDetails").param("siteNumberIsIn", "7478|8691").param("advisoryType", "ETA"))
				.andExpect(status().isOk()).andExpect(content().string(containsString(jsonresponse)))

				.andDo(print());
		assertThat(jsonresponse, containsString("\"age\":\"433 days\""));
		assertThat(jsonresponse, containsString(
				"\"productName\":[\"VNX5200\",\"VNX5400\",\"VNX5600\",\"VNX5800\",\"VNX7600\",\"VNX8000\",\"VNX VG50\"]"));
		assertThat(jsonresponse, containsString("\"productFamily\":\"1\""));
		assertThat(jsonresponse, containsString("\"published\":1492086796000"));
		assertThat(jsonresponse, containsString("\"emcProprietaryCode\":null"));
		verify(advisoriesService, times(1)).getAdvisoryDetail(filterParams);
	}
	@Test
    public void testGetAdvisoriesSummary() throws InterruptedException, ExecutionException {
        // Create test data for the filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("dateAfter", "2023-01-01");
        filterParams.put("dateBefore", "2023-12-31");

        // Create a list of AdvisoriesSummary instances to simulate the result
        List<AdvisoriesSummary> dtaSummaryList = new ArrayList<>();
        AdvisoriesSummary dtaSummary1 = new AdvisoriesSummary(/* Initialize with required data */);
        AdvisoriesSummary dtaSummary2 = new AdvisoriesSummary(/* Initialize with required data */);
        dtaSummaryList.add(dtaSummary1);
        dtaSummaryList.add(dtaSummary2);

        List<AdvisoriesSummary> dsaSummaryList = new ArrayList<>();
        AdvisoriesSummary dsaSummary1 = new AdvisoriesSummary(/* Initialize with required data */);
        AdvisoriesSummary dsaSummary2 = new AdvisoriesSummary(/* Initialize with required data */);
        dsaSummaryList.add(dsaSummary1);
        dsaSummaryList.add(dsaSummary2);

        // Create CompletableFutures to simulate the asynchronous behavior
        CompletableFuture<List<AdvisoriesSummary>> dtaFuture = new CompletableFuture<>();
        dtaFuture.complete(dtaSummaryList);

        CompletableFuture<List<AdvisoriesSummary>> dsaFuture = new CompletableFuture<>();
        dsaFuture.complete(dsaSummaryList);

        // Mock the behavior of advisoriesService methods
        Mockito.when(advisoriesService.getEsaSummary(any())).thenReturn(dsaFuture);
        Mockito.when(advisoriesService.getEtaSummary(any())).thenReturn(dtaFuture);

        try {
            // Call the method you want to test
            Map<String, Object> result = controller.getAdvisoriesSummary(filterParams, request);

            // Verify the result
            assertEquals(dtaSummaryList, result.get("technicalAdvisories"));
            assertEquals(dsaSummaryList, result.get("securityAdvisories"));
        } catch (InterruptedException ex) {
            // Handle exceptions if needed.
        }
    }
	@Test
    public void testGetNonEntitledEsaDetails() throws InterruptedException, ExecutionException {
        // Create test data for the filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("orServicePlanLevelNotIn", "SomeValue");

        // Create a list of AdvisoriesHud instances to simulate the result
        List<AdvisoriesHud> advisoriesList = new ArrayList<>();
        AdvisoriesHud hud1 = new AdvisoriesHud();
        hud1.setArticles("5");
        AdvisoriesHud hud2 = new AdvisoriesHud();
        hud2.setArticles("3");
        advisoriesList.add(hud1);
        advisoriesList.add(hud2);

        // Create a CompletableFuture to simulate the asynchronous behavior
        CompletableFuture<List<AdvisoriesHud>> dsaFuture = new CompletableFuture<>();
        dsaFuture.complete(advisoriesList);

        // Mock the behavior of advisoriesService method
        Mockito.when(advisoriesService.getDsaHud(any())).thenReturn(dsaFuture);

        try {
            // Call the method you want to test
            int result = controller.getNonEntitledEsaDetails(filterParams, request);

            // Verify the result
            assertEquals(8, result);
        } catch (InterruptedException ex) {
            // Handle exceptions if needed.
        }
    }
	@Test
    public void testGetNonEntitledEtaDetails() throws InterruptedException, ExecutionException {
        // Create test data for the filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("orServicePlanLevelNotIn", "SomeValue");

        // Create a list of AdvisoriesHud instances to simulate the result
        List<AdvisoriesHud> advisoriesList = new ArrayList<>();
        AdvisoriesHud hud1 = new AdvisoriesHud();
        hud1.setArticles("5");
        AdvisoriesHud hud2 = new AdvisoriesHud();
        hud2.setArticles("3");
        advisoriesList.add(hud1);
        advisoriesList.add(hud2);

        // Create a CompletableFuture to simulate the asynchronous behavior
        CompletableFuture<List<AdvisoriesHud>> dtaFuture = new CompletableFuture<>();
        dtaFuture.complete(advisoriesList);

        // Mock the behavior of advisoriesService method
        Mockito.when(advisoriesService.getDtaHud(any())).thenReturn(dtaFuture);

        try {
            // Call the method you want to test
            int result = controller.getNonEntitledEtaDetails(filterParams, request);

            // Verify the result
            assertEquals(8, result);
        } catch (InterruptedException ex) {
            // Handle exceptions if needed.
        }
    }
	@Test
    public void testGetAdvisoriesCount() throws InterruptedException, ExecutionException {
        // Create test data for the filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("dateAfter", "2023-01-01");
        filterParams.put("dateBefore", "2023-12-31");

        // Create CompletableFuture instances to simulate the asynchronous behavior
        CompletableFuture<Integer> dsaFuture = new CompletableFuture<>();
        CompletableFuture<Integer> dtaFuture = new CompletableFuture<>();
        dsaFuture.complete(10); // Set the result for dsaFuture
        dtaFuture.complete(20); // Set the result for dtaFuture

        // Mock the behavior of advisoriesService methods
        Mockito.when(advisoriesService.getEsaTotalRecord(any())).thenReturn(dsaFuture);
        Mockito.when(advisoriesService.getEtaTotalRecord(any())).thenReturn(dtaFuture);

        try {
            // Call the method you want to test
            Map<String, Integer> response = controller.getAdvisoriesCount(filterParams, request);

            // Verify the response
            assertEquals(10, response.get("dsa").intValue());
            assertEquals(20, response.get("dta").intValue());
        } catch (InterruptedException ex) {
            // Handle exceptions if needed.
        }
    }
	@Test
	public void testGetHudDetailsWithFutureData() throws InterruptedException, ExecutionException {
	    // Arrange
	    HttpServletRequest request = mock(HttpServletRequest.class);
	    Map<String, Object> filterParams = new HashMap<>();

	    // Mocking advisoriesService to return Future with some data
	    List<AdvisoriesHud> mockData = new ArrayList<>();
	    Future<List<AdvisoriesHud>> dsa = mock(Future.class);
	    Future<List<AdvisoriesHud>> dta = mock(Future.class);
	    
	    // Mock isDone and get methods for dsa and dta
	    when(dsa.isDone()).thenReturn(true);
	    when(dta.isDone()).thenReturn(true);
	    when(dsa.get()).thenReturn(mockData);
	    when(dta.get()).thenReturn(mockData);
	    
	    when(advisoriesService.getDsaHud(filterParams)).thenReturn(dsa);
	    when(advisoriesService.getDtaHud(filterParams)).thenReturn(dta);

	    // Act
	    Map<String, List<AdvisoriesHud>> result = controller.getHudDetails(filterParams, request);

	    // Assert
	    // Add assertions to check if the result matches your expectations
	    // You should compare result with the expected values based on your mock data
	}
	@Test
    public void testGetHudDetailsWithFilters() throws InterruptedException, ExecutionException {
        // Arrange
        HttpServletRequest request = mock(HttpServletRequest.class);
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("locationIdIsIn", "someValue");

        // Act
        Map<String, List<AdvisoriesHud>> result = controller.getHudDetails(filterParams, request);

        // Assert
        // Add assertions to check if the result matches your expectations
        assertEquals(4, result.get("technicalAdvisories").size()); // Assuming it always creates 4 items
        assertEquals(4, result.get("securityAdvisories").size()); // Assuming it always creates 4 items
    }
	@Test
    public void testGetNotesForSerializedProduct() throws InterruptedException, ExecutionException {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "exampleAdvisoryType";

        // Mock advisoriesService to return Future with some data
        List<IpsNote> mockData = new ArrayList<>();
        Future<List<IpsNote>> notesList = mock(Future.class);
        when(advisoriesService.getNotesForSerializedProduct(filterParams, advisoryType)).thenReturn(notesList);
        when(notesList.get()).thenReturn(mockData);

        // Act
        List<IpsNote> result = controller.getNotesForSerializedProduct(filterParams, advisoryType);

        // Assert
        // Add assertions to check if the result matches your expectations
        assertNotNull(result);
        assertEquals(mockData, result);
    }
	@Test
    public void testGetNotesForSerializedProductSuccess() throws InterruptedException, ExecutionException {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "SomeAdvisoryType";
        List<IpsNote> notes = new ArrayList<>();

        // Create IpsNote instances and add them to the list
        IpsNote note1 = new IpsNote();
        note1.setNtId("1");
        
        // Set other properties as needed
        notes.add(note1);

        IpsNote note2 = new IpsNote();
        note2.setNtId("2");
        // Set other properties as needed
        notes.add(note2);
        Future<List<IpsNote>> notesList = Mockito.mock(Future.class);

        // Mock behavior
        Mockito.when(advisoriesService.getNotesForSerializedProduct(filterParams, advisoryType)).thenReturn(notesList);
        Mockito.when(notesList.get()).thenReturn(notes);

        // Act
        List<IpsNote> result = controller.getNotesForSerializedProduct(filterParams, advisoryType);

        // Assert
        // Make assertions to verify the correctness of the result
        // For example, compare the expectedNotes with the result
        assertEquals(notes, result);
    }

    @Test
    public void testAddNotesWithoutResolutionUpdated() throws IOException {
        // Arrange
        Map<String, Object> filterParams = createFilterParamsWithNotesAndResolutionUpdated(false);
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        UserBean userBean = new UserBean();
        userBean.setEmail("test@example.com");

        // Mock behavior
        Mockito.when(request.getAttribute("USER_BEAN")).thenReturn(userBean);

        // Act
        controller.addNotes(filterParams, request);

        // Assert
        // Make assertions to verify the behavior based on your requirements
        // For example, you can verify that processResolutionTracking was not called
        // and that the appropriate log messages were generated
    }
    

    // Helper method to create filter parameters with notes and resolutionUpdated values
    private Map<String, Object> createFilterParamsWithNotesAndResolutionUpdated(boolean resolutionUpdated) {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("notes", "Test note content");
        filterParams.put("isResolutionUpdated", Boolean.toString(resolutionUpdated));
        return filterParams;
    }
    @Test
    public void testDownloadEsaAggregateWithInvalidFilterParams() throws IOException {
        // Create invalid filter parameters
        Map<String, Object> filterParams = new HashMap<>();
        final Map<String, String> columns = new LinkedHashMap<>();
        filterParams.put("invalidParam", "value");
        filterParams.put("sortBy", "invalid-sort-value");
        filterParams.put("sortDir", "asc");
        MockHttpServletResponse response = new MockHttpServletResponse();
        // Define your expected exception
        ResponseStatusException exception = new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid request payload");

        // Mock the behavior of advisoriesService to throw the expected exception
        doThrow(exception).when(advisoriesService).getEsaAggregate(any(OutputStream.class), eq(filterParams), any());

        // Call the downloadEsaAggregate method and assert that it throws the expected exception
        try {
            controller.downloadEsaAggregate(filterParams, request, response);
        } catch (ResponseStatusException e) {
            // Check if the thrown exception matches the expected exception
            assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
            assertEquals("Invalid  request payload", e.getReason());
        }
        Mockito.verify(advisoriesService, never()).getEsaAggregate(any(OutputStream.class), eq(filterParams), any());
    }
    @Test(expected = AdvisoriesException.class)
    public void testGetAdvisoriesForSerializedProduct_MissingAdvisoryType() throws InterruptedException {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        when(request.getAttribute("USER_BEAN")).thenReturn(new UserBean());

        // Act
        controller.getAdvisoriesForSerializedProduct(filterParams, null, request);

        // No need for assertions as the expected result is an exception
    }
    
    @Test
    public void testGetAdvisoriesSummaryWithLocationIdButNoSiteNumber() throws InterruptedException {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("locationIdIsIn", "your_location_id"); // Simulate the condition
        HttpServletRequest request = mock(HttpServletRequest.class);
        List<String> emptyList = Collections.emptyList();
        
        when(request.getAttribute("USER_BEAN")).thenReturn(new UserBean()); // Set a valid userBean
        
        // Act
        Map<String, Object> result = controller.getAdvisoriesSummary(filterParams, request);

        // Assert
        assertNotNull(result);
        assertEquals(emptyList, result.get("technicalAdvisories"));
        assertEquals(emptyList, result.get("securityAdvisories"));
    }
 
    @Test
    public void testValidateFilterParams() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
       
        // Prepare parameters to be tested
        Map<String, Object> validParams = new HashMap<>();
        validParams.put("sortBy", "valid,value");
        validParams.put("sortDir", "asc");

        Map<String, Object> invalidParams = new HashMap<>();
        invalidParams.put("sortBy", "invalid value");
        invalidParams.put("sortDir", "invalid");

        // Get the private method for testing using reflection
        Method validateFilterParamsMethod = AdvisoriesController.class.getDeclaredMethod("validateFilterParams", Map.class);
        validateFilterParamsMethod.setAccessible(true); // Allow invoking private method

        // Test the method with valid parameters
        boolean isValidValidParams = (boolean) validateFilterParamsMethod.invoke(controller, validParams);
        assertTrue(isValidValidParams);

        // Test the method with invalid parameters
        boolean isValidInvalidParams = (boolean) validateFilterParamsMethod.invoke(controller, invalidParams);
        assertFalse(isValidInvalidParams);
    }
    
    @Test
    public void testAddNotesWithResolutionUpdated() throws Exception {
        // Mock data
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("notes", "Test Note");
        filterParams.put("isResolutionUpdated", "true"); // Assuming it's a string representation of boolean
        filterParams.put("resolutionCode", "ABC123");
        filterParams.put("instanceSiteMap", "[{\"role\": \"Partner\"}]");
        filterParams.put("advisoryType", "ETA");
        filterParams.put("resolution", "Not Scheduled");
        
        HttpServletRequest request = mock(HttpServletRequest.class);
        UserBean userBean = new UserBean();
        userBean.setEmail("test@example.com");

        when(request.getAttribute("USER_BEAN")).thenReturn(userBean);

        // Call the method to test
        controller.addNotes(filterParams, request);

        // Assertions
        verify(advisoriesService).addNotes(filterParams, userBean); // Ensure addNotes is called
        verifyProcessResolutionTrackingInvoked(filterParams, userBean); // Ensure processResolutionTracking is called
    }

    private void verifyProcessResolutionTrackingInvoked(Map<String, Object> filterParams, UserBean userBean) throws Exception {
        // Use reflection to invoke the private method processResolutionTracking
        Method privateMethod = AdvisoriesController.class.getDeclaredMethod("processResolutionTracking", Map.class, UserBean.class);
        privateMethod.setAccessible(true);
        privateMethod.invoke(controller, filterParams, userBean);

        // Add assertions based on the expected behavior of processResolutionTracking
    }
    @Test
    public void testGetNotesForSerializedProductWhenAdvisoryTypeIsNull() throws InterruptedException, ExecutionException {
        // Create test data
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = null;

        // Mock behavior of advisoriesService
        Future<List<IpsNote>> mockNotesList = mock(Future.class);
        when(advisoriesService.getNotesForSerializedProduct(filterParams, null)).thenReturn(mockNotesList);

        // Test the method
        AdvisoriesException exception = assertThrows(AdvisoriesException.class, () ->
                controller.getNotesForSerializedProduct(filterParams, advisoryType));

        // Verify the exception
        assertEquals("advisoryType is required: ", exception.getMessage());
    }
}
