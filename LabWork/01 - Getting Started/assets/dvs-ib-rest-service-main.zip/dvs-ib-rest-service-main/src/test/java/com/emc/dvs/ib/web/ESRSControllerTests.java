package com.emc.dvs.ib.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsChangeEventBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.persistance.InstallBaseMapper;
import com.emc.dvs.ib.service.InstallBaseService;
import com.emc.dvs.ib.service.InstallBaseServiceImpl;
import com.emc.dvs.ib.util.SiteRelationService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class ESRSControllerTests {
	
	@InjectMocks
	private InstallBaseServiceImpl installBaseServiceImpl;
	
	@Mock
	private InstallBaseService installBaseService;
	
	@Mock
	private InstallBaseMapper installBaseMapper;
	
	@Mock
	private SiteRelationService siteRelationService;
	
	
	@Mock
	private HttpServletRequest request;
		
	private MockMvc mockMvc;
	
	
	@InjectMocks
	private ESRSController controller;
	
	ObjectMapper objectMapper = new ObjectMapper();
	
	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel(Logger.ROOT_LOGGER_NAME, LogLevel.TRACE);
	}
	
	@Test
	public void testUpdateGatewayClusterAlias() throws Exception{
		
		Map<String, Object> aliasDetails = new HashMap<>();
		aliasDetails.put("Product_Alias", "Test Alias");
		aliasDetails.put("id", "ABCDE123");
		aliasDetails.put("siteNumber", "123456");
		aliasDetails.put("action", "ADD");
		aliasDetails.put("isCluster", false);
		
		Map<String,Object> relationshipType = new HashMap<>();
		relationshipType.put("relationship", "HIERARCHY");
		
		List<EsrsBean> esrsBeanList = new ArrayList<>();
		EsrsBean aliasBean = new EsrsBean();
		aliasBean.setAlias("Test Device Alias");
		esrsBeanList.add(aliasBean);
		
		EsrsChangeEventBean esrsChangeEventBean = new EsrsChangeEventBean();
		esrsChangeEventBean.setId("123FGGQ666");
		esrsChangeEventBean.setData("{\"aliasChange\":[{\"uid\":\"12345\",\"alias\":\"Test Alias Name\",\"updatedBy\":\"User Name\",\"updatedOn\":1498217713502,\"relationshipType\":\"E\",\"userIdentityType\":\"E\",\"action\":\"ADD\",\"clusterConnection\":false}]}");
		
		//Mockito.when(crmSiteService.getRelationshipType("12345", "123456")).thenReturn(relationshipType);
		
		Mockito.when(installBaseMapper.getEsrsData(Mockito.anyString())).thenReturn(esrsBeanList);
		
		Mockito.when(installBaseMapper.getEsrsChangeEvent(Mockito.anyMap())).thenReturn(Arrays.asList(esrsChangeEventBean));
		
		doNothing().when(installBaseMapper).updateEsrsData(Mockito.anyString(), Mockito.anyString());
		
		doNothing().when(installBaseMapper).updateEsrsChangeEvent(Mockito.anyString(), Mockito.anyString());
		Mockito.when(siteRelationService.getSiteRelationShip(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn("C");
		installBaseServiceImpl.insertAliasChangeForESRS(aliasDetails, "12345", "Firstname Lastname", "C");
		
		//verify(crmSiteService, times(2)).getRelationshipType("12345", "123456");
		
		verify(installBaseMapper, times(1)).getEsrsData("ABCDE123");
		
		
	}
	
	@Test
	public void testInsertGatewayClusterAlias() throws Exception{
		
		Map<String, Object> aliasDetails = new HashMap<>();
		aliasDetails.put("alias", "Test Alias");
		aliasDetails.put("id", "ABCDE123");
		aliasDetails.put("siteNumber", "123456");
		aliasDetails.put("action", "ADD");
		aliasDetails.put("isCluster", true);
		
		Map<String,Object> relationshipType = new HashMap<>();
		relationshipType.put("relationship", "HIERARCHY");
		
		//Mockito.when(crmSiteService.getRelationshipType("12345", "123456")).thenReturn(relationshipType);
		
		Mockito.when(installBaseMapper.getEsrsData(Mockito.anyString())).thenReturn(null);
		
		Mockito.when(installBaseMapper.getEsrsChangeEvent(Mockito.anyMap())).thenReturn(new ArrayList<>());
		
		doNothing().when(installBaseMapper).insertEsrsdata(Mockito.anyString(), Mockito.anyString());
		
		doNothing().when(installBaseMapper).insertEsrsChangeEvent(Mockito.anyString(), Mockito.anyString());
		Mockito.when(siteRelationService.getSiteRelationShip(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn("C");
				
		installBaseServiceImpl.insertAliasChangeForESRS(aliasDetails, "12345", "Firstname Lastname", "C");
		
		//verify(crmSiteService, times(2)).getRelationshipType("12345", "123456");
		
		verify(installBaseMapper, times(1)).getEsrsData("ABCDE123");
		
	}
	
	@Test
	public void testGetDeviceAlias() throws Exception {
		EsrsBean aliasBean = new EsrsBean();
		aliasBean.setAlias("Test Device Alias");
		Map<String, Object> deviceAliasFilterParams = new HashMap<>();
		deviceAliasFilterParams.put("deviceId", "123456");
		
		Map<String, EsrsBean> esrsBeanMap = new HashMap<>();
		esrsBeanMap.put("123456", aliasBean);
		
		when(installBaseService.getEsrsData(deviceAliasFilterParams)).thenReturn(esrsBeanMap);
		this.mockMvc.perform(get("/esrs")
			.param("deviceId", "123456"))
			.andExpect(status().isOk());
		verify(installBaseService, times(1)).getEsrsData(deviceAliasFilterParams);
	}
	
	@Test
	public void testGetEsrsTimelineData() throws Exception{
		
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "ELMESR0816CF8G");
		filterParams.put("size", 10);
		
		Map<String, Object> aliasChange = new HashMap<>();
		aliasChange.put("uid", "1024169");
		aliasChange.put("alias", "Test 111 Edit Alias");
		aliasChange.put("action", "UPDATE");
		aliasChange.put("lastUpdatedBy", " ");
		aliasChange.put("updatedOn", 1548052842842L);
		aliasChange.put("relationshipType", "E");
		aliasChange.put("userIdentityType", "E");
		aliasChange.put("clusterConnection", false);
		
		List<Map<String, Object>> listOfAliasChange = new ArrayList<>();
		listOfAliasChange.add(aliasChange);
		
		Map<String, Object> changeEvents = new HashMap<>();
		changeEvents.put("aliasChange", listOfAliasChange);
		
		when(installBaseService.getEsrsChangeEvent(filterParams)).thenReturn(Arrays.asList(changeEvents));
		
		this.mockMvc.perform(get("/esrs/timeline")
				.param("deviceId", "ELMESR0816CF8G")
				.param("size", "10"))
				.andExpect(status().isOk());
		verify(installBaseService, times(1)).getEsrsChangeEvent(filterParams);
		
		
	}
	
	@Test
	public void testGetEsrsAliasChange() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "gateway");
		
		when(installBaseService.getEsrsAliasChangeCount(filterParams)).thenReturn(10L);
		
		MvcResult result = this.mockMvc.perform(get("/esrsalias/count")
				.param("deviceId", "gateway"))
				.andReturn();
		
		long actual = objectMapper.readValue(result.getResponse().getContentAsString(), Long.class);
		assertEquals(10L, actual);
	}
	
	@Test
	public void testDownloadNicknameChangeData() throws Exception{
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("deviceId", "ELM4ZP4VCWBTSK");
		filterParams.put("columns", "{\r\n" + 
				"	\"columns\": [{\r\n" + 
				"		\"title\": \"New Nickname\",\r\n" + 
				"		\"field\": \"newAlias\"\r\n" + 
				"	}, {\r\n" + 
				"		\"title\": \"Name\",\r\n" + 
				"		\"field\": \"userName\"\r\n" + 
				"	}, {\r\n" + 
				"		\"title\": \"Update Date\",\r\n" + 
				"		\"field\": \"updateDate\"\r\n" + 
				"	}]\r\n" + 
				"}");
			this.mockMvc.perform(post("/downloadNicknameChangeData").param("columns", "{\"columns\":[{\"title\":\"New Nickname\",\"field\":\"newAlias\"},{\"title\":\"Name\",\"field\":\"userName\"},{\"title\":\"Update Date\",\"field\":\"updateDate\"}]} ").param("deviceId", "ELM4ZP4VCWBTSK"))
				.andExpect(status().isOk()).andExpect(content().contentType("txt/csv"));
	}
	
	@Test
	public void testGetTridentConnectHomeEvents() throws Exception{
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", "10");
		filterParams.put("deviceId", "ELMESR0816CF8G");
		
		Map<String, Object> connectHomeEvent = new HashMap<>();
		connectHomeEvent.put("connectDate", 1568745000000L);
		connectHomeEvent.put("serialNumber", "ELMESR0816CF8G");
		connectHomeEvent.put("connectTime", 18355000);
		connectHomeEvent.put("connectDateTime", 1568783155000L);
		connectHomeEvent.put("startTime", 1568783155000L);
		connectHomeEvent.put("productName", "POWERSTORE");
		
		List<Map<String, Object>> connectHomeEventsList = new ArrayList<>();
		connectHomeEventsList.add(connectHomeEvent);
		
		when(installBaseService.getTridentConnectHomeEvents(filterParams)).thenReturn(connectHomeEventsList);
		
		this.mockMvc.perform(get("/trident/connecthome")
				.param("size", "10")
		        .param("deviceId", "ELMESR0816CF8G"))
		        .andExpect(status().isOk());
		verify(installBaseService, times(1)).getTridentConnectHomeEvents(filterParams);
	}
	
	@Test
	public void testGetTridentAggregateResponse() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", "10");
		filterParams.put("deviceId", "ELM6CXJH7111G1");
		
		EsrsDeviceGatewaysBean esrsBean = new EsrsDeviceGatewaysBean();
		
		esrsBean.setClusterGroupName("SERVICE PLANNING - SVT HA Gateways S12Y");
		esrsBean.setGatewayModelName("ESRS-VE");
		esrsBean.setClusterId("10953");
		esrsBean.setGatewayId("ELM6CXJH7111G1");
		List<String> gatwayStatuses = new ArrayList<>();
		gatwayStatuses.add("Online");
		esrsBean.setGatewayDeviceStatuses(gatwayStatuses);
		List<String> esrsVersions = new ArrayList<>();
		esrsVersions.add("3.32.00.08");
		esrsBean.setEsrsVersions(esrsVersions);
		
		when(installBaseService.getTridentAggregateResponse(filterParams)).thenReturn(esrsBean);
		
		this.mockMvc.perform(get("/trident")
				.param("size", "10")
		        .param("deviceId", "ELM6CXJH7111G1"))
		        .andExpect(status().isOk());
		verify(installBaseService, times(1)).getTridentAggregateResponse(filterParams);
	}
	
	@Test
	public void testGetTridentConnectedDevices() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", "10");
		filterParams.put("deviceId", "ELM6CXJH7111G1");
		
		Map<String, Object> tridentDevice = new HashMap<>();
		tridentDevice.put("serialNumber", "FNM00175100036");
		tridentDevice.put("gatewayId", "ELM6CXJH7111G1");
		tridentDevice.put("productName", "POWERSTORE");
		tridentDevice.put("deviceStatus", "Online");
		tridentDevice.put("esrsVersion", "3.32.00.08");
		
		List<Map<String, Object>> tridentDeviceList = new ArrayList<>();
		tridentDeviceList.add(tridentDevice);
		
		when(installBaseService.getTridentConnectedDevices(filterParams)).thenReturn(tridentDeviceList);
		
		this.mockMvc.perform(get("/trident/devices")
				.param("size", "10")
		        .param("deviceId", "ELM6CXJH7111G1"))
		        .andExpect(status().isOk());
		verify(installBaseService, times(1)).getTridentConnectedDevices(filterParams);
	}
	
	@Test
	public void testGetTridentInstallBaseResponse() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("serialNumberIsIn", "8HX1BW2");
		
		Map<String, Object> response = new HashMap<>();
		response.put("serialNumber", "8HX1BW2");
		response.put("gatewayDeviceStatusList", "Missing");
		response.put("lastConnectHomeDate", "1573249820");
		response.put("deviceStatus", "Online");
		response.put("esrsVersion", "3.32.00.08");
		
		when(installBaseService.getTridentInstallBaseResponse(filterParams)).thenReturn(response);
		
		this.mockMvc.perform(get("/trident/ib")
		        .param("serialNumberIsIn", "8HX1BW2"))
		        .andExpect(status().isOk());
		verify(installBaseService, times(1)).getTridentInstallBaseResponse(filterParams);
	}
	
	@Test(expected = ServletException.class)
	public void testGetTridentInstallBaseResponseBadRequest() throws Exception {
		
		this.mockMvc.perform(get("/trident/ib"))
			.andExpect(status().isBadRequest());
	}
	
	@Test
	public void testGetTridentInstallBaseResponseMulti() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("serialNumberIsIn", "8HX1BW2|H9P42W2");
		
		Map<String, Object> response1 = new HashMap<>();
		response1.put("serialNumber", "8HX1BW2");
		response1.put("gatewayDeviceStatusList", "Missing");
		response1.put("lastConnectHomeDate", "2020-06-01 18:00:47");
		response1.put("deviceStatus", "Online");
		response1.put("esrsVersion", "3.32.00.08");
		
		Map<String, Object> response2 = new HashMap<>();
		response2.put("serialNumber", "H9P42W2");
		response2.put("gatewayDeviceStatusList", "Online");
		response2.put("lastConnectHomeDate", "2020-06-01 18:00:47");
		response2.put("deviceStatus", "Missing");
		response2.put("esrsVersion", "3.32.00.08");
		
		when(installBaseService.getTridentInstallBaseResponseMulti(filterParams)).thenReturn(Arrays.asList(response1, response2));
		
		this.mockMvc.perform(get("/trident/ib/multi")
		        .param("serialNumberIsIn", "8HX1BW2|H9P42W2"))
		        .andExpect(status().isOk());
		verify(installBaseService, times(1)).getTridentInstallBaseResponseMulti(filterParams);
	}
	
	@Test(expected = ServletException.class)
	public void testGetTridentInstallBaseResponseBadRequestMulti() throws Exception {
		
		this.mockMvc.perform(get("/trident/ib/multi"))
			.andExpect(status().isBadRequest());
	}
	@Test
    public void testInsertConnectHomeData() {
        // Prepare sample data for filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("param1", "value1");
        filterParams.put("param2", "value2");

        // Mock behavior of the installBaseService
        Mockito.doNothing().when(installBaseService).insertConnectHomeData(any());

        // Call the method you want to test
        controller.insertConnectHomeData(filterParams, request);

        // Verify that installBaseService.insertConnectHomeData was called with the expected parameters
        Mockito.verify(installBaseService, Mockito.times(1)).insertConnectHomeData(any());
    }
	@Test
    public void testInsertConnectHomeDataWithEmptyData() {
        Map<String, Object> filterParams = new HashMap<>();
        HttpServletRequest request = mock(HttpServletRequest.class);

        doNothing().when(installBaseService).insertConnectHomeData(filterParams);

        ResponseEntity<String> response = controller.insertConnectHomeData(filterParams, request);

        verify(installBaseService, never()).insertConnectHomeData(filterParams);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
	@Test
    public void testUpdateConnectHomeDataWithValidParams() {
        // Prepare sample data for filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("param1", "value1");
        filterParams.put("param2", "value2");

        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Mock behavior of installBaseService
        Mockito.doNothing().when(installBaseService).updateConnectHomeData(any());

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateConnectHomeData(filterParams, request);

        // Verify that installBaseService.updateConnectHomeData was called with the expected parameters
        Mockito.verify(installBaseService, Mockito.times(1)).updateConnectHomeData(filterParams);

        // Verify that the response is an HTTP 200 (OK) response
        assertEquals(ResponseEntity.ok().build(), responseEntity);
    }

    @Test
    public void testUpdateConnectHomeDataWithEmptyParams() {
        // Test the case when filterParams is empty
        Map<String, Object> filterParams = new HashMap<>();
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateConnectHomeData(filterParams, request);

        // Verify that the response is an HTTP 400 (Bad Request) response
        assertEquals(ResponseEntity.badRequest().build(), responseEntity);

        // Ensure that installBaseService.updateConnectHomeData is not called
        Mockito.verify(installBaseService, Mockito.never()).updateConnectHomeData(any());
    }
    @Test
    public void testUpdateDeviceOrGatewayDataWithValidParams() {
        // Prepare sample data for filterParams (a list of maps)
        List<Map<String, Object>> filterParams = new ArrayList<>();
        Map<String, Object> params1 = new HashMap<>();
        params1.put("param1", "value1");
        Map<String, Object> params2 = new HashMap<>();
        params2.put("param2", "value2");
        filterParams.add(params1);
        filterParams.add(params2);

        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Mock behavior of installBaseService
        Mockito.doNothing().when(installBaseService).updateGatewayData(any());

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateDeviceOrGatewayData(filterParams, request);

        // Verify that installBaseService.updateGatewayData was called with the expected parameters
        Mockito.verify(installBaseService, Mockito.times(1)).updateGatewayData(filterParams);

        // Verify that the response is an HTTP 200 (OK) response
        assertEquals(ResponseEntity.ok().build(), responseEntity);
    }

    @Test
    public void testUpdateDeviceOrGatewayDataWithEmptyParams() {
        // Test the case when filterParams is an empty list
        List<Map<String, Object>> filterParams = new ArrayList<>();
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateDeviceOrGatewayData(filterParams, request);

        // Verify that the response is an HTTP 400 (Bad Request) response
        assertEquals(ResponseEntity.badRequest().build(), responseEntity);

        // Ensure that installBaseService.updateGatewayData is not called
        Mockito.verify(installBaseService, Mockito.never()).updateGatewayData(any());
    }
    @Test
    public void testUpdateDeviceStatusWithValidParams() {
        // Prepare sample data for filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("param1", "value1");
        filterParams.put("param2", "value2");

        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Mock behavior of installBaseService
        Mockito.doNothing().when(installBaseService).upsertEsrsDeviceStatus(any());

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateDeviceStatus(filterParams, request);

        // Verify that installBaseService.upsertEsrsDeviceStatus was called with the expected parameters
        Mockito.verify(installBaseService, Mockito.times(1)).upsertEsrsDeviceStatus(filterParams);

        // Verify that the response is an HTTP 200 (OK) response
        assertEquals(ResponseEntity.ok().build(), responseEntity);
    }

    @Test
    public void testUpdateDeviceStatusWithEmptyParams() {
        // Test the case when filterParams is empty
        Map<String, Object> filterParams = new HashMap<>();
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Call the method you want to test
        ResponseEntity<String> responseEntity = controller.updateDeviceStatus(filterParams, request);

        // Verify that the response is an HTTP 400 (Bad Request) response
        assertEquals(ResponseEntity.badRequest().build(), responseEntity);

        // Ensure that installBaseService.upsertEsrsDeviceStatus is not called
        Mockito.verify(installBaseService, Mockito.never()).upsertEsrsDeviceStatus(any());
    }
	
    @Test
    public void testGetGatewayIdsWithinAClusterWithValidParams() {
        // Prepare sample data for filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("deviceId", "cluster123");

        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Mock behavior of installBaseService
        String expectedResult = "Gateway1, Gateway2, Gateway3";
        Mockito.when(installBaseService.getGatewayIdsWithinACluster(filterParams)).thenReturn(expectedResult);

        // Call the method you want to test
        String result = controller.getGatewayIdsWithinACluster(filterParams, request);

        // Verify that installBaseService.getGatewayIdsWithinACluster was called with the expected parameters
        Mockito.verify(installBaseService, Mockito.times(1)).getGatewayIdsWithinACluster(filterParams);

        // Verify that the method returns the expected result
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetGatewayIdsWithinAClusterWithMissingDeviceId() {
        // Test the case when the "deviceId" parameter is missing from filterParams
        Map<String, Object> filterParams = new HashMap<>();
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        // Call the method you want to test
        String result = controller.getGatewayIdsWithinACluster(filterParams, request);

        // Verify that the result is an empty string
        assertNull(result);

        // Ensure that installBaseService.getGatewayIdsWithinACluster is not called
        Mockito.verify(installBaseService).getGatewayIdsWithinACluster(any());
    }
    @Test
    public void testEditAliasForESRS() {
        // Prepare test data
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("key1", "value1");
        requestMap.put("key2", "value2");

        UserBean userBean = new UserBean();
        userBean.setUid("user123");
        userBean.setFlname("John Doe");
        userBean.setIdentityType("admin");

        // Mock the HttpServletRequest and its attributes
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute("USER_BEAN", userBean);

        // Mock the behavior of the installBaseService (void method)
        doNothing().when(installBaseService).insertAliasChangeForESRS(any(), anyString(), anyString(), anyString());

        // Call the controller method
        controller.editAliasForESRS(requestMap, request);

        // Verify that the installBaseService method was called with the expected arguments
        verify(installBaseService).insertAliasChangeForESRS(eq(requestMap), eq(userBean.getUid()), eq(userBean.getFlname()), eq(userBean.getIdentityType()));
    }
    @Test
    public void testGetEsrsTimeRangeStats() {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("key", "value");

        HttpServletRequest request = new MockHttpServletRequest();
        HttpServletResponse response = new MockHttpServletResponse();

        Map<Long, Integer> expectedStats = new HashMap<>();
        expectedStats.put(123L, 5);
        expectedStats.put(456L, 10);

        when(installBaseService.getServiceEventsTimeRangeAliasChangeCount(filterParams)).thenReturn(expectedStats);

        Map<Long, Integer> result = controller.getEsrsTimeRangeStats(filterParams, request, response);

        // Verify that the method from the service was called
        // You can use more specific verification based on your implementation

        assertEquals(expectedStats, result);
    }
}
