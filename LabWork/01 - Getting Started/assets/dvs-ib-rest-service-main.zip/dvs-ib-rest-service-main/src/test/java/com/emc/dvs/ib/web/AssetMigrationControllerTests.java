package com.emc.dvs.ib.web;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.emc.dvs.ib.service.InstallBaseService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
@AutoConfigureMockMvc
public class AssetMigrationControllerTests {

    @InjectMocks
    private AssetMigrationController controller;

    @Mock
    private InstallBaseService installBaseService;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel(Logger.ROOT_LOGGER_NAME, LogLevel.TRACE);
    }

    @Test
    public void testMoveSsdataToPgsql() throws Exception {
        List<Object> sampleData = new ArrayList<>();
      
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(sampleData);

        mockMvc.perform(post("/singleSerialization/assetMigration")
            .contentType(MediaType.APPLICATION_JSON)
            .content(json))
            .andExpect(status().isOk())
            .andExpect(content().string("Asset data move to pgsql (asset_ss and IB_)  tables transferred successfully."));
    }
}

