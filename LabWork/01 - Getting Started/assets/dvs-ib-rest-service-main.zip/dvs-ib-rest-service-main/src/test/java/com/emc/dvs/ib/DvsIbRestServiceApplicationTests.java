package com.emc.dvs.ib;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Repeat;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.StopWatch;

import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.persistance.InstallBaseMapper;
import com.emc.dvs.ib.service.InstallBaseService;

@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
@ActiveProfiles({"dev", "local"})
public class DvsIbRestServiceApplicationTests {
	
	@Autowired
	InstallBaseService installBaseService;
	
	@Autowired
	InstallBaseMapper mapper;
	
	@Test
	public void contextLoads() {
	}
	
	@Ignore
	@Test
	public void testGetComponents() {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("cpsdSerialNumber", "V98FN1318006");
		String q = "a_b";
		q = q.replaceAll("_", "\\\\_");
		filterParams.put("searchIsLike", q);
		System.out.println(filterParams);
		filterParams.put("componentCurrentPartition", "component_p2");
		List<ComponentBean> result = installBaseService.getSolutionComponents(filterParams);
		System.out.println(result.size());
	}
	@Test
	public void testRestTemplate()
	{
		DvsIbRestServiceApplication obj =new DvsIbRestServiceApplication();
		obj.restTemplate();
	}
	@Ignore
	@Repeat(5)
	@Test
	public void testGetStats() throws Exception {
		List<String> sites = Arrays.asList("4252425","7815730","27929238","66971","10318580","2458212","8327360","7649252","8798740","1331999","1793906","3637772","1839668","1003815674","28075951","64955","1332434","2260199","2236359","4206202","27929449","7356251","9860320","1003817078","4168793","2451497","4050352","2547806","27897442","1003810723","14213918","39046","67311","4192684","12768995","2876397","15447207","14385623","27871274","28079070","6899465","8929716","28079089","123048","123462","2451577","1330604","7651335","4339361","11693712","7671294","1003815413","2800322","4220749","4483016","1332608","4194656","1003815929","65088","8766119","27774392","3994847","2451545","12888778","1003815898","4130734","1003815421","1003817084","1003817563","15491243","2765517","10026323","123146","1786247","2876449","5043099","66628","8982091","3641715","13328978","6812039","1788100","58797","8246970","3628401","1003815409","7594237","27955592","2765592","1793490","2856351","1793802","27895960","1003815699","1794479","1788026","1786099","2856198","8848035","4271695","27897439","90444","4208760","8844965","1785581","2451561","3870735","1794323","14292295","2458158","50315","7389688","2852813","15564783","4118319","4315844","2451529","4188659","1003815432","9095814","78143","604340","5505565","7496851","5165896","8768433","9711","27897393","1331387","2259215","8353784","67076","1794011","1330865","2876004","24521491","13553538","6274367","28030646","26140876","12529393","1003807218","14299514","28079051","9128672","5257672","11584889","63245","27931600","4301116","1795365","1003815670","14298762","2765567","1795729","14538371","2533461","1003815665","5260515","7786675","63113","28075996","27951100","14570256","30160798","9064731","1003815669","1003815478","1794999","27890506","14292393");
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", String.join("|", sites));
		StopWatch sw = new StopWatch();
		sw.start();
		Future<List<InstallBaseGeoBean>> geo = installBaseService.getInstallBaseGeoDetails(filterParams);
		Future<InstallBaseStatsBean> stats = installBaseService.getInstallBaseStats(filterParams);
		while(! geo.isDone()) {
			Thread.sleep(10);
		}
		sw.stop();
		System.out.println("Done:" + sw.getLastTaskTimeMillis());
		System.out.println(geo.get());
		System.out.println(stats.get());
	}
	
	@Ignore
	@Repeat(5)
	@Test
	public void testGetProducts() throws Exception {
		List<String> sites = Arrays.asList("4252425","7815730","27929238","66971","10318580","2458212","8327360","7649252","8798740","1331999","1793906","3637772","1839668","1003815674","28075951","64955","1332434","2260199","2236359","4206202","27929449","7356251","9860320","1003817078","4168793","2451497","4050352","2547806","27897442","1003810723","14213918","39046","67311","4192684","12768995","2876397","15447207","14385623","27871274","28079070","6899465","8929716","28079089","123048","123462","2451577","1330604","7651335","4339361","11693712","7671294","1003815413","2800322","4220749","4483016","1332608","4194656","1003815929","65088","8766119","27774392","3994847","2451545","12888778","1003815898","4130734","1003815421","1003817084","1003817563","15491243","2765517","10026323","123146","1786247","2876449","5043099","66628","8982091","3641715","13328978","6812039","1788100","58797","8246970","3628401","1003815409","7594237","27955592","2765592","1793490","2856351","1793802","27895960","1003815699","1794479","1788026","1786099","2856198","8848035","4271695","27897439","90444","4208760","8844965","1785581","2451561","3870735","1794323","14292295","2458158","50315","7389688","2852813","15564783","4118319","4315844","2451529","4188659","1003815432","9095814","78143","604340","5505565","7496851","5165896","8768433","9711","27897393","1331387","2259215","8353784","67076","1794011","1330865","2876004","24521491","13553538","6274367","28030646","26140876","12529393","1003807218","14299514","28079051","9128672","5257672","11584889","63245","27931600","4301116","1795365","1003815670","14298762","2765567","1795729","14538371","2533461","1003815665","5260515","7786675","63113","28075996","27951100","14570256","30160798","9064731","1003815669","1003815478","1794999","27890506","14292393");
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", String.join("|", sites));
		StopWatch sw = new StopWatch();
		sw.start();
		Future<List<ConnectivityProductBean>> products = installBaseService.getConnectivityList(filterParams);
		while(! products.isDone()) {
			Thread.sleep(10);
		}
		sw.stop();
		System.out.println("Done:" + sw.getLastTaskTimeMillis());
		//System.out.println(products.get());
			
	}
	
	@Ignore
	@Test
	public void testGetProduct() {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "G084120070L");
		filterParams.put("currentPartitionId", "2");
		ProductBean p = installBaseService.getProductDetail(filterParams);
		System.out.println(p);
	}

}
