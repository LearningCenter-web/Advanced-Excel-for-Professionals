package com.emc.dvs.ib.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import com.emc.dvs.export.domain.ColumnWrapper;
import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.KpiBean;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.SerializedAdvisoryEvent;
import com.emc.dvs.ib.domain.SerializedProductBean;
import com.emc.dvs.ib.domain.SerializedResponseBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.persistance.AdvisoriesMapper;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class AdvisoriesServiceImplTest {

	@InjectMocks
	private AdvisoriesServiceImpl service;

	@Mock
	private AdvisoriesMapper mapper;

	@Captor
	private ArgumentCaptor<Map<String, Object>> filtersCaptor;
	
	@Mock
    private SubscriptionDetailsService subscriptionDetailsService;
	
	@Mock
    private UserBean user;
	
	@Mock
	private JdbcTemplate template;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	private MockHttpServletResponse response;

	private final ObjectMapper objMapper = new ObjectMapper();

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		service.request= request;
	}

	private List<String> getSiteList() {
		final List<String> sites = new ArrayList<String>();
		sites.add("1234");
		sites.add("5678");
		sites.add("9012");
		sites.add("3456");
		return sites;
	}
//	@Test
//    public void testUpdateResolutionTracking() {
//        Map<String, Object> filterParams = new HashMap<>();
//        UserBean user = new UserBean();
//        String resolution = "SomeResolution";
//
//        List<Map<String, Object>> esaInstanceMaps = new ArrayList<>();
//        // Add sample data to esaInstanceMaps
//        
//        when(mapper.getEsaInstanceMap(filterParams)).thenReturn(esaInstanceMaps);
//        when(mapper.getEsaMarkAsReviewedCount(filterParams)).thenReturn(0);
//
//        service.updateResolutionTracking(filterParams, user, resolution);
//
//        // Verify that advisoriesMapper methods were called
//        verify(mapper, times(1)).getEsaInstanceMap(filterParams);
//        verify(mapper, times(1)).getEsaMarkAsReviewedCount(filterParams);
//
//        // You can also add more specific verifications based on your actual implementation
//
//        // Assert that user's attributes have been set as expected
//        Assertions.assertEquals("userEmail", user.getEmail());
//        Assertions.assertEquals("userName", user.getFlname());
//        Assertions.assertEquals("SomeResolution", user.getIdentityType());
//
//        // You can add more assertions based on your actual implementation
//    }
	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetEsaAggregate() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esaAggBean.setAge("433 days");
		esaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esaAggBean.setProductFamily("1");
		esaAggBean.setLastReviewedBy("User");
		esaAggBean.setLastUpdatedBy("User");
		esaAggBean.setLastReviewTime(1530774202);
		esaAggBean.setStatus("new");
		esaAggBean.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean.setPublished(1492086796000L);
		esaAggBean.setEmcProprietaryCode(null);
		esaAggBean.setUpdated(true);
		esaAggBeanList.add(esaAggBean);

		when(mapper.getEsaAggregate(anyMap())).thenReturn(esaAggBeanList);
		final List<AdvisoryBean> actual = service.getEsaAggregate(filterParams).get();
		assertNotNull(actual);
		verify(mapper, times(1)).getEsaAggregate(filtersCaptor.capture());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetEsaEventsCount() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		
		when(mapper.getEsaEventsCount(anyMap())).thenReturn(1);
		final Integer actual = service.getEsaEventsCount(filterParams).get();
		assertNotNull(actual);
		verify(mapper, times(1)).getEsaEventsCount(filtersCaptor.capture());
	}
	
//	@Test
//    public void testGetETASerializedTotalRecord() {
//        // Arrange
//        Map<String, Object> filterParams = new HashMap<>();
//        filterParams.put("articleStatusIsIn", "SomeValue");
//        filterParams.put("severityFilterIsIn", "Low|Medium");
//
//        // Mock the behavior of advisoriesMapper
//        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(42);
//
//        // Act
//        Integer result = mapper.getETASerializedTotalRecord(filterParams);
//
//        // Assert
//        assertEquals(42, result.intValue());
//    }
	@SuppressWarnings("unchecked")
	@Test
	public void testGetEtaEventsCount() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		
		when(mapper.getEtaEventsCount(anyMap())).thenReturn(1);
		final Integer actual = service.getEtaEventsCount(filterParams).get();
		assertNotNull(actual);
		verify(mapper, times(1)).getEtaEventsCount(filtersCaptor.capture());
	}
//	@Test
//    public void testUpdateResolutionTrackingWhenSerializedIsTrue() {
//        // Create test data
//        Map<String, Object> filterParams = new HashMap<>();
//        UserBean user = new UserBean();
//        filterParams.put("isSerialized", "true");
//        filterParams.put("instanceSiteMap", "Your JSON String");
//        filterParams.put("email", "user@example.com");
//        filterParams.put("userName", "John Doe");
//
//        // Mock the behavior of advisoriesMapper methods
//        Mockito.when(mapper.getEsaMarkAsReviewedCount(filterParams)).thenReturn(0); // Assuming it should be 0
//
//        // Invoke the method to test
//        service.updateResolutionTracking(filterParams, user, "Your Resolution");
//
//        // Add assertions to verify the expected behavior
//        Mockito.verify(mapper, Mockito.times(1)).getEsaMarkAsReviewedCount(filterParams);
//        // Add more assertions based on the expected behavior
//    }
//	@Test
//	public void testUpdateEtaResolutionTracking() throws JsonMappingException, JsonProcessingException {
//        // Prepare test data
//        Map<String, Object> filterParams = new HashMap<>();
//        UserBean user = new UserBean();
//        String resolution = "YourResolution";
//        filterParams.put("isSerialized", "true");
//        filterParams.put("instanceSiteMap", "[{\"instanceId\":\"107776391459\",\"role\":\"PARTNER\"},{\"instanceId\":\"106607266401\",\"role\":\"PARTNER\"}]"); 
//        filterParams.put("resolution", "Scheduled For Action");
//        List<InstanceSiteMap> instanceSiteRoleMap = new ArrayList<>();
//        instanceSiteRoleMap.add(new InstanceSiteMap()); 
//        
////        when(objMapper.readValue(anyString(), Mockito.any(Class.class)))
////            .thenReturn(instanceSiteRoleMap);
////        filterParams.put("instanceSiteMap", instanceSiteRoleMap.toString()); 
//      
//        when(mapper.getEsaMarkAsReviewedCount(filterParams)).thenReturn(0);
//
//        // Mock any other method calls as needed
//        
//        // Call the method
//        service.updateResolutionTracking(filterParams, user, resolution);
//
//        // Add assertions based on the expected behavior of the method
//        // For example, assert that user's properties have been updated correctly.
//        assertEquals("P", user.getIdentityType());
//    }
	@Test
    public void testInsertAuditRecord2() {
        // Create sample data
        List<Map<String, Object>> esaInstanceMaps = new ArrayList<>();
        UserBean user = new UserBean(); // Replace with the actual UserBean instance.
        String event = "sampleEvent";

        // Mock the batchUpdate method of JdbcTemplate using doReturn
        doReturn(new int[]{1, 2, 3}).when(template).batchUpdate(anyString(), any(BatchPreparedStatementSetter.class));

        // Call the method to be tested
        service.insertAuditRecord(esaInstanceMaps, user, event);

                                                                                                      
    }
	@Test
    public void testInsertDtaAuditRecord() throws SQLException {
        // Mock data
        List<Map<String, Object>> etaInstanceMaps = new ArrayList<>();
        UserBean user = new UserBean(); // Assuming you have a method to create a UserBean
        String event = "someEvent";

        // Mock jdbcTemplate.batchUpdate method
        doAnswer((Answer<Void>) invocation -> {
            PreparedStatementSetter setter = invocation.getArgument(1, PreparedStatementSetter.class);
            PreparedStatement preparedStatement = mock(PreparedStatement.class);
            setter.setValues(preparedStatement);

            // Add assertions for preparedStatement
            verify(preparedStatement).setObject(eq(1), anyString());
            // Add more assertions as needed

            return null;
        }).when(template).batchUpdate(anyString(), any(BatchPreparedStatementSetter.class));


        // Call your service method
        service.insertDtaAuditRecord(etaInstanceMaps, user, event);

        
    }
	@Test
    public void testUpdateResolutionTracking() {
        // Create sample data for filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("isSerialized", "true");
        filterParams.put("instanceSiteMap", "[{\"instanceId\":\"197050321\",\"role\":\"PARTNER\"}]"); // Example JSON
        filterParams.put("email", "user@example.com");
        filterParams.put("userName", "John Doe");

        // Mock the behavior of advisoriesMapper
        List<Map<String, Object>> esaInstanceMaps = new ArrayList<>(); // Replace with your sample data
        when(mapper.getEsaInstanceMap(filterParams)).thenReturn(esaInstanceMaps);
        when(mapper.getEsaMarkAsReviewedCount(filterParams)).thenReturn(0);

        // Mock the behavior of user
        when(user.getEmail()).thenReturn("user@example.com");
        when(user.getFlname()).thenReturn("John Doe");

        // Call the method to be tested
        service.updateResolutionTracking(filterParams, user, "Scheduled For Action"); // Replace with a valid resolution type

        // Verify that the methods were called as expected
        verify(mapper, times(2)).getEsaInstanceMap(filterParams);
        verify(mapper, times(1)).getEsaMarkAsReviewedCount(filterParams);
        // Verify that no other interactions occurred on the user mock
       
    }
	@Test
	public void testUpdateEtaResolutionTracking() {
	    // Create test data
	    String resolution = "Scheduled For Action"; // Set a valid resolution value

	    // Mock behavior for advisoriesMapper
	    when(mapper.getEtaInstanceMap(anyMap())).thenReturn(new ArrayList<>());

	    // Stub the behavior for filterParams.get("isSerialized")
	    Map<String, Object> filterParams = Mockito.mock(Map.class);
	    when(filterParams.get("isSerialized")).thenReturn("true");
	    when(filterParams.get("instanceSiteMap")).thenReturn("[{\\\"instanceId\\\":\\\"197050321\\\",\\\"role\\\":\\\"PARTNER\\\"}]");
	    // Mock other necessary behavior for your specific test case.

	    // Call the method to test
	    service.updateEtaResolutionTracking(filterParams, user, resolution);

	    // Verify the interactions
	    verify(mapper, times(1)).getEtaInstanceMap(anyMap());
	    // Add more verifications for your specific case.
	}
	@Test
    public void testUpdateEtaResolutionTrackingWithSerialized() {
        String resolution = "Scheduled For Action"; // Set a valid resolution value

        // Mock behavior for advisoriesMapper
        when(mapper.getEtaInstanceMap(anyMap())).thenReturn(new ArrayList<>());

        // Create a mock for filterParams
        Map<String, Object> filterParams = Mockito.mock(Map.class);
        when(filterParams.get("isSerialized")).thenReturn("true");
        when(filterParams.get("instanceSiteMap")).thenReturn("[{\"instanceId\":\"197050321\",\"role\":\"PARTNER\"}]");
        when(filterParams.get("email")).thenReturn("user@example.com");
        when(filterParams.get("userName")).thenReturn("John Doe");
        // Mock other necessary behavior for your specific test case.

        // Call the method to test
        service.updateEtaResolutionTracking(filterParams, user, resolution);

        // Verify the interactions
        verify(mapper, times(2)).getEtaInstanceMap(anyMap());
        verify(user).setEmail("user@example.com");
        verify(user).setFlname("John Doe");
        verify(user).setIdentityType("P");
        verify(mapper).getEtaMarkAsReviewedCount(anyMap());
        // Add more verifications for your specific case.
    }
	@Test
    public void testUpdateEtaResolutionTrackingWithNonSerialized() {
        String resolution = "Scheduled For Action"; // Set a valid resolution value

        // Mock behavior for advisoriesMapper
        when(mapper.getEtaInstanceMap(anyMap())).thenReturn(new ArrayList<>());

        // Create a mock for filterParams
        Map<String, Object> filterParams = Mockito.mock(Map.class);
        when(filterParams.get("isSerialized")).thenReturn("false");
        // Mock other necessary behavior for your specific test case.

        // Call the method to test
        service.updateEtaResolutionTracking(filterParams, user, resolution);

        // Verify the interactions
        verify(mapper, times(1)).getEtaInstanceMap(anyMap());
    }

    @Test
    public void testUpdateEtaResolutionTrackingWithNoSerializedFlag() {
        String resolution = "Scheduled For Action"; // Set a valid resolution value

        // Mock behavior for advisoriesMapper
        when(mapper.getEtaInstanceMap(anyMap())).thenReturn(new ArrayList<>());

        // Create a mock for filterParams
        Map<String, Object> filterParams = Mockito.mock(Map.class);
        when(filterParams.get("isSerialized")).thenReturn(null);
        // Mock other necessary behavior for your specific test case.

        // Call the method to test
        service.updateEtaResolutionTracking(filterParams, user, resolution);

        // Verify the interactions
        verify(mapper, times(1)).getEtaInstanceMap(anyMap());
    }
//    @Test
//    public void testSetValues() throws SQLException {
//        // Create test data
//        int index = 1; // Index of the parameter you want to set
//        PreparedStatement preparedStatement = Mockito.mock(PreparedStatement.class);
//
//        // Create your esaInstanceMaps
//        List<Map<String, Object>> esaInstanceMaps = new ArrayList<>();
//        Map<String, Object> map = new HashMap<>();
//        // Add the necessary data to the map
//        map.put("event", "YourEvent");
//        // Add other required fields
//        esaInstanceMaps.add(map);
//
//        // Mock behavior for the mapper
//        when(mapper.getEtaInstanceMap(Mockito.anyMap())).thenReturn(esaInstanceMaps);
//
//        // Call the method to test
//        service.setValues(preparedStatement, index);
//
//        // Verify that the method has been called with the expected arguments
//        verify(preparedStatement, times(1)).setObject(index, Mockito.anyString()); // Adjust the argument type as needed
//
//        // Verify that the map in esaInstanceMaps has been updated correctly
//        assertEquals("YourEvent", esaInstanceMaps.get(0).get("event"));
//        // Add more verifications as needed.
//    }
//    @Test
//    public void testInsertAuditRecord() throws SQLException {
//        // Create your test data
//        UserBean user = new UserBean();
//        user.setUid("123");
//        user.setFlname("John Doe");
//        user.setEmail("john.doe@example.com");
//        user.setIdentityType("E");
//
////        String esaSql = "INSERT INTO dvs.esa_event VALUES (?::jsonb)";
//        // Create your esaInstanceMaps
//        ReflectionTestUtils.setField(service, "esaSql", "mockQuery");
//        List<Map<String, Object>> esaInstanceMaps = new ArrayList<>();
//        Map<String, Object> map = new HashMap<>();
//        // Add the necessary data to the map
//        map.put("event", "YourEvent");
//        map.put("timestamp", "testtimestamp");
//        map.put("uid", "123");
//        map.put("userName", "John Doe");
//        map.put("email", "testemail");
//        map.put("identityType", "testidentityType");
//        
//        // Add other required fields
//        esaInstanceMaps.add(map);
//        final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
//        when(mapper.getEsaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
//        // Mock jdbcTemplate.batchUpdate
//        when(template.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class)))
//            .thenAnswer(invocation -> {
//                BatchPreparedStatementSetter batchSetter = invocation.getArgument(1);
//                // Mock the PreparedStatement and call the setValues method of the batchSetter
//                PreparedStatement preparedStatement = Mockito.mock(PreparedStatement.class);
//                batchSetter.setValues(preparedStatement, 0);
//
//                // Verify that the PreparedStatement is updated correctly
//                Mockito.verify(preparedStatement).setObject(1, Mockito.anyString());
//                return new int[]{1};
//            });
//
//        // Call the method to test
//        service.insertAuditRecord(esaInstanceMaps, user, "YourEvent");
//    }
    @Test
    public void testGetEsaTimelineData() {
        // Create your test data
        Map<String, Object> filterParams = new HashMap<>();
        // Add necessary data to filterParams

        List<AdvisoryBean> esaAggregate = new ArrayList<>();
        // Add one or more AdvisoryBeans to esaAggregate

        // Mock the behavior for advisoriesMapper methods
        AdvisoriesMapper advisoriesMapper = mock(AdvisoriesMapper.class);
        when(advisoriesMapper.getIbInstanceMap(filterParams)).thenReturn(new HashMap<>()); // Mock productBeanMap
        when(advisoriesMapper.getEsaTimeline(filterParams)).thenReturn(esaAggregate); // Mock esaAggregate retrieval

        // Create an ObjectMapper mock
        ObjectMapper mapper = mock(ObjectMapper.class);

        // Create an instance of your service
        AdvisoriesServiceImpl service = new AdvisoriesServiceImpl(advisoriesMapper, template, mapper, null);

        // Call the method to test
        List<TimelineEntity> timelineEntities = service.getEsaTimelineData(filterParams);

        // Verify the interactions
        assertEquals(esaAggregate.size(), timelineEntities.size()); // Ensure the list size matches

        // Add more verifications for the specific behavior in the provided code
        for (int i = 0; i < esaAggregate.size(); i++) {
            AdvisoryBean esa = esaAggregate.get(i);
            TimelineEntity esaEntity = timelineEntities.get(i);

            assertEquals("ESA", esaEntity.getEntityType());
            // Add more assertions to verify other fields in esaEntity
        }
    }

	@SuppressWarnings("unchecked")
	@Test
	public void testGetEtaAggregate() throws Exception {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean etaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
		etaAggBean.setProducts("3");
		etaAggBean.setDocumentId("ESA-2015-025");
		etaAggBean.setSeverity("Critical");
		etaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		etaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		etaAggBean.setAge("433 days");
		etaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		etaAggBean.setProductFamily("1");
		etaAggBean.setLastReviewedBy("User");
		etaAggBean.setLastUpdatedBy("User");
		etaAggBean.setLastReviewTime(1530774202);
		etaAggBean.setStatus("new");
		etaAggBean.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean.setPublished(1492086796000L);
		etaAggBean.setEmcProprietaryCode(null);
		etaAggBean.setUpdated(true);
		etaAggBeanList.add(etaAggBean);

		when(mapper.getEtaAggregate(anyMap())).thenReturn(etaAggBeanList);
		final List<AdvisoryBean> actual = service.getEtaAggregate(filterParams).get();
		assertNotNull(actual);
		verify(mapper, times(1)).getEtaAggregate(filtersCaptor.capture());
	}

	@Test
	public void testEsaTotalRecord() throws Exception {
		when(mapper.getEsaAggregateTotalRecord(anyMap())).thenReturn(10000);

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		final int actual = service.getEsaTotalRecord(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getEsaAggregateTotalRecord(filtersCaptor.capture());

		final Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		final List<String> capturedSites = (List<String>) filters.get("siteIds");
		Assertions.assertEquals(capturedSites, getSiteList());
		final String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		Assertions.assertEquals("Y", capturedTlaValue);
	}

	@Test
	public void testEtaTotalRecord() throws Exception {
		when(mapper.getEtaAggregateTotalRecord(anyMap())).thenReturn(10000);

		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		final int actual = service.getEtaTotalRecord(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getEtaAggregateTotalRecord(filtersCaptor.capture());

		final Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		final List<String> capturedSites = (List<String>) filters.get("siteIds");
		Assertions.assertEquals(capturedSites, getSiteList());
		final String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		Assertions.assertEquals("Y", capturedTlaValue);
	}

	@Test
	public void testEsaReviewed() {
		ReflectionTestUtils.setField(service, "esaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEsaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.markDsaAsReviewed(filterParams, user);
	}

	@Test
	public void testEtaReviewed() {
		ReflectionTestUtils.setField(service, "etaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEtaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.markDtaAsReviewed(filterParams, user);
	}

	@Test
	public void testEsaNotApplicable() {
		ReflectionTestUtils.setField(service, "esaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEsaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.markDsaAsDisregarded(filterParams, user);
	}

	@Test
	public void testEtaNotApplicable() {
		ReflectionTestUtils.setField(service, "etaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEtaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.markDtaAsNotApplicable(filterParams, user);
	}

	@Test
	public void testEsaRemidiation() {
		ReflectionTestUtils.setField(service, "esaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEsaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.updateResolutionTracking(filterParams, user, "Not Applicable");
	}

	@Test
	public void testEtaRemidiation() {
		ReflectionTestUtils.setField(service, "etaSql", "mockQuery");
		final List<Map<String, Object>> mockInstanceMap = new ArrayList<>();
		final UserBean user = new UserBean();
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		when(mapper.getEtaInstanceMap(anyMap())).thenReturn(mockInstanceMap);
		service.updateEtaResolutionTracking(filterParams, user, "Not Scheduled");
	}

	@Test
	public void testDsaAffectedProducts() throws InterruptedException, ExecutionException {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093219");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886584");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);

		when(mapper.getAffectedProducts(filterParams)).thenReturn(products);
		final List<AffectedProductsBean> actual = service.getAffectedProducts(filterParams, "ESA").get();
		assertNotNull(actual);
		verify(mapper, times(1)).getAffectedProducts(filtersCaptor.capture());
	}
	
	@Test
	public void testDsaAffectedProductsETA() throws InterruptedException, ExecutionException {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093219");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886584");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);

		when(mapper.getEtaAffectedProducts(filterParams)).thenReturn(products);
		final List<AffectedProductsBean> actual = service.getAffectedProducts(filterParams, "ETA").get();
		assertNotNull(actual);
		verify(mapper, times(1)).getEtaAffectedProducts(filtersCaptor.capture());
	}

	@Test
	public void testDsaRemidiationCount() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean esaAggBean1 = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean1.setProducts("3");
		esaAggBean1.setDocumentId("ESA-2015-025");
		esaAggBean1.setSeverity("Critical");
		esaAggBean1.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean1.setLastUpdatedBy("User");
		esaAggBean1.setLastReviewTime(1530774202);
		esaAggBean1.setStatus("New");
		esaAggBean1.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean1.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean1.setPublished(1492086796000L);
		esaAggBean1.setEmcProprietaryCode(null);
		esaAggBean1.setUpdated(false);
		final AdvisoryBean esaAggBean2 = new AdvisoryBean();
		esaAggBean2.setProducts("3");
		esaAggBean2.setDocumentId("ESA-2015-025");
		esaAggBean2.setSeverity("Critical");
		esaAggBean2.setProductFamily("1");
		esaAggBean2.setLastReviewedBy("User");
		esaAggBean2.setLastUpdatedBy("User");
		esaAggBean2.setLastReviewTime(1530774202);
		esaAggBean2.setStatus("Work In Progress");
		esaAggBean2.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean2.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean2.setPublished(1492086796000L);
		esaAggBean2.setEmcProprietaryCode(null);
		esaAggBean2.setUpdated(false);
		esaAggBeanList.add(esaAggBean1);
		esaAggBeanList.add(esaAggBean2);

		final AdvisoryBean etaAggBean3 = new AdvisoryBean();
		etaAggBean3.setProducts("3");
		etaAggBean3.setDocumentId("ESA-2015-025");
		etaAggBean3.setSeverity("Critical");
		etaAggBean3.setProductFamily("1");
		etaAggBean3.setLastReviewedBy("User");
		etaAggBean3.setLastUpdatedBy("User");
		etaAggBean3.setLastReviewTime(1530774202);
		etaAggBean3.setStatus("Remediated");
		etaAggBean3.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean3.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean3.setPublished(1492086796000L);
		etaAggBean3.setEmcProprietaryCode(null);
		etaAggBean3.setUpdated(false);
		
		final AdvisoryBean etaAggBean4 = new AdvisoryBean();
		etaAggBean4.setProducts("3");
		etaAggBean4.setDocumentId("ESA-2015-025");
		etaAggBean4.setSeverity("Critical");
		etaAggBean4.setProductFamily("1");
		etaAggBean4.setLastReviewedBy("User");
		etaAggBean4.setLastUpdatedBy("User");
		etaAggBean4.setLastReviewTime(1530774202);
		etaAggBean4.setStatus("Not Applicable");
		etaAggBean4.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean4.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean4.setPublished(1492086796000L);
		etaAggBean4.setEmcProprietaryCode(null);
		etaAggBean4.setUpdated(false);
		
		final AdvisoryBean etaAggBean5 = new AdvisoryBean();
		etaAggBean5.setProducts("3");
		etaAggBean5.setDocumentId("ESA-2015-025");
		etaAggBean5.setSeverity("Critical");
		etaAggBean5.setProductFamily("1");
		etaAggBean5.setLastReviewedBy("User");
		etaAggBean5.setLastUpdatedBy("User");
		etaAggBean5.setLastReviewTime(1530774202);
		etaAggBean5.setStatus("Reviewed");
		etaAggBean5.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean5.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean5.setPublished(1492086796000L);
		etaAggBean5.setEmcProprietaryCode(null);
		etaAggBean5.setUpdated(false);
		
		esaAggBeanList.add(esaAggBean1);
		esaAggBeanList.add(esaAggBean2);
		esaAggBeanList.add(etaAggBean3);
		esaAggBeanList.add(etaAggBean4);
		esaAggBeanList.add(etaAggBean5);
		when(mapper.getEsaAggregate(filterParams)).thenReturn(esaAggBeanList);
		final KpiBean kpi = service.getRemediationStatus(filterParams);
		assertNotNull(kpi);
		assertEquals(kpi.getNewCount(), 2);
		assertEquals(kpi.getWorkInProgressCount(), 2);
		assertEquals(kpi.getReviewedCount(), 1);
		assertEquals(kpi.getNotApplicableCount(), 1);
		assertEquals(kpi.getRemediatedCount(), 1);
		verify(mapper, times(1)).getEsaAggregate(filtersCaptor.capture());

	}

	@Test
	public void testDtaRemidiationCount() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean etaAggBean1 = new AdvisoryBean();
		final List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
		etaAggBean1.setProducts("3");
		etaAggBean1.setDocumentId("ESA-2015-025");
		etaAggBean1.setSeverity("Critical");
		etaAggBean1.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBean1.setLastUpdatedBy("User");
		etaAggBean1.setLastReviewTime(1530774202);
		etaAggBean1.setStatus("New");
		etaAggBean1.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean1.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean1.setPublished(1492086796000L);
		etaAggBean1.setEmcProprietaryCode(null);
		etaAggBean1.setUpdated(false);
		final AdvisoryBean etaAggBean2 = new AdvisoryBean();
		etaAggBean2.setProducts("3");
		etaAggBean2.setDocumentId("ESA-2015-025");
		etaAggBean2.setSeverity("Critical");
		etaAggBean2.setProductFamily("1");
		etaAggBean2.setLastReviewedBy("User");
		etaAggBean2.setLastUpdatedBy("User");
		etaAggBean2.setLastReviewTime(1530774202);
		etaAggBean2.setStatus("Work In Progress");
		etaAggBean2.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean2.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean2.setPublished(1492086796000L);
		etaAggBean2.setEmcProprietaryCode(null);
		etaAggBean2.setUpdated(false);
		
		final AdvisoryBean etaAggBean3 = new AdvisoryBean();
		etaAggBean3.setProducts("3");
		etaAggBean3.setDocumentId("ESA-2015-025");
		etaAggBean3.setSeverity("Critical");
		etaAggBean3.setProductFamily("1");
		etaAggBean3.setLastReviewedBy("User");
		etaAggBean3.setLastUpdatedBy("User");
		etaAggBean3.setLastReviewTime(1530774202);
		etaAggBean3.setStatus("Remediated");
		etaAggBean3.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean3.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean3.setPublished(1492086796000L);
		etaAggBean3.setEmcProprietaryCode(null);
		etaAggBean3.setUpdated(false);
		
		final AdvisoryBean etaAggBean4 = new AdvisoryBean();
		etaAggBean4.setProducts("3");
		etaAggBean4.setDocumentId("ESA-2015-025");
		etaAggBean4.setSeverity("Critical");
		etaAggBean4.setProductFamily("1");
		etaAggBean4.setLastReviewedBy("User");
		etaAggBean4.setLastUpdatedBy("User");
		etaAggBean4.setLastReviewTime(1530774202);
		etaAggBean4.setStatus("Not Applicable");
		etaAggBean4.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean4.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean4.setPublished(1492086796000L);
		etaAggBean4.setEmcProprietaryCode(null);
		etaAggBean4.setUpdated(false);
		
		final AdvisoryBean etaAggBean5 = new AdvisoryBean();
		etaAggBean5.setProducts("3");
		etaAggBean5.setDocumentId("ESA-2015-025");
		etaAggBean5.setSeverity("Critical");
		etaAggBean5.setProductFamily("1");
		etaAggBean5.setLastReviewedBy("User");
		etaAggBean5.setLastUpdatedBy("User");
		etaAggBean5.setLastReviewTime(1530774202);
		etaAggBean5.setStatus("Reviewed");
		etaAggBean5.setArticleId("kA3j0000000PEhrCAG");
		etaAggBean5.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		etaAggBean5.setPublished(1492086796000L);
		etaAggBean5.setEmcProprietaryCode(null);
		etaAggBean5.setUpdated(false);
		
		
		etaAggBeanList.add(etaAggBean1);
		etaAggBeanList.add(etaAggBean2);
		etaAggBeanList.add(etaAggBean3);
		etaAggBeanList.add(etaAggBean4);
		etaAggBeanList.add(etaAggBean5);
		
		when(mapper.getEtaAggregate(filterParams)).thenReturn(etaAggBeanList);
		final KpiBean kpi = service.getEtaRemediationStatusCount(filterParams);
		assertNotNull(kpi);
		assertEquals(kpi.getNewCount(), 1);
		assertEquals(kpi.getWorkInProgressCount(), 1);
		assertEquals(kpi.getReviewedCount(), 1);
		assertEquals(kpi.getNotApplicableCount(), 1);
		assertEquals(kpi.getRemediatedCount(), 1);
		verify(mapper, times(1)).getEtaAggregate(filtersCaptor.capture());

	}
//	@Test
//	public void testGetAdvisoryForProduct() {
//	    // Create your test data
//	    Map<String, Object> filterParams = new HashMap<>();
//	    filterParams.put("articleStatusIsIn", "sampleStatus");
//	    filterParams.put("severityFilterIsIn", "LOW");
//	    filterParams.put("size", 2);
//	    filterParams.put("number", 1);
//	    List<SerializedProductBean> serializedProductBeans = new ArrayList<>();
//
//	    // Create some sample SerializedProductBean objects
//	    SerializedProductBean productBean1 = new SerializedProductBean();
//	    productBean1.setSeverity("CRITICAL");
//	    // Set other properties as needed
//	    serializedProductBeans.add(productBean1);
//
//	    SerializedProductBean productBean2 = new SerializedProductBean();
//	    productBean2.setSeverity("HIGH");
//	    // Set other properties as needed
//	    serializedProductBeans.add(productBean2);
//
//	    // Mock advisoriesMapper methods
//	    when(mapper.getEtaForProduct(filterParams)).thenReturn(serializedProductBeans);
//
//	    // Call the method to test
//	    SerializedResponseBean responseBean = service.getAdvisoryForProduct(filterParams, "ETA");
//
//	    // Assert the results
//	    assertNotNull(responseBean);
//	    assertEquals(serializedProductBeans.size(), responseBean.getTotalElementsCount());
//
//	    Map<String, Integer> severityCountsMap = responseBean.getSeverityCountsMap();
//
//	    // Assert that the counts match the expected values
//	    assertEquals(1, severityCountsMap.get("CRITICAL").intValue());
//	    assertEquals(1, severityCountsMap.get("HIGH").intValue());
//	    assertEquals(0, severityCountsMap.get("MEDIUM").intValue());
//	    assertEquals(0, severityCountsMap.get("LOW").intValue());
//	}
//	@Test
//    public void testGetAdvisorySerialized() {
//        // Define your test data and set up your mocks here
//        Map<String, Object> filterParams = /* Create your filterParams */;
//        String advisoryType = /* Set the advisory type */;
//        // Mock behavior of advisoriesMapper and subscriptionDetailsService methods
//        when(advisoriesMapper.getEtaSerialized(filterParams)).thenReturn(/* Mocked data for ETA */);
//        when(subscriptionDetailsService.getSubscriptionDetails(/* profileId */)).thenReturn(/* Mocked subscription details */);
//        // Other mock setups as needed
//
//        // Call your method
//        SerializedResponseBean responseBean = yourServiceClass.getAdvisorySerialized(filterParams, advisoryType);
//
//        // Verify the expected behavior
//        // For example, assert that the responseBean and its properties are as expected
//        assertEquals(/* Expected value */, responseBean.getTotalElementsCount());
//        // Add more assertions as per your requirements
//    }
	@Test
	public void testGetAdvisoryForProduct() {
	    // Create your test data
	    Map<String, Object> filterParams = new HashMap<>();
	    filterParams.put("articleStatusIsIn", "sampleStatus");
	    filterParams.put("severityFilterIsIn", "LOW");
	    filterParams.put("size", 2);
	    filterParams.put("number", 1);
	    List<SerializedProductBean> serializedProductBeans = new ArrayList<>();

	    // Create some sample SerializedProductBean objects
	    SerializedProductBean productBean1 = new SerializedProductBean();
	    productBean1.setSeverity("CRITICAL");
	    // Set other properties as needed
	    serializedProductBeans.add(productBean1);

	    SerializedProductBean productBean2 = new SerializedProductBean();
	    productBean2.setSeverity("HIGH");
	    // Set other properties as needed
	    serializedProductBeans.add(productBean2);

	    // Mock advisoriesMapper methods
	    when(mapper.getEtaForProduct(filterParams)).thenReturn(serializedProductBeans);

	    // Call the method to test
	    SerializedResponseBean responseBean = service.getAdvisoryForProduct(filterParams, "ETA");

	    // Assert the results
	    assertNotNull(responseBean);
	    assertEquals(serializedProductBeans.size(), responseBean.getTotalElementsCount());

	    Map<String, Integer> severityCountsMap = responseBean.getSeverityCountsMap();

	    // Make sure severityCountsMap is not null
	    assertNotNull(severityCountsMap);

	}


	@Test
	public void testEsaAffectedProductsKpi() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		filterParams.put("regionIsIn", "APJK CS Theater");
		final List<AdvisoryBean> aggList = new ArrayList<>();
		final AdvisoryBean esa1 = new AdvisoryBean();
		esa1.setArticleId("ESA-2016-079");
		final AdvisoryBean esa2 = new AdvisoryBean();
		esa1.setArticleId("ESA-2016-089");
		aggList.add(esa1);
		aggList.add(esa2);
		when(mapper.getArticles(filterParams)).thenReturn(aggList);
		final AffectedProductsKpi emeaKpi = new AffectedProductsKpi();
		emeaKpi.setCritical("1000");
		emeaKpi.setHigh("450");
		emeaKpi.setHigh("450");
		emeaKpi.setMedium("40");
		emeaKpi.setLow("10");
		emeaKpi.setProductCount("2000");
		emeaKpi.setRegion("EMEA");
		final AffectedProductsKpi apjKpi = new AffectedProductsKpi();
		apjKpi.setCritical("1000");
		apjKpi.setHigh("450");
		apjKpi.setHigh("450");
		apjKpi.setMedium("40");
		apjKpi.setLow("10");
		apjKpi.setProductCount("2000");
		apjKpi.setRegion("APJ");
		final List<AffectedProductsKpi> kpis = new ArrayList<>();
		kpis.add(apjKpi);
		kpis.add(emeaKpi);
		when(mapper.getAffectedProductsForKpi(filterParams)).thenReturn(kpis);
		final List<AffectedProductsKpi> actual = service.getAffectedProductsForKpi(filterParams);
		assertNotNull(actual);
		Assertions.assertEquals(actual.size(), 2);
		Assertions.assertEquals(actual.get(0).getCritical(), "1000");
		Assertions.assertEquals(actual.get(0).getRegion(), "APJ");
		Assertions.assertEquals(actual.get(1).getRegion(), "EMEA");
		verify(mapper, times(1)).getArticles(filtersCaptor.capture());
		verify(mapper, times(1)).getAffectedProductsForKpi(filtersCaptor.capture());
	}

	@Test
	public void testEtaAffectedProductsKpi() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		filterParams.put("regionIsIn", "APJK CS Theater");
		final List<AdvisoryBean> aggList = new ArrayList<>();
		final AdvisoryBean eta1 = new AdvisoryBean();
		eta1.setArticleId("ETA 2016079");
		final AdvisoryBean eta2 = new AdvisoryBean();
		eta2.setArticleId("ETA 2016089");
		aggList.add(eta1);
		aggList.add(eta2);
		when(mapper.getEtaArticles(filterParams)).thenReturn(aggList);
		final AffectedProductsKpi emeaKpi = new AffectedProductsKpi();
		emeaKpi.setCritical("1000");
		emeaKpi.setHigh("450");
		emeaKpi.setHigh("450");
		emeaKpi.setMedium("40");
		emeaKpi.setLow("10");
		emeaKpi.setProductCount("2000");
		emeaKpi.setRegion("EMEA");
		final AffectedProductsKpi apjKpi = new AffectedProductsKpi();
		apjKpi.setCritical("1000");
		apjKpi.setHigh("450");
		apjKpi.setHigh("450");
		apjKpi.setMedium("40");
		apjKpi.setLow("10");
		apjKpi.setProductCount("2000");
		apjKpi.setRegion("APJ");
		final List<AffectedProductsKpi> kpis = new ArrayList<>();
		kpis.add(apjKpi);
		kpis.add(emeaKpi);
		when(mapper.getEtaAffectedProductsForKpi(filterParams)).thenReturn(kpis);
		final List<AffectedProductsKpi> actual = service.getEtaAffectedProductsForKpi(filterParams);
		assertNotNull(actual);
		Assertions.assertEquals(actual.size(), 2);
		Assertions.assertEquals(actual.get(0).getCritical(), "1000");
		Assertions.assertEquals(actual.get(0).getRegion(), "APJ");
		Assertions.assertEquals(actual.get(1).getRegion(), "EMEA");
		verify(mapper, times(1)).getEtaArticles(filtersCaptor.capture());
		verify(mapper, times(1)).getEtaAffectedProductsForKpi(filtersCaptor.capture());
	}

	@Test
	public void testEsaAdvisoryDetail() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		filterParams.put("advisoryType", "ESA");
		final AdvisoryBean esa = new AdvisoryBean();
		esa.setProducts("3");
		esa.setDocumentId("ESA-2015-025");
		esa.setSeverity("Critical");
		esa.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esa.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esa.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esa.setAge("433 days");
		esa.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esa.setProductFamily("1");
		esa.setLastReviewedBy("User");
		esa.setLastUpdatedBy("User");
		esa.setLastReviewTime(1530774202);
		esa.setStatus("new");
		esa.setArticleId("kA3j0000000PEhrCAG");
		esa.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esa.setPublished(1492086796000L);
		esa.setEmcProprietaryCode(null);
		esa.setUpdated(true);
		when(mapper.getSecAdvisoryDetail(filterParams)).thenReturn(esa);
		final AdvisoryBean actual = service.getAdvisoryDetail(filterParams);
		assertNotNull(actual);
		Assertions.assertEquals(actual.getStatus(), "new");
		Assertions.assertEquals(actual.getSeverity(), "Critical");
		verify(mapper, times(1)).getSecAdvisoryDetail(filtersCaptor.capture());
	}

	@Test
	public void testEtaAdvisoryDetail() {
		final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		filterParams.put("advisoryType", "ETA");
		final AdvisoryBean eta = new AdvisoryBean();
		eta.setProducts("3");
		eta.setDocumentId("ETA 2015025");
		eta.setSeverity("Critical");
		eta.setTitle("ESA 2015025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		eta.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		eta.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		eta.setAge("433 days");
		eta.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		eta.setProductFamily("1");
		eta.setLastReviewedBy("User");
		eta.setLastUpdatedBy("User");
		eta.setLastReviewTime(1530774202);
		eta.setStatus("new");
		eta.setArticleId("kA3j0000000PEhrCAG");
		eta.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		eta.setPublished(1492086796000L);
		eta.setEmcProprietaryCode(null);
		eta.setUpdated(true);
		when(mapper.getTechAdvisoryDetail(filterParams)).thenReturn(eta);
		final AdvisoryBean actual = service.getAdvisoryDetail(filterParams);
		assertNotNull(actual);
		Assertions.assertEquals(actual.getStatus(), "new");
		Assertions.assertEquals(actual.getSeverity(), "Critical");
		Assertions.assertEquals(actual.getDocumentId(), "ETA 2015025");
		verify(mapper, times(1)).getTechAdvisoryDetail(filtersCaptor.capture());
	}

	@Test
	public void testEmptyAdvisoryDetail() {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		filterParams.put("advisoryType", "ARTICLE");
		final AdvisoryBean actual = service.getAdvisoryDetail(filterParams);
		assertNotNull(actual);
	}

	@Test
	public void testEsaExport() throws JsonParseException, JsonMappingException, IOException {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBeanList.add(esaAggBean);
		final OutputStream out = response.getOutputStream();
		when(mapper.getEsaAggregate(anyMap())).thenReturn(esaAggBeanList);
		final String columns = "{\"columns\":[{\"title\":\"Severity\",\"field\":\"Severity\"}]}";
		final ColumnWrapper colWrapper = objMapper.readValue(columns, ColumnWrapper.class);

		service.getEsaAggregate(out, filterParams, colWrapper.getColumns());
	}

	@Test
	public void testEtaExport() throws JsonParseException, JsonMappingException, IOException {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AdvisoryBean etaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> etaAggBeanList = new ArrayList<>();
		etaAggBean.setProducts("3");
		etaAggBean.setDocumentId("ESA-2015-025");
		etaAggBean.setSeverity("Critical");
		etaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		etaAggBeanList.add(etaAggBean);
		final OutputStream out = response.getOutputStream();
		when(mapper.getEtaAggregate(anyMap())).thenReturn(etaAggBeanList);
		final String columns = "{\"columns\":[{\"title\":\"Severity\",\"field\":\"Severity\"}]}";
		final ColumnWrapper colWrapper = objMapper.readValue(columns, ColumnWrapper.class);

		service.getEtaAggregate(out, filterParams, colWrapper.getColumns());
	}

	@Test
	public void testEsaAffectedProductsExport() throws JsonParseException, JsonMappingException, IOException {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093219");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886584");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);
		final OutputStream out = response.getOutputStream();
		when(mapper.getAffectedProducts(filterParams)).thenReturn(products);
		final String columns = "{\"columns\":[{\"title\":\"Severity\",\"field\":\"Severity\"}]}";
		final ColumnWrapper colWrapper = objMapper.readValue(columns, ColumnWrapper.class);

		service.getAffectedProducts(out, filterParams, colWrapper.getColumns());
	}
	
	@Test
	public void testEsaAffectedProductsExportETA() throws JsonParseException, JsonMappingException, IOException {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093219");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886584");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);
		final OutputStream out = response.getOutputStream();
		when(mapper.getAffectedProducts(filterParams)).thenReturn(products);
		final String columns = "{\"columns\":[{\"title\":\"Severity\",\"field\":\"Severity\"}]}";
		final ColumnWrapper colWrapper = objMapper.readValue(columns, ColumnWrapper.class);

		service.getAffectedProducts(out, filterParams, colWrapper.getColumns());
	}

	@Test
	public void testEtaAffectedProductsExport() throws JsonParseException, JsonMappingException, IOException {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		final AffectedProductsBean product1 = new AffectedProductsBean();
		product1.setInstanceId("1030093219");
		product1.setLastUpdatedBy("James McKenna");
		product1.setSiteId("2886584");
		product1.setProductFamily("AVAMAR DATA STORE");
		product1.setSerialNumberProductPage(true);
		product1.setProductAlias("Avamar");
		final AffectedProductsBean product2 = new AffectedProductsBean();
		product2.setInstanceId("1030093219");
		product2.setLastUpdatedBy("James McKenna");
		product2.setSiteId("2886584");
		product2.setProductFamily("AVAMAR DATA STORE");
		product2.setSerialNumberProductPage(true);
		product2.setProductAlias("Avamar");
		final List<AffectedProductsBean> products = new ArrayList<>();
		products.add(product1);
		products.add(product2);
		final OutputStream out = response.getOutputStream();
		when(mapper.getEtaAffectedProducts(filterParams)).thenReturn(products);
		final String columns = "{\"columns\":[{\"title\":\"Severity\",\"field\":\"Severity\"}]}";
		final ColumnWrapper colWrapper = objMapper.readValue(columns, ColumnWrapper.class);

		service.getEtaAffectedProducts(out, filterParams, colWrapper.getColumns());
	}
	
	@Test
	public void testGetEsaTimelineStats() {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("tlvTimeRangeBefore", 54321L);
		filterParams.put("tlvTimeRangeAfter", 12345L);
		
		List<AdvisoryBean> esaTimelines = new ArrayList<>();
		when(mapper.getEsaAggregate(filterParams)).thenReturn(esaTimelines);
		
		service.getEsaTimelineData(filterParams);
	}
	
	@Test
	public void testGetEsaTimelineStats1() {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("tlvTimeRangeBefore", 54321L);
		filterParams.put("tlvTimeRangeAfter", 12345L);
		
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esaAggBean.setAge("433 days");
		esaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esaAggBean.setProductFamily("1");
		esaAggBean.setLastReviewedBy("User");
		esaAggBean.setLastUpdatedBy("User");
		esaAggBean.setLastReviewTime(1530774202);
		esaAggBean.setStatus("new");
		esaAggBean.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean.setPublished(1492086796000L);
		esaAggBean.setEmcProprietaryCode(null);
		esaAggBean.setUpdated(true);
		esaAggBeanList.add(esaAggBean);

		when(mapper.getEsaAggregate(anyMap())).thenReturn(esaAggBeanList);
		
		service.getEsaTimelineData(filterParams);
	}
	
	
	@Test
	public void testGetEtaTimelineData() {
		final Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("tlvTimeRangeBefore", 54321L);
		filterParams.put("tlvTimeRangeAfter", 12345L);
		
		final AdvisoryBean esaAggBean = new AdvisoryBean();
		final List<AdvisoryBean> esaAggBeanList = new ArrayList<>();
		esaAggBean.setProducts("3");
		esaAggBean.setDocumentId("ESA-2015-025");
		esaAggBean.setSeverity("Critical");
		esaAggBean.setTitle("ESA-2015-025: EMC ProSphere Security Update for GNU C Library \"GHOST\" Vulnerability");
		esaAggBean.setResolution(
				"The following EMC Documentum Content Server releases contain resolutions to these vulnerabilities:\\n\\n\\n\\tEMC Documentum Content Server 7.0\\n\\n\\t\\n\\t\\tP20 and later (POODLE)\\n\\t\\t\\n\\t\\tP21 and later  (Oracle JRE updates)\\n\\t\\t\\n\\t\\n\\tEMC Documentum Content Server 7.1 P18 and later\\n\\t\\n\\tEMC Documentum Content Server 7.2 P02 and later\\n\\t\\n\\nCustomers on EMC Documentum Content Server prior to 7.0, with extended support agreement, are requested to raise a hot fix request through EMC Customer Support.EMC strongly recommends all customers to apply the patches at the earliest opportunity.");
		esaAggBean.setSummary(
				"The buffer overflow vulnerability in glibc (aka the  GHOST  vulnerability) may potentially be exploited remotely to run arbitrary code on Connectrix MDS Series switch and director systems.");
		esaAggBean.setAge("433 days");
		esaAggBean.setProductNameList("VNX5200|VNX5400|VNX5600|VNX5800|VNX7600|VNX8000|VNX VG50");
		esaAggBean.setProductFamily("1");
		esaAggBean.setLastReviewedBy("User");
		esaAggBean.setLastUpdatedBy("User");
		esaAggBean.setLastReviewTime(1530774202);
		esaAggBean.setStatus("new");
		esaAggBean.setArticleId("kA3j0000000PEhrCAG");
		esaAggBean.setCveIds("CVE-2015-0458,CVE-2015-0459,CVE-2015-0460,CVE-2015-0469");
		esaAggBean.setPublished(1492086796000L);
		esaAggBean.setEmcProprietaryCode(null);
		esaAggBean.setUpdated(true);
		esaAggBeanList.add(esaAggBean);

		when(mapper.getEtaTimeline(anyMap())).thenReturn(esaAggBeanList);
		
		service.getEtaTimelineData(filterParams);
	}
	
	@Test
    public void testGetDsaHud() throws ExecutionException, InterruptedException {
        Map<String, Object> filterParams = createFilterParams(); // Create test filter parameters

        // Create a list of AdvisoriesHud objects for the expected result
        List<AdvisoriesHud> expectedData = createExpectedData();

        // Mock the behavior of advisoriesMapper
        when(mapper.getDsaHud(filterParams)).thenReturn(expectedData);

        // Call the method and get the CompletableFuture
        Future<List<AdvisoriesHud>> futureResult = service.getDsaHud(filterParams);

        // Block and get the result from the CompletableFuture
        List<AdvisoriesHud> actualData = futureResult.get();

        // Assert that the actual data matches the expected data
        Assertions.assertEquals(expectedData, actualData);
    }

    @Test
    public void testGetDtaHud() throws ExecutionException, InterruptedException {
        Map<String, Object> filterParams = createFilterParams(); // Create test filter parameters

        // Create a list of AdvisoriesHud objects for the expected result
        List<AdvisoriesHud> expectedData = createExpectedData();

        // Mock the behavior of advisoriesMapper
        when(mapper.getDtaHud(filterParams)).thenReturn(expectedData);

        // Call the method and get the CompletableFuture
        Future<List<AdvisoriesHud>> futureResult = service.getDtaHud(filterParams);

        // Block and get the result from the CompletableFuture
        List<AdvisoriesHud> actualData = futureResult.get();

        // Assert that the actual data matches the expected data
        Assertions.assertEquals(expectedData, actualData);
    }

    // Create test filter parameters
    private Map<String, Object> createFilterParams() {
        // Replace with actual filter parameters for testing
        return new HashMap<>();
    }

    // Create a list of AdvisoriesHud objects for testing
    private List<AdvisoriesHud> createExpectedData() {
        List<AdvisoriesHud> data = new ArrayList<>();
        // Populate data for testing
        return data;
    }
    
    @SuppressWarnings("unchecked")
	@Test
	public void testGetDtaCount() throws Exception {
    	final Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "7478|8691");
		filterParams.put("size", 25);
		filterParams.put("number", 1);
		filterParams.put("sortBy", "severity");
		filterParams.put("sortDir", "desc");
		when(mapper.getDtaCount(anyMap())).thenReturn(1);
		final Integer actual = service.getDtaCount(filterParams).get();
		assertNotNull(actual);
		verify(mapper, times(1)).getDtaCount(filtersCaptor.capture());
	}
    
    @SuppressWarnings("unchecked")
   	@Test
   	public void testGetDsaCount() throws Exception {
       	final Map<String, Object> filterParams = new HashMap<String, Object>();
   		filterParams.put("siteNumberIsIn", "7478|8691");
   		filterParams.put("size", 25);
   		filterParams.put("number", 1);
   		filterParams.put("sortBy", "severity");
   		filterParams.put("sortDir", "desc");
   		when(mapper.getDsaCount(anyMap())).thenReturn(1);
   		final Integer actual = service.getDsaCount(filterParams).get();
   		assertNotNull(actual);
   		verify(mapper, times(1)).getDsaCount(filtersCaptor.capture());
   	}
    
    @Test
    public void testGetEtaSummary() throws Exception {
        final Map<String, Object> filterParams = new HashMap<String, Object>();
        filterParams.put("siteNumberIsIn", "7478|8691");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        filterParams.put("sortBy", "severity");
        filterParams.put("sortDir", "desc");

        List<AdvisoriesSummary> expectedSummary = new ArrayList<AdvisoriesSummary>();
        when(mapper.getEtaSummary(anyMap())).thenReturn(expectedSummary);
        final List<AdvisoriesSummary> actual = service.getEtaSummary(filterParams).get();
        assertNotNull(actual);
        
        // Verify that the getEtaSummary method was invoked with the correct parameters
        verify(mapper, times(1)).getEtaSummary(filterParams);
    }

    @Test
    public void testGetEsaSummary() throws Exception {
    	final Map<String, Object> filterParams = new HashMap<String, Object>();
        filterParams.put("siteNumberIsIn", "7478|8691");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        filterParams.put("sortBy", "severity");
        filterParams.put("sortDir", "desc");

        List<AdvisoriesSummary> expectedSummary = new ArrayList<AdvisoriesSummary>();
        when(mapper.getEsaSummary(anyMap())).thenReturn(expectedSummary);
        final List<AdvisoriesSummary> actual = service.getEsaSummary(filterParams).get();
        assertNotNull(actual);
        
        // Verify that the getEtaSummary method was invoked with the correct parameters
        verify(mapper, times(1)).getEsaSummary(filterParams);

    }
    
    @Test
    public void testGetAdvisorySerialized() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Pending");
        filterParams.put("severityFilterIsIn", "Low|OtherSeverity");
        filterParams.put("siteNumberIsIn", "7478|8691");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        filterParams.put("sortBy", "severity");
        filterParams.put("sortDir", "desc");
        filterParams.put("severityFilterIsIn", "Low");
        filterParams.put("uid", "123");
        filterParams.put("tagId", "0");
        List<SerializedProductBean> expectedSerializedProductBeans = new ArrayList<>();
        // Initialize expectedSerializedProductBeans with test data

        // Mock the methods in the advisoriesMapper
        Mockito.when(mapper.getEtaSerialized(any())).thenReturn(expectedSerializedProductBeans);
        Mockito.when(mapper.getEtaEventsSerialized(any())).thenReturn(new ArrayList<>());

        // Act
        SerializedResponseBean responseBean = service.getAdvisorySerialized(filterParams, "ETA");

        // Assert
        // Add your assertions to verify the behavior of the method and the properties of responseBean
        Assertions.assertEquals(expectedSerializedProductBeans.size(), responseBean.getTotalElementsCount());
        // Add more assertions as needed
    }
    
    @Test
    public void testGetAdvisorySerializedForCompleted() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Completed");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        // Add other required filter parameters
        List<SerializedProductBean> expectedSerializedProductBeans = new ArrayList<>();
        // Initialize expectedSerializedProductBeans with test data

        // Mock the methods in the advisoriesMapper
        Mockito.when(mapper.getEtaSerialized(any())).thenReturn(expectedSerializedProductBeans);
        Mockito.when(mapper.getEtaEventsSerialized(any())).thenReturn(new ArrayList<>());

        // Act
        SerializedResponseBean responseBean = service.getAdvisorySerialized(filterParams, "ETA");

        // Assert
        // Add your assertions to verify the behavior of the method for the "Completed" condition
        Assertions.assertEquals(expectedSerializedProductBeans.size(), responseBean.getTotalElementsCount());
        // Add more assertions as needed
    }

    @Test
    public void testGetAdvisorySerializedForOtherConditions() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        // Set filter parameters for other conditions you want to test
        filterParams.put("articleStatusIsIn", "Completed");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        List<SerializedProductBean> expectedSerializedProductBeans = new ArrayList<>();
        // Initialize expectedSerializedProductBeans with test data

        // Mock the methods in the advisoriesMapper
        Mockito.when(mapper.getEtaSerialized(any())).thenReturn(expectedSerializedProductBeans);
        Mockito.when(mapper.getEtaEventsSerialized(any())).thenReturn(new ArrayList<>());

        // Act
        SerializedResponseBean responseBean = service.getAdvisorySerialized(filterParams, "ETA");

        // Assert
        // Add your assertions to verify the behavior of the method for the other conditions
        Assertions.assertEquals(expectedSerializedProductBeans.size(), responseBean.getTotalElementsCount());
        // Add more assertions as needed
    }
    @Test
    public void testGetAdvisorySerializedWhenSerializedProductBeansNotEmpty() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Completed");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        List<SerializedProductBean> serializedProductBeans = new ArrayList<>();
        // Initialize serializedProductBeans with test data

        // Mock advisoriesMapper and events based on your condition
        Mockito.when(mapper.getEtaSerialized(any())).thenReturn(serializedProductBeans);
        Mockito.when(mapper.getEtaEventsSerialized(any())).thenReturn(new ArrayList<>());

        // Act
        SerializedResponseBean responseBean = service.getAdvisorySerialized(filterParams, "ETA");

        // Assert
        // Verify that responseBean properties are updated as expected
        Assertions.assertEquals(serializedProductBeans.size(), responseBean.getTotalElementsCount());
        // Add more assertions for other properties if needed
    }

    @Test
    public void testGetAdvisorySerializedWhenSerializedProductBeansEmpty() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Completed");
        filterParams.put("size", 25);
        filterParams.put("number", 1);
        List<SerializedProductBean> serializedProductBeans = new ArrayList<>();
        // Mock advisoriesMapper and events based on your condition
        Mockito.when(mapper.getEtaSerialized(any())).thenReturn(serializedProductBeans);
        Mockito.when(mapper.getEtaEventsSerialized(any())).thenReturn(new ArrayList<>());

        // Act
        SerializedResponseBean responseBean = service.getAdvisorySerialized(filterParams, "ETA");

        // Assert
        // Verify that responseBean properties are set as expected when serializedProductBeans is empty
        Assertions.assertEquals(0, responseBean.getTotalElementsCount());
        // Add more assertions for other properties if needed
    }
    @Test
    public void testUpdateArticleStatusFilter() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();

        // Act
        updateArticleStatusFilter(filterParams, "Pending");

        // Assert
        // Verify that the articleStatusIsIn is updated as expected
        Assertions.assertEquals("New|Reviewed|Work In Progress", filterParams.get("articleStatusIsIn"));

        // Act
        updateArticleStatusFilter(filterParams, "Completed");

        // Assert
        // Verify that the articleStatusIsIn is updated as expected
        Assertions.assertEquals("Remediated|Not Applicable", filterParams.get("articleStatusIsIn"));

        // Act
        filterParams.put("articleStatusIsIn", "Pending|Completed");
        updateArticleStatusFilter(filterParams, "Pending|Completed");

        // Assert
        // Verify that the articleStatusIsIn is updated as expected
        Assertions.assertEquals("Remediated|Not Applicable|New|Reviewed|Work In Progress", filterParams.get("articleStatusIsIn"));
    }

    private void updateArticleStatusFilter(Map<String, Object> filterParams, String articleStatus) {
        if (articleStatus != null) {
            if (articleStatus.equals("Pending")) {
                filterParams.put("articleStatusIsIn", "New|Reviewed|Work In Progress");
            } else if (articleStatus.equals("Completed")) {
                filterParams.put("articleStatusIsIn", "Remediated|Not Applicable");
            } else if (articleStatus.equals("Pending|Completed") || articleStatus.equals("Completed|Pending")) {
                filterParams.put("articleStatusIsIn", "Remediated|Not Applicable|New|Reviewed|Work In Progress");
            }
        }
    }   
    @Test
    public void testFilterBySearchString() throws Exception {
        // Arrange
        AdvisoriesServiceImpl advisoriesService = new AdvisoriesServiceImpl(mapper, template, objMapper, null);
        List<SerializedProductBean> inputList = new ArrayList<>();
        // Initialize inputList with test data
        String searchString = "Test";

        // Use reflection to access the private method
        Method method = AdvisoriesServiceImpl.class.getDeclaredMethod("filterBySearchString", List.class, String.class);
        method.setAccessible(true);

        // Act
        List<SerializedProductBean> filteredList = (List<SerializedProductBean>) method.invoke(advisoriesService, inputList, searchString);

        // Assert
        for (SerializedProductBean article : filteredList) {
            Assertions.assertTrue(
                containsIgnoreCase(article.getArticleId(), searchString) || 
                containsIgnoreCase(article.getAdvisoryId(), searchString) || 
                containsIgnoreCase(article.getAge(), searchString) ||
                containsIgnoreCase(article.getTitle(), searchString) ||
                containsIgnoreCase(article.getSeverity(), searchString) ||
                containsIgnoreCase(article.getSummary(), searchString) ||
                containsIgnoreCase(article.getResolution(), searchString) ||
                containsIgnoreCase(article.getStatus(), searchString) ||
                containsIgnoreCase(article.getLastUpdatedBy(), searchString) ||
                containsDateIgnoreCase(article.getFirstPublishedDate(), searchString) ||
                containsDateIgnoreCase(article.getLastPublishedDate(), searchString)
            );
        }
    }

    private boolean containsIgnoreCase(String source, String target) {
        return source != null && source.toUpperCase().contains(target.toUpperCase());
    }

    private boolean containsDateIgnoreCase(String source, String target) {
        try {
            // Attempt to parse the source as a date and compare it
            long sourceTimestamp = Long.parseLong(source);
            String sourceString = new SimpleDateFormat("dd MMM yyyy").format(new Date(sourceTimestamp));
            return containsIgnoreCase(sourceString, target);
        } catch (NumberFormatException e) {
            // If the source is not a valid timestamp, it cannot match the target
            return false;
        }
    }
    

    @Test
    public void testGetETASerializedTotalRecordWithNullFilterParams() {
        // Arrange
        Map<String, Object> filterParams = null;

        // Mock the behavior of advisoriesMapper
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(0);

        // Act
        Integer result = mapper.getETASerializedTotalRecord(filterParams);

        // Assert
        assertEquals(0, result.intValue());
    }

    @Test
    public void testGetETASerializedTotalRecordWithEmptyFilterParams() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();

        // Mock the behavior of advisoriesMapper
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(10);

        // Act
        Integer result = mapper.getETASerializedTotalRecord(filterParams);

        // Assert
        assertEquals(10, result.intValue());
    }

    @Test
    public void testGetETASerializedTotalRecordWithDifferentValues() {
        // Arrange
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Completed");
        filterParams.put("severityFilterIsIn", "Low");

        // Mock the behavior of advisoriesMapper
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(20);

        // Act
        Integer result = mapper.getETASerializedTotalRecord(filterParams);

        // Assert
        assertEquals(20, result.intValue());
    }
    @Test
    public void testAddNotesWithSerializedTrueAndPartnerRole() throws IOException {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("isSerialized", "true");
        filterParams.put("instanceSiteMap", "[{\"role\": \"Partner\"}]");
        filterParams.put("email", "partner@example.com");
        filterParams.put("userName", "Partner User");
        filterParams.put("advisoryType", "ESA");
        UserBean user = new UserBean();
        
        // Mock the behavior of the mapper (if necessary)
        
        // Act
        service.addNotes(filterParams, user);

        // Assert
        assertEquals("P", user.getIdentityType());
        assertEquals("partner@example.com", user.getEmail());
        assertEquals("Partner User", user.getFlname());
        // Add more assertions as needed
    }

    @Test
    public void testAddNotesWithSerializedTrueAndEmployeeRole() throws IOException {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("isSerialized", "true");
        filterParams.put("instanceSiteMap", "[{\"role\": \"Employee\"}]");
        filterParams.put("email", "employee@example.com");
        filterParams.put("userName", "Employee User");
        filterParams.put("advisoryType", "ESA");
        UserBean user = new UserBean();
        
        // Mock the behavior of the mapper (if necessary)
        
        // Act
        service.addNotes(filterParams, user);

        // Assert
        assertEquals("E", user.getIdentityType());
        assertEquals("employee@example.com", user.getEmail());
        assertEquals("Employee User", user.getFlname());
        // Add more assertions as needed
    }

    @Test
    public void testAddNotesWithSerializedTrueAndOtherRole() throws IOException {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("isSerialized", "true");
        
        // Create a valid JSON string for instanceSiteMap
        String instanceSiteMapJson = "[{\"role\": \"OtherRole\"}]";
        filterParams.put("instanceSiteMap", instanceSiteMapJson);
        filterParams.put("advisoryType", "ESA");
        filterParams.put("email", "other@example.com");
        filterParams.put("userName", "Other User");
        
        UserBean user = new UserBean();
        
        // Mock the behavior of the mapper (if necessary)
        
        // Act
        service.addNotes(filterParams, user);

        // Assert
        assertEquals("OtherRole", user.getIdentityType()); // Replace "OtherRole" with the expected role
        assertEquals("other@example.com", user.getEmail());
        assertEquals("Other User", user.getFlname());
        // Add more assertions as needed
    }

    @Test
    public void testAddNotesWithSerializedFalse() throws IOException {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("isSerialized", "false");
        filterParams.put("advisoryType", "ESA");
        // Provide a valid JSON object for instanceSiteMap
        filterParams.put("instanceSiteMap", "[{\"role\": \"Employee\"}]");
        filterParams.put("email", "other@example.com");
        filterParams.put("userName", "Other User");

        UserBean user = new UserBean();

        // Mock the behavior of the mapper (if necessary)

        // Act
        service.addNotes(filterParams, user);

        // Assert
        // Add assertions to verify user's properties when isSerialized is false
        assertNull(user.getIdentityType());
        // Add more assertions as needed
    }
    @Test
    public void testGetEsaNotes() throws InterruptedException, ExecutionException {
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "ESA";
        List<Note> esaNotes = new ArrayList<>();
        esaNotes.add(new Note());

        when(mapper.getEsaNotes(filterParams)).thenReturn(esaNotes);

        Future<List<Note>> result = service.getNotes(filterParams, advisoryType);

        assertEquals(esaNotes, result.get());
    }
    @Test
    public void testGetEtaNotes() throws InterruptedException, ExecutionException {
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "ETA";
        List<Note> etaNotes = new ArrayList<>();
        etaNotes.add(new Note());

        when(mapper.getEtaNotes(filterParams)).thenReturn(etaNotes);

        Future<List<Note>> result = service.getNotes(filterParams, advisoryType);

        assertEquals(etaNotes, result.get());
    }
    @Test
    public void testGetNotesForSerializedProduct_Esa() throws InterruptedException, ExecutionException {
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "ESA";
        List<IpsNote> esaNotes = new ArrayList<>();
        // Add some test notes to esaNotes
        IpsNote note1 = new IpsNote();
        note1.setRecordType("note");
        note1.setTimestamp(1L);
        note1.setUserName("User1");
        note1.setEmail("user1@example.com");
        note1.setNtId("user1");
        note1.setAdvisoryNote("Note 1");
        note1.setRole("Role1");
        note1.setResolution("Resolution1");
        note1.setArticleId("Article1");
        note1.setInstanceId("Instance1");
        note1.setFlag("Flag1");
        note1.setCompanyName("Company1");
        note1.setProductId("Product1");
        

        IpsNote event1 = new IpsNote();
        event1.setRecordType("event");
        event1.setTimestamp(2L);
        event1.setUserName("User2");
        event1.setEmail("user2@example.com");
        event1.setNtId("user2");
        event1.setAdvisoryNote("Event 1");
        event1.setRole("Role2");
        event1.setResolution("Resolution2");
        event1.setArticleId("Article2");
        event1.setInstanceId("Instance2");
        event1.setFlag("Flag2");
        event1.setCompanyName("Company2");
        event1.setProductId("Product2");
        

        // Continue setting up other IpsNote objects

        // Modify the assertions
        esaNotes.add(event1);
        esaNotes.add(note1);
        // Mock the advisoriesMapper
        when(mapper.getEsaNotesSerialized(filterParams)).thenReturn(esaNotes);

        Future<List<IpsNote>> result = service.getNotesForSerializedProduct(filterParams, advisoryType);

        // Verify that the filtering, deduplication, and sorting are performed correctly
        assertEquals(esaNotes, result.get());
        // Add more assertions to verify the result
    }
    @Test
    public void testGetNotesForSerializedProduct_Eta() throws InterruptedException, ExecutionException {
        Map<String, Object> filterParams = new HashMap<>();
        String advisoryType = "ETA";
        List<IpsNote> etaNotes = new ArrayList<>();
        // Add some test notes to etaNotes
        IpsNote note1 = new IpsNote();
        note1.setRecordType("note");
        note1.setTimestamp(1L);
        note1.setUserName("User1");
        note1.setEmail("user1@example.com");
        note1.setNtId("user1");
        note1.setAdvisoryNote("Note 1");
        note1.setRole("Role1");
        note1.setResolution("Resolution1");
        note1.setArticleId("Article1");
        note1.setInstanceId("Instance1");
        note1.setFlag("Flag1");
        note1.setCompanyName("Company1");
        note1.setProductId("Product1");
        

        IpsNote event1 = new IpsNote();
        event1.setRecordType("event");
        event1.setTimestamp(2L);
        event1.setUserName("User2");
        event1.setEmail("user2@example.com");
        event1.setNtId("user2");
        event1.setAdvisoryNote("Event 1");
        event1.setRole("Role2");
        event1.setResolution("Resolution2");
        event1.setArticleId("Article2");
        event1.setInstanceId("Instance2");
        event1.setFlag("Flag2");
        event1.setCompanyName("Company2");
        event1.setProductId("Product2");
        

        // Continue setting up other IpsNote objects

        // Modify the assertions
        etaNotes.add(event1);
        etaNotes.add(note1);
        // Mock the advisoriesMapper
        when(mapper.getEtaNotesSerialized(filterParams)).thenReturn(etaNotes);

        Future<List<IpsNote>> result = service.getNotesForSerializedProduct(filterParams, advisoryType);

        // Verify that the filtering, deduplication, and sorting are performed correctly
        assertEquals(etaNotes, result.get());
        // Add more assertions to verify the result
    }
    @Test
    public void testGetESASerializedTotalRecord() {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "YourArticleStatusValue");
        filterParams.put("severityFilterIsIn", "Low|OtherSeverity");

        // Define the expected result from advisoriesMapper
        int expectedTotalRecord = 42;
        when(mapper.getESASerializedTotalRecord(filterParams)).thenReturn(expectedTotalRecord);

        // Call the method under test
        Future<Integer> result = service.getESASerializedTotalRecord(filterParams);

        // Wait for the result (use CompletableFuture to block until it's available)
        CompletableFuture<Integer> futureResult = CompletableFuture.supplyAsync(() -> {
            try {
                return result.get();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });

        // Verify that advisoriesMapper was called with the correct filterParams
        verify(mapper).getESASerializedTotalRecord(filterParams);

        // Verify the result
        try {
            Integer actualTotalRecord = futureResult.get();
            assertEquals(expectedTotalRecord, actualTotalRecord.intValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testGetETASerializedTotalRecord() {
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "YourArticleStatusValue");
        filterParams.put("severityFilterIsIn", "Low|OtherSeverity");

        // Define the expected result from advisoriesMapper
        int expectedTotalRecord = 42;
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(expectedTotalRecord);

        // Call the method under test
        Future<Integer> result = service.getETASerializedTotalRecord(filterParams);

        // Wait for the result (use CompletableFuture to block until it's available)
        CompletableFuture<Integer> futureResult = CompletableFuture.supplyAsync(() -> {
            try {
                return result.get();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });

        // Verify that advisoriesMapper was called with the correct filterParams
        verify(mapper).getETASerializedTotalRecord(filterParams);

        // Verify the result
        try {
            Integer actualTotalRecord = futureResult.get();
            assertEquals(expectedTotalRecord, actualTotalRecord.intValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testGetETASerializedTotalRecord_ArticleStatusNotNull() {
        // Define your filterParams
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Pending");
        filterParams.put("severityFilterIsIn", "Low|OtherSeverity");

        // Define the expected result
        int expectedTotalRecord = 42;

        // Mock the behavior of advisoriesMapper
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(expectedTotalRecord);

        // Call the method under test
        Future<Integer> result = service.getETASerializedTotalRecord(filterParams);

        // Wait for the result (use CompletableFuture to block until it's available)
        CompletableFuture<Integer> futureResult = CompletableFuture.supplyAsync(() -> {
            try {
                return result.get();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });

        // Verify that advisoriesMapper was called with the correct filterParams
        verify(mapper).getETASerializedTotalRecord(filterParams);

        // Verify the result
        try {
            Integer actualTotalRecord = futureResult.get();
            assertEquals(expectedTotalRecord, actualTotalRecord.intValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetETASerializedTotalRecord_ArticleStatusNull() {
        // Define your filterParams with null articleStatusIsIn
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("severityFilterIsIn", "Low|OtherSeverity");

        // Define the expected result
        int expectedTotalRecord = 42;

        // Mock the behavior of advisoriesMapper
        when(mapper.getETASerializedTotalRecord(filterParams)).thenReturn(expectedTotalRecord);

        // Call the method under test
        Future<Integer> result = service.getETASerializedTotalRecord(filterParams);

        // Wait for the result (use CompletableFuture to block until it's available)
        CompletableFuture<Integer> futureResult = CompletableFuture.supplyAsync(() -> {
            try {
                return result.get();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });

        // Verify that advisoriesMapper was called with the correct filterParams
        verify(mapper).getETASerializedTotalRecord(filterParams);

        // Verify the result
        try {
            Integer actualTotalRecord = futureResult.get();
            assertEquals(expectedTotalRecord, actualTotalRecord.intValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testGetAdvisorySerializedWithTagIdNotZero() {
        // Arrange
    	AdvisoriesServiceImpl advisoriesService = new AdvisoriesServiceImpl(mapper, template, objMapper, subscriptionDetailsService);
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Pending");
        filterParams.put("severityFilterIsIn", "Low");
        filterParams.put("searchSerializedIsLike", "searchQuery");
        filterParams.put("size", 10);
        filterParams.put("number", 1);
        filterParams.put("sortBy", "status");
        filterParams.put("sortDir", "desc");
        filterParams.put("uid", "userId");
        filterParams.put("tagId", "1");
        MockHttpServletRequest mockRequest = new MockHttpServletRequest();
        mockRequest.addHeader("profileId", "text/html");
        advisoriesService.request = mockRequest;
        ObjectMapper mapper1 = new ObjectMapper();
       
        String advisoryType = "ESA";
        SerializedResponseBean responseBean = new SerializedResponseBean();
        responseBean.setSubscriptionAlertEnabled(true);

        // Mocking external dependencies
        when(mapper.getProductNames(filterParams)).thenReturn("ProductName");
        when(subscriptionDetailsService.getSubscriptionDetails(anyString())).thenReturn(getMockSubscriptionDetails());
        when(mapper.getEtaSerialized(filterParams)).thenReturn(getMockSerializedProductBeans());
        when(mapper.getEtaEventsSerialized(filterParams)).thenReturn(getMockSerializedAdvisoryEvents());
        when(mapper.getEsaSerialized(filterParams)).thenReturn(getMockSerializedProductBeans());
        when(mapper.getEsaEventsSerialized(filterParams)).thenReturn(getMockSerializedAdvisoryEvents());

        // Act
        SerializedResponseBean result = advisoriesService.getAdvisorySerialized(filterParams, advisoryType);

        // Assert
        assertTrue(result.isSubscriptionAlertEnabled());
        assertEquals(0, result.getTotalElementsCount());
    }
    @Test
    public void testGetAdvisorySerializedETAWithTagIdNotZero() {
        // Arrange
    	AdvisoriesServiceImpl advisoriesService = new AdvisoriesServiceImpl(mapper, template, objMapper, subscriptionDetailsService);
        Map<String, Object> filterParams = new HashMap<>();
        filterParams.put("articleStatusIsIn", "Pending");
        filterParams.put("severityFilterIsIn", "Low");
        filterParams.put("searchSerializedIsLike", "searchQuery");
        filterParams.put("size", 10);
        filterParams.put("number", 1);
        filterParams.put("sortBy", "status");
        filterParams.put("sortDir", "desc");
        filterParams.put("uid", "userId");
        filterParams.put("tagId", "1");
        MockHttpServletRequest mockRequest = new MockHttpServletRequest();
        mockRequest.addHeader("profileId", "text/html");
        advisoriesService.request = mockRequest;
        ObjectMapper mapper1 = new ObjectMapper();
       
        String advisoryType = "ETA";
        SerializedResponseBean responseBean = new SerializedResponseBean();
        responseBean.setSubscriptionAlertEnabled(true);

        // Mocking external dependencies
        when(mapper.getProductNames(filterParams)).thenReturn("ProductName");
        when(subscriptionDetailsService.getSubscriptionDetails(anyString())).thenReturn(getMockSubscriptionDetails());
        when(mapper.getEtaSerialized(filterParams)).thenReturn(getMockSerializedProductBeans());
        when(mapper.getEtaEventsSerialized(filterParams)).thenReturn(getMockSerializedAdvisoryEvents());
        when(mapper.getEsaSerialized(filterParams)).thenReturn(getMockSerializedProductBeans());
        when(mapper.getEsaEventsSerialized(filterParams)).thenReturn(getMockSerializedAdvisoryEvents());

        // Act
        SerializedResponseBean result = advisoriesService.getAdvisorySerialized(filterParams, advisoryType);

        // Assert
        assertFalse(result.isSubscriptionAlertEnabled());
        assertEquals(0, result.getTotalElementsCount());
    }

    private Map<String, Object> getMockSubscriptionDetails() {
        Map<String, Object> subscriptionDetails = new HashMap<>();
        subscriptionDetails.put("subscriptions", getMockSubscriptionsMap());
        return subscriptionDetails;
    }

    private List<Map<String, Object>> getMockSubscriptionsMap() {
        List<Map<String, Object>> subscriptionsMap = new ArrayList<>();

        Map<String, Object> subscription = new HashMap<>();
        subscription.put("subDetails", getMockSubDetails());
        subscriptionsMap.add(subscription);

        return subscriptionsMap;
    }

    private List<Map<String, Object>> getMockSubDetails() {
        List<Map<String, Object>> subDetails = new ArrayList<>();

        Map<String, Object> subDetail = new HashMap<>();
        subDetail.put("productName", "ProductName");
        subDetail.put("dsa", true);
        subDetail.put("dta", false);
        subDetails.add(subDetail);

        return subDetails;
    }

    private List<SerializedProductBean> getMockSerializedProductBeans() {
        List<SerializedProductBean> serializedProductBeans = new ArrayList<>();

        SerializedProductBean productBean1 = new SerializedProductBean();
        productBean1.setStatus("New");
        productBean1.setSeverity("Critical");
        productBean1.setLastUpdatedBy("User1");
        productBean1.setLastUpdatedDate("2023-01-02T12:34:56");

        SerializedProductBean productBean2 = new SerializedProductBean();
        productBean2.setStatus("In Progress");
        productBean2.setSeverity("High");
        productBean2.setLastUpdatedBy("User2");
        productBean2.setLastUpdatedDate("2023-01-01T12:34:56");

        serializedProductBeans.add(productBean1);
        serializedProductBeans.add(productBean2);

        return serializedProductBeans;
    }

    private List<SerializedAdvisoryEvent> getMockSerializedAdvisoryEvents() {
        List<SerializedAdvisoryEvent> advisoryEvents = new ArrayList<>();

        SerializedAdvisoryEvent event1 = new SerializedAdvisoryEvent();
        event1.setArticleNumber("Article1");
        event1.setInstanceNumber("Instance1");
        event1.setStatus("Resolved");
        event1.setLastUpdatedBy("User1");
        event1.setLastUpdatedDate("2023-01-02T12:34:56");

        SerializedAdvisoryEvent event2 = new SerializedAdvisoryEvent();
        event2.setArticleNumber("Article2");
        event2.setInstanceNumber("Instance2");
        event2.setStatus("Closed");
        event2.setLastUpdatedBy("User2");
        event2.setLastUpdatedDate("2023-01-01T12:34:56");

        advisoryEvents.add(event1);
        advisoryEvents.add(event2);

        return advisoryEvents;
    }
    @Test
    public void testInsertDtaAuditRecord1() throws Exception {
        JdbcTemplate mockJdbcTemplate = mock(JdbcTemplate.class);
        
        List<Map<String, Object>> etaInstanceMaps = new ArrayList<>(); // Prepare some mock data
        UserBean user = new UserBean(); // Mock UserBean
        user.setUid("123");
        // ... set other user properties

        // ... prepare the etaInstanceMaps with test data

        String expectedJson = "{\"your\":\"expectedJson\"}"; // Create an expected JSON value
        
        doAnswer(invocation -> {
            // This simulates how the PreparedStatement would be handled in the method
            BatchPreparedStatementSetter setter = invocation.getArgument(1);
            setter.setValues(mock(PreparedStatement.class), 0); // Assuming a single item for simplicity
            return null;
        }).when(mockJdbcTemplate).batchUpdate(anyString(), any(BatchPreparedStatementSetter.class));

        service.insertDtaAuditRecord(etaInstanceMaps, user, "Test Event");

        // Assertions here might involve the behavior you expect after the method call, rather than the exact internal database behavior.
    }

}
