package com.emc.dvs.ib.aspect;

import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.annotation.Aspect;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import static org.junit.Assert.assertNull;

@Aspect
@Component
@SpringBootTest({"server.port:0", "spring.cloud.config.enabled:false"})
public class SqlInjectionAspectTests {
	
	@InjectMocks
	private SqlInjectionAspect aspect;	
	private MockHttpServletRequest request;
	private List<String> dbParams=new ArrayList<>();

	@Before
	public void setup() {		
		MockitoAnnotations.initMocks(this);		
		request = new MockHttpServletRequest();	
		dbParams.add("esaDateBefore");
		dbParams.add("esaDateAfter");
		dbParams.add("etaDateBefore");
		dbParams.add("etaDateAfter");
		aspect.setRegex("\\b(DATABASE|DATABASE()|TABLE|ALTER|CREATE|DELETE|DROP|OR|EXEC(UTE){0,1}|INSERT( +INTO){0,1}|MERGE|SELECT|UPDATE|UNION( +ALL){0,1})\\b");
		aspect.setDbparams(dbParams);
		aspect.setRequest(request);	
	}
	
	@Test
	public void testValidParams() {
		request.setParameter("esaDateAfter", "2021-12-09");		
		Object result = aspect.validateSqlInjectionParams();
		assertNull(result);
	}
	
	@Test(expected=HttpClientErrorException.class)
	public void testInvalidParams() {
		request.setParameter("esaDateAfter", "2021-12-09 or 1=1");		
		aspect.validateSqlInjectionParams();
	}

}
