package com.emc.dvs.ib.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.matches;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import com.emc.dvs.export.StreamResultHandler;
import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ConnectHomeDurationBean;
import com.emc.dvs.ib.domain.ConnectivityAggBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.Entitlement;
import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsChangeEventBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.domain.GatewayBean;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseProductBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.MilestoneStatsBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.ProductSiteChangeBean;
import com.emc.dvs.ib.domain.WarrantyResponse;
import com.emc.dvs.ib.exception.ResourceNotFoundException;
import com.emc.dvs.ib.persistance.InstallBaseMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

@SpringBootTest({ "server.port:0", "spring.cloud.config.enabled:false" })
public class InstallBaseServiceImplTests {

	@InjectMocks
	private InstallBaseServiceImpl service;

	@Mock
	private MailService mailService;

	@Mock
	private InstallBaseMapper mapper;

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private EsrsService esrsService;

	@Captor
	private ArgumentCaptor<Map<String, Object>> filtersCaptor;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		service.setDefaultConnectHomeStatusDuration(726L);
		service.setSendEmailDuration(86400000L);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetInstallBaseSiteList() {
		// Test the list passed to the mapper
		when(mapper.getInstallBaseStats(anyMap())).thenReturn(new InstallBaseStatsBean());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		service.getInstallBaseStats(filterParams);

		verify(mapper, times(1)).getInstallBaseStats(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
	}

	@Test
	public void testInstallBaseGeoSiteWithFilters() throws Exception {
		// Test the list is added to the existing filterParams argument
		when(mapper.getInstallBaseStats(anyMap())).thenReturn(new InstallBaseStatsBean());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		InstallBaseStatsBean actual = service.getInstallBaseStats(filterParams).get();

		verify(mapper, times(1)).getInstallBaseStats(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
		assertNotNull(actual);
	}

	@Test
	public void testGetInstallBaseConnectedPercent() throws Exception {
		// Test that the connected value is correctly set
		InstallBaseStatsBean stats = new InstallBaseStatsBean();
		stats.setConnected(10);
		stats.setTotal(200);
		stats.setNotConnectedEligible(100);
		when(mapper.getInstallBaseStats(anyMap())).thenReturn(stats);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		InstallBaseStatsBean actual = service.getInstallBaseStats(filterParams).get();

		assertEquals(10f, actual.getConnectedPercent(), 0.0000);
	}

	@Test
	public void testGetInstallBaseZeroConnectedPercent() throws Exception {
		// Test that there is no attempt to avoid by 0
		InstallBaseStatsBean stats = new InstallBaseStatsBean();
		stats.setConnectedPercent(50); // The default % is 0 so we need to test
										// for something else
		when(mapper.getInstallBaseStats(anyMap())).thenReturn(stats);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		InstallBaseStatsBean actual = service.getInstallBaseStats(filterParams).get();

		assertEquals(50, actual.getConnectedPercent());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInstallBaseGeoDetails() throws Exception {
		// Test the list passed to the mapper
		when(mapper.getInstallBaseGeoDetails(anyMap()))
				.thenReturn(new ArrayList<InstallBaseGeoBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<InstallBaseGeoBean> actual = service.getInstallBaseGeoDetails(filterParams).get();

		verify(mapper, times(1)).getInstallBaseGeoDetails(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);
	}

	@Test
	public void testInstallBaseGeoDetailsWithFilters() throws Exception {
		// Test the list is added to the existing filterParams argument
		when(mapper.getInstallBaseGeoDetails(anyMap()))
				.thenReturn(new ArrayList<InstallBaseGeoBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		List<InstallBaseGeoBean> actual = service.getInstallBaseGeoDetails(filterParams).get();

		verify(mapper, times(1)).getInstallBaseGeoDetails(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
		assertNotNull(actual);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetInstallBaseFilterValues() throws Exception {
		// test the list of sites is passed to the mapper and the two calls are
		// merged into one result
		InstallBaseFilterValuesBean filterValues = new InstallBaseFilterValuesBean();
		filterValues.setIbStatusList("ibStatus");
		filterValues.setProductFamilyList("productFamilyList");
		filterValues.setSiteDisplayNameList("siteDisplayName");
		filterValues.setTlaFlagList("Y|N");

		when(mapper.getInstallBaseAllFilterValues(anyMap())).thenReturn(filterValues);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		InstallBaseFilterValuesBean actual = service.getInstallBaseFilterValues(filterParams).get();

		verify(mapper, times(1)).getInstallBaseAllFilterValues(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();

		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);
		assertEquals("ibStatus", actual.getIbStatus().get(0));
		assertEquals("productFamilyList", actual.getProductFamily().get(0));
		assertEquals("siteDisplayName", actual.getSiteDisplayName().get(0));
		assertEquals("Y", actual.getTlaFlag().get(0));
		assertEquals("N", actual.getTlaFlag().get(1));
	}

	@Test
	public void testGetSerialNumbers() throws Exception {
		when(mapper.getInstallBaseSerialNumbers(anyMap()))
				.thenReturn(Arrays.asList("serialNumber", "serialNumber1"));
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<String> actual = service.getSerialNumbers(filterParams);
		verify(mapper, times(1)).getInstallBaseSerialNumbers(anyMap());
		assertEquals(2, actual.size());
	}

	@Test
	public void testGetInstanceNumbers() throws Exception {
		when(mapper.getInstallBaseInstanceNumbers(anyMap()))
				.thenReturn(Arrays.asList("instanceNumber", "instanceNumber1"));
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<String> actual = service.getInstanceIds(filterParams);
		verify(mapper, times(1)).getInstallBaseInstanceNumbers(anyMap());
		assertEquals(2, actual.size());
	}

	@Test
	public void testGetProductNames() throws Exception {
		when(mapper.getInstallBaseProductNames(anyMap()))
				.thenReturn(Arrays.asList("productName", "productName1"));
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<String> actual = service.getProductNames(filterParams).get();
		verify(mapper, times(1)).getInstallBaseProductNames(anyMap());
		assertEquals(2, actual.size());
	}

	@Test
	public void testGetContractStatus() throws Exception {
		when(mapper.getContractStatus(anyMap()))
				.thenReturn(Arrays.asList("contractStatus", "contractStatus1"));
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<String> actual = service.getContractStatus(filterParams).get();
		verify(mapper, times(1)).getContractStatus(anyMap());
		assertEquals(2, actual.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetInstallBaseFilterValuesEmpty() throws Exception {
		// asserts that the filter is an empty array when no values are in the
		// DB
		InstallBaseFilterValuesBean filterValues = new InstallBaseFilterValuesBean();

		when(mapper.getInstallBaseAllFilterValues(anyMap())).thenReturn(filterValues);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		InstallBaseFilterValuesBean actual = service.getInstallBaseFilterValues(filterParams).get();

		verify(mapper, times(1)).getInstallBaseAllFilterValues(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();

		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetConnectivityAggregate() throws Exception {
		List<ConnectivityAggBean> list = new ArrayList<ConnectivityAggBean>();
		ConnectivityAggBean b1 = new ConnectivityAggBean();
		b1.setConnectionType("ESRS");
		b1.setProductFamily("AVAMAR");
		b1.setConnectFlag("Connected");
		b1.setConnectionTypeCount(2);
		b1.setProductFamilyCount(2);
		ConnectivityAggBean b2 = new ConnectivityAggBean();
		b2.setConnectionType("ESRS");
		b2.setProductFamily("AVAMAR");
		b2.setConnectFlag("Connected");
		b2.setConnectionTypeCount(3);
		b2.setProductFamilyCount(3);
		ConnectivityAggBean b3 = new ConnectivityAggBean();
		b3.setConnectionType("EMAIL HOME");
		b3.setProductFamily("XTREMIO");
		b3.setConnectFlag("Not Connected");
		b3.setConnectionTypeCount(4);
		b3.setProductFamilyCount(4);
		ConnectivityAggBean b4 = new ConnectivityAggBean();
		b4.setConnectionType("EMAIL HOME");
		b4.setProductFamily("XTREMIO");
		b4.setConnectFlag("Not Connected");
		b4.setConnectionTypeCount(5);
		b4.setProductFamilyCount(5);
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);
		when(mapper.getConnectivityAggregate(anyMap())).thenReturn(list);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		Map<String, Object> actual = service.getConnectivityAggregate(filterParams).get();

		assertNotNull(actual);
		assertEquals(5, ((Map<String, Object>) ((Map<String, Object>) actual.get("connected")).get("connectionTypeMap"))
				.get("ESRS"));
		assertEquals(5, ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) actual.get("connected"))
				.get("productFamilyMap")).get("AVAMAR")).get("ESRS"));

		assertEquals(9,
				((Map<String, Object>) ((Map<String, Object>) actual.get("notConnected")).get("connectionTypeMap"))
						.get("EMAIL HOME"));
		assertEquals(9, ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) actual.get("notConnected"))
				.get("productFamilyMap")).get("XTREMIO")).get("EMAIL HOME"));

		verify(mapper, times(1)).getConnectivityAggregate(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetConnectivityAggregateForNull() throws Exception {
		List<ConnectivityAggBean> list = new ArrayList<ConnectivityAggBean>();
		when(mapper.getConnectivityAggregate(anyMap())).thenReturn(list);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		Map<String, Object> actual = service.getConnectivityAggregate(filterParams).get();

		assertNotNull(actual);
		assertNotNull(actual.get("connected"));
		assertNotNull(((Map<String, Object>) actual.get("connected")).get("connectionTypeMap"));
		assertNotNull(((Map<String, Object>) actual.get("connected")).get("productFamilyMap"));
		assertNull((List<ConnectivityAggBean>) ((Map<String, Object>) ((Map<String, Object>) actual.get("connected"))
				.get("connectionTypeMap")).get("ESRS"));
		assertNull((List<ConnectivityAggBean>) ((Map<String, Object>) ((Map<String, Object>) actual.get("connected"))
				.get("productFamilyMap")).get("AVAMAR"));

		assertNotNull(actual.get("notConnected"));
		assertNotNull(((Map<String, Object>) actual.get("notConnected")).get("connectionTypeMap"));
		assertNotNull(((Map<String, Object>) actual.get("notConnected")).get("productFamilyMap"));
		assertNull((List<ConnectivityAggBean>) ((Map<String, Object>) ((Map<String, Object>) actual.get("notConnected"))
				.get("connectionTypeMap")).get("EMAIL HOME"));
		assertNull((List<ConnectivityAggBean>) ((Map<String, Object>) ((Map<String, Object>) actual.get("notConnected"))
				.get("productFamilyMap")).get("XTREMIO"));

		verify(mapper, times(1)).getConnectivityAggregate(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
	}

	@Test
	public void testGetConnectivityTotalRecord() throws Exception {
		when(mapper.getConnectivityTotalRecord(anyMap()))
		.thenReturn(10000);
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		int actual = service.getConnectivityTotalRecord(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getConnectivityTotalRecord(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
	}

	@Test
	public void testGetConnectivityList() throws Exception {
		List<ConnectivityProductBean> products = new ArrayList<ConnectivityProductBean>();
		ConnectivityProductBean p1 = new ConnectivityProductBean();
		p1.setConnectionType("connectionType");
		p1.setIbStatus("Install");
		products.add(p1);
		ConnectivityProductBean p2 = new ConnectivityProductBean();
		products.add(p2);
		p2.setIbStatus("INStaLL");
		ConnectivityProductBean p3 = new ConnectivityProductBean();
		p3.setConnectionType("");
		p3.setIbStatus("ibStatsususd");
		products.add(p3);

		when(mapper.getConnectivityList(anyMap())).thenReturn(products);

		List<ConnectivityProductBean> actual = service.getConnectivityList(new HashMap<String, Object>()).get();

		verify(mapper, times(1)).getConnectivityList(anyMap());

		assertEquals("connectionType", actual.get(0).getConnectionType());

	}

	@Test
	public void testGetConnectivityListWithSizeInFilterParams() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", 10); // Add the "size" key

		// Call the method with filterParams containing "size"
		service.getConnectivityList(new ByteArrayOutputStream(), filterParams, new ArrayList<Column>());

		// Assertions to verify that the "size" key is removed from filterParams
		assertFalse(filterParams.containsKey("size"));
	}

	private List<String> getSiteList() {
		List<String> sites = new ArrayList<String>();
		sites.add("1234");
		sites.add("5678");
		sites.add("9012");
		sites.add("3456");
		return sites;
	}

	@Test
	public void testGetCodeLevelsTotalRecord() throws Exception {
		when(mapper.getCodeLevelsTotalRecord(anyMap()))
		.thenReturn(10000);
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		int actual = service.getCodeLevelsTotalRecord(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getCodeLevelsTotalRecord(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
	}

	@SuppressWarnings({ "unchecked", "unused" })
	@Test
	public void testGetCodeLevelsProducts() throws Exception {
		List<CodeLevelsProductBean> list = new ArrayList<CodeLevelsProductBean>();
		CodeLevelsProductBean b1 = new CodeLevelsProductBean();
		b1.setIbStatus("Install");
		list.add(b1);
		CodeLevelsProductBean b2 = new CodeLevelsProductBean();
		b2.setIbStatus("INStaLL");
		list.add(b2);
		CodeLevelsProductBean b3 = new CodeLevelsProductBean();
		b3.setIbStatus("ibStatsususd");
		list.add(b3);
		when(mapper.getCodeLevelsProducts(anyMap())).thenReturn(list);

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<CodeLevelsProductBean> actual = service.getCodeLevelsProducts(filterParams).get();

		verify(mapper, times(1)).getCodeLevelsProducts(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
	}

	@Test
	public void testGetCodeLevelsProductsWithEmptyFilter() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		List<CodeLevelsProductBean> actual = service.getCodeLevelsProducts(filterParams).get();
		assertTrue(actual.isEmpty());
	}

	@Test
	public void testGetCodeLevelsProductsWithInvalidSiteId() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", Arrays.asList("invalidSiteId"));
		List<CodeLevelsProductBean> actual = service.getCodeLevelsProducts(filterParams).get();
		assertTrue(actual.isEmpty());
	}

	@Test
	public void testCodeLevelsProductsWithFilters() throws Exception {
		// Test the list is added to the existing filterParams argument
		when(mapper.getCodeLevelsProducts(anyMap()))
				.thenReturn(new ArrayList<CodeLevelsProductBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		filterParams.put("codeLevelCategoryIsIn", "TargetPlus");
		List<CodeLevelsProductBean> actual = service.getCodeLevelsProducts(filterParams).get();

		verify(mapper, times(1)).getCodeLevelsProducts(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
		String capturedCodeLevel = (String) filters.get("codeLevelCategoryIsIn");
		assertEquals("TargetPlus", capturedCodeLevel);
		assertNotNull(actual);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetCodeLevelsAggregate() throws Exception {
		when(mapper.getCodeLevelsAggregate(anyMap()))
		.thenReturn(new ArrayList<CodeLevelsAggBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<CodeLevelsAggBean> actual = service.getCodeLevelsAggregate(filterParams);
		
		verify(mapper, times(1)).getCodeLevelsAggregate(filtersCaptor.capture());
		
		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetContractCategoryAggregate() throws Exception {
		// Test the list passed to the mapper
		when(mapper.getContractCategoryAggregate(anyMap()))
				.thenReturn(new ArrayList<ContractCategoryBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<ContractCategoryBean> actual = service.getContractCategoryAggregate(filterParams);

		verify(mapper, times(1)).getContractCategoryAggregate(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);
	}

	@Test
	public void testGetContractCategoryAggregateWithFilters() throws Exception {
		// Test the list is added to the existing filterParams argument
		when(mapper.getContractCategoryAggregate(anyMap()))
				.thenReturn(new ArrayList<ContractCategoryBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		List<ContractCategoryBean> actual = service.getContractCategoryAggregate(filterParams);

		verify(mapper, times(1)).getContractCategoryAggregate(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
		assertNotNull(actual);
	}

	@Test
	public void testGetContractTimelineTotal() throws Exception {
		when(mapper.getContractTimelineTotal(anyMap()))
		.thenReturn(10000);
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		int actual = service.getContractTimelineTotal(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getContractTimelineTotal(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
	}

	@Test
	public void testGetContractTimeline() throws Exception {
		// Test the list is added to the existing filterParams argument
		when(mapper.getContractTimeline(anyMap()))
				.thenReturn(new ArrayList<ContractTimelineBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		List<ContractTimelineBean> actual = service.getContractTimeline(filterParams).get();

		verify(mapper, times(1)).getContractTimeline(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
		assertNotNull(actual);
	}

	@Test
	public void testGetContractInventoryTotal() throws Exception {
		when(mapper.getContractInventoryTotal(anyMap()))
		.thenReturn(10000);
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("tlaFlagIsLike", "Y");
		filterParams.put("siteIds", getSiteList());
		int actual = service.getContractInventoryTotal(filterParams).get();
		assertEquals(10000, actual);
		verify(mapper, times(1)).getContractInventoryTotal(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		String capturedTlaValue = (String) filters.get("tlaFlagIsLike");
		assertEquals("Y", capturedTlaValue);
	}

	@Test
	public void testGetContractInventoryWithSizeInFilterParams() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("size", 10);

		// Call the method with 'size' in 'filterParams'
		service.getContractInventory(new ByteArrayOutputStream(), filterParams, new ArrayList<Column>());

		// Assertions to verify that "size" is removed from 'filterParams'
		assertFalse(filterParams.containsKey("size"));
	}

	@Test
	public void testGetContractInventoryWithEmptyCols() throws Exception {
		Map<String, Object> filterParams = new HashMap<String, Object>();
		List<Column> cols = new ArrayList<>();

		// Call the method with an empty 'cols' list
		service.getContractInventory(new ByteArrayOutputStream(), filterParams, cols);

		// Add assertions to verify the behavior
	}

	@Test
	public void testGetProductDetailWithConnectedProduct() {
		// Create a sample ProductBean with CONNECTED connectFlag
		ProductBean connectedProduct = new ProductBean();
		connectedProduct.setConnectFlag("CONNECTED");
		connectedProduct.setProductFamily("SampleProductFamily");

		// Mock the mapper to return a list containing the connected product
		when(mapper.getProductDetail(anyMap())).thenReturn(Collections.singletonList(connectedProduct));

		// Call the method with filterParams
		Map<String, Object> filterParams = new HashMap<>();
		ProductBean result = service.getProductDetail(filterParams);

		// Assertions
		assertNotNull(result);
		assertEquals("CONNECTED", result.getConnectFlag());
		// Add assertions for the connectHomeStatusDuration if needed
	}

	@Test
	public void testGetProductsWithNonEmptyCols() {
		// Prepare test data
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Map<String, Object> filterParams = new HashMap<>();
		List<Column> cols = new ArrayList<>();
		cols.add(new Column());

		// Call the method with non-empty cols
		service.getProducts(outputStream, filterParams, cols);

		// No specific assertions are needed for this test, as it's intended to cover
		// the code path.
		// Ensure the test runs without exceptions.
	}

	@Test
	public void testGetProductsWithSizeInFilterParams() {
		// Prepare test data
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", 10); // Add the "size" key

		// Call the method with filterParams containing "size"
		service.getProducts(outputStream, filterParams, new ArrayList<Column>());

		// Assertions to verify that the "size" key is removed from filterParams
		assertFalse(filterParams.containsKey("size"));
	}

	@Test
	public void testGetChangesAndSubmissionTimelineRangeEventCount() {
		// Prepare test data
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("filterBy", "All");

		// Define sample events for the mock
		List<Map<String, Object>> sampleEvents = new ArrayList<>();
		Map<String, Object> event1 = new HashMap<>();
		event1.put("date", "123.45");
		event1.put("count", "10");
		Map<String, Object> event2 = new HashMap<>();
		event2.put("date", "678.90");
		event2.put("count", "20");
		sampleEvents.add(event1);
		sampleEvents.add(event2);

		// Mock the behavior of installBaseMapper
		when(mapper.getChangesAndSubmissionTimelineRangeEventCount(filterParams)).thenReturn(sampleEvents);

		// Call the method to be tested
		Map<Long, Integer> result = service.getChangesAndSubmissionTimelineRangeEventCount(filterParams);

		// Verify the result
		assertEquals(2, result.size());
	}

	@Test
	public void testGetEsrsChangeEventWithMultipleGatewayIds() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "gateway");
		filterParams.put("gatewayDeviceIds", "123|456");
		List<Column> cols = new ArrayList<>();

		// Define one or more sample Column objects and add them to the list
		Column col1 = new Column();
		col1.setTitle("Name");
		col1.setField("userName");

		// Add more columns if needed
		cols.add(col1);

		// Mock the behavior of the 'getEsrsChangeEventForExport' method
		doNothing().when(mapper).getEsrsChangeEventForExport(any(StreamResultHandler.class), eq(filterParams));

		// Create a mock for the OutputStream
		OutputStream out = mock(OutputStream.class);

		service.getEsrsChangeEvent(out, filterParams, cols);

		// Verify that 'getEsrsChangeEventForExport' is called with the correct
		// arguments
		verify(mapper).getEsrsChangeEventForExport(any(StreamResultHandler.class), eq(filterParams));
	}

	@Test
	public void testGetServiceEventsTimeRangeAliasChangeCount() {
		// Arrange
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "123");

		// Create a list of sample data to be returned by the mapper
		List<Map<String, Object>> sampleData = new ArrayList<>();
		Map<String, Object> data1 = new HashMap<>();
		data1.put("date", 123.456);
		data1.put("count", 5);
		sampleData.add(data1);

		// Mock the behavior of the installBaseMapper
		when(mapper.getServiceEventsTimeRangeAliasChangeCount(filterParams)).thenReturn(sampleData);

		// Act
		Map<Long, Integer> result = service.getServiceEventsTimeRangeAliasChangeCount(filterParams);

		// Assert
		assertEquals(1, result.size());
		assertTrue(result.containsKey(123L));
		assertEquals(Integer.valueOf(5), result.get(123L));
	}

	@Test
	public void testWithNewProductFamily() {
		// Arrange
		String productFamily = "NewProductFamily";
		ConnectHomeDurationBean connectHomeDuration = null; // Simulating the absence of data
		Long defaultConnectHomeStatusDuration = 726L; // Set your default value

		when(mapper.getConnectHomeDuration(productFamily)).thenReturn(connectHomeDuration);

		// Act
		Long statusDaysLimit = service.getConnectHomeStatusDuration(productFamily);

		// Assert
		assertEquals(defaultConnectHomeStatusDuration, statusDaysLimit);
		verify(mapper).insertConnectHomeDuration(any(ConnectHomeDurationBean.class));
		// You can add more specific assertions related to sending emails and updating
		// duration if needed.
	}

	@Test
	public void testGetProductsWithStandardFilterParams() {
		// Prepare test data
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Map<String, Object> filterParams = new HashMap<>();
		// Add standard filter parameters
		filterParams.put("siteId", "123");
		filterParams.put("productType", "ABC");

		// Call the method with standard filterParams
		service.getProducts(outputStream, filterParams, new ArrayList<Column>());

		// Add assertions to verify the behavior
		// For example, you can assert that the method interacts with the mapper as
		// expected.
	}

	@Test
	public void testGetProductDetail() {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		ConnectHomeDurationBean connectHomeDuration = null;
		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).insertConnectHomeDuration(connectHomeDuration);
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "1234");
		ProductBean actual = service.getProductDetail(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "1234");
		assertNotNull(actual);

	}

	@Test
	public void testGetProductDetailWithConnectHomeDurationRecord() {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		ConnectHomeDurationBean connectHomeDuration = new ConnectHomeDurationBean("productFamily", 726L, new Date(),
				true);
		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).updateLastEmailSentDuration("productFamily");
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "1234");
		ProductBean actual = service.getProductDetail(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "1234");
		assertNotNull(actual);

	}

	@Test
	public void testGetProductDetailWithConnectHomeDurationRecordAndSendNotification() {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		ConnectHomeDurationBean connectHomeDuration = new ConnectHomeDurationBean("productFamily", 726L,
				new Date(System.currentTimeMillis() - 86400000L), true);
		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).updateLastEmailSentDuration("productFamily");
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "1234");
		ProductBean actual = service.getProductDetail(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "1234");
		assertNotNull(actual);

	}

	@Test
	public void testGetProductDetailWithConnectHomeDurationRecordAndSendNotificationNotNull() {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		ConnectHomeDurationBean connectHomeDuration = new ConnectHomeDurationBean("productFamily", 726L,
				new Date(System.currentTimeMillis() - 86400000L), true);
		doNothing().when(mapper).insertConnectHomeDuration(connectHomeDuration);
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).updateLastEmailSentDuration("productFamily");
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "1234");
		ProductBean actual = service.getProductDetail(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "1234");
		assertNotNull(actual);

	}

	@Test
	public void testGetMilestoneStats() {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setEops(1232496000000L);
		pb.setShipDate(123456009879L);
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("serialNumberIsIn", "1234");
		MilestoneStatsBean actualMSB = service.getMilestoneStats(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "1234");
		assertNotNull(actualMSB);
		assertEquals(1, actualMSB.getEopsDateCount());
		assertEquals(1, actualMSB.getShipDateCount());
		assertEquals(0, actualMSB.getContractEndDateCount());
		assertEquals(0, actualMSB.getInstallDateCount());
		assertEquals(0, actualMSB.getPurchaseDateCount());
	}

	@Test
	public void testInsertAliasEditRecord() {
		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("Product_Alias__C", "Test Alias");
		requestBody.put("assetId", "123456");
		requestBody.put("instanceNumber", "789123");
		requestBody.put("siteNumber", "12345");
		requestBody.put("cpsd", true);

		when(mapper.getProductChangeEvent(789123L)).thenReturn(null);

		service.insertAliasChangeEvent(requestBody, "12345", "me", "newAliasName", "E");

		verify(mapper, times(1)).getProductChangeEvent(789123L);
		verify(mapper, times(1)).insertProductChangeEvent(anyLong(), anyString());
	}

	@Test
	public void testUpdateAliasEditRecord() {
		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("Product_Alias__C", "Test Alias");
		requestBody.put("assetId", "123456");
		requestBody.put("instanceNumber", "789123");
		requestBody.put("siteNumber", "12345");
		requestBody.put("cpsd", true);

		ProductSiteChangeBean productChangeBean = new ProductSiteChangeBean();
		productChangeBean.setId(1);
		productChangeBean.setData("{}");

		when(mapper.getProductChangeEvent(789123L)).thenReturn(productChangeBean);

		service.insertAliasChangeEvent(requestBody, "12345", "me", "newAliasName", "E");

		verify(mapper, times(1)).getProductChangeEvent(789123L);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), anyString());
	}

	@Test
	public void testInsertContractRenewalInsertNewRecord() throws Exception {

		Map<String, Object> contractDetails = getContractDetails();
		ProductBean product = new ProductBean();
		product.setSerialNumber("1000");
		product.setInstanceNumber("1000");
		product.setContractEndDate(1490918400L);
		product.setProductFamily("productFamily");
		List<ProductBean> productsList = new ArrayList<>();
		productsList.add(product);
		ConnectHomeDurationBean connectHomeDuration = null;

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(9147483647L); // greater than int max value of 2,147,483,647
		ibProduct.setData("{\"serialNumber\": 1000}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getInstallBaseProduct(1, product.getInstanceNumber())).thenReturn(ibProduct);
		when(mapper.getProductChangeEvent(1000L)).thenReturn(null);
		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).insertConnectHomeDuration(connectHomeDuration);
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);

		service.insertContractRenewalRecord(contractDetails, "12345", "Firstname Lastname", "E");

		verify(mapper, times(1)).insertProductChangeEvent(anyLong(), anyString());
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testInsertContractRenewalUpdateExistingRecord() throws Exception {

		Map<String, Object> contractDetails = getContractDetails();
		ProductBean product = new ProductBean();
		product.setSerialNumber("1000");
		product.setInstanceNumber("1000");
		product.setContractEndDate(1490918400L);
		product.setProductFamily("productFamily");
		List<ProductBean> productsList = new ArrayList<>();
		productsList.add(product);
		ConnectHomeDurationBean connectHomeDuration = null;

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{\"serialNumber\": 1000}");

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"contractRenewal\":[{\"uid\":\"12345\",\"contractSubmissionDate\":\"1490818400\",\"contractEndDate\":1490918400}]}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getInstallBaseProduct(1, product.getInstanceNumber())).thenReturn(ibProduct);
		when(mapper.getProductChangeEvent(1000L)).thenReturn(siteChangeBean);

		Map<String, Object> mailParams = new HashMap<>();
		doNothing().when(mailService).sendConnectHomeDurationMail(mailParams);
		doNothing().when(mapper).insertConnectHomeDuration(connectHomeDuration);
		when(mapper.getConnectHomeDuration("productFamily")).thenReturn(connectHomeDuration);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);

		service.insertContractRenewalRecord(contractDetails, "12345", "Firstname Lastname", "E");

		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), anyString());
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test(expected = ResourceNotFoundException.class)
	public void testInsertContractRenewalRecordNotFoundException() throws Exception {
		Map<String, Object> contractDetails = getContractDetails();
		when(mapper.getProductDetail(anyMap())).thenReturn(new ArrayList<ProductBean>());
		service.insertContractRenewalRecord(contractDetails, "12345", "Firstname Lastname", "E");
	}

	private Map<String, Object> getContractDetails() {
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("model", "ABC");
		contractDetails.put("serialNumber", "1000");
		contractDetails.put("dunsNumber", "1001");
		contractDetails.put("siteId", "1002");
		contractDetails.put("companyName", "PQR");
		contractDetails.put("contactName", "XYZ");
		contractDetails.put("contactPhone", "0123456789");
		contractDetails.put("contactEmail", "xyz@pqr.com");
		contractDetails.put("comments", "Test Comment");
		contractDetails.put("contractRenewalAction", "renewContract");
		contractDetails.put("siteAddress", "siteAddress");
		contractDetails.put("country", "country");
		contractDetails.put("theater", "theater");
		return contractDetails;
	}

	@Test
	public void testGetProductsTotal() throws Exception {
		when(mapper.getProductsTotal(anyMap()))
		.thenReturn(250);
		
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		int actual = service.getProductsTotal(filterParams).get();
		assertEquals(250, actual);
		verify(mapper, times(1)).getProductsTotal(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
	}

	@Test
	public void testGetProducts() throws Exception {
		when(mapper.getProductDetail(anyMap()))
				.thenReturn(new ArrayList<ProductBean>());

		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteIds", getSiteList());
		List<ProductBean> actual = service.getProducts(filterParams).get();

		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());

		Map<String, Object> filters = filtersCaptor.getValue();
		@SuppressWarnings("unchecked")
		List<String> capturedSites = (List<String>) filters.get("siteIds");
		assertEquals(capturedSites, getSiteList());
		assertNotNull(actual);
	}

	@Test
	public void testInsertProductChangeEventNewData() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "Suite 3103");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "Colorado");
		siteDetails.put("originalProvince", "");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "5th Floor");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "Greater London");
		siteDetails.put("updatedProvince", "");
		siteDetails.put("updatedCountry", "United Kingom");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(null);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), anyString());
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).insertProductChangeEvent(anyLong(), anyString());
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testInsertProductChangeEventExistingData() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "Suite 3103");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "Colorado");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "5th Floor");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "Greater London");
		siteDetails.put("updatedCountry", "United Kingom");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(siteChangeBean);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), anyString());
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), anyString());
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testInsertContractRenewalRecord_OptimizeForStorage() throws IOException {
		// Arrange
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("serialNumber", "789");
		contractDetails.put("siteId", "101");
		contractDetails.put("contractRequestType", "optimizeForStorage");
		contractDetails.put("contractRenewalAction", "Renew");

		String uid = "user456";
		String userName = "Jane Doe";
		String userIdentityType = "manager";

		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("currentPartitionId", "yourPartitionId"); // Replace with actual partition ID
		filterParams.put("serialNumberIsIn", contractDetails.get("serialNumber"));

		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setEops(1577750400000L);
		pb.setShipDate(1530316800000L);
		pb.setInstanceNumber("12345");
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		ProductSiteChangeBean productChangeEvent = new ProductSiteChangeBean();
		productChangeEvent.setId(2);
		productChangeEvent.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");
		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{\"serialNumber\": 1000}");

		pb.setContractEndDate(1490918400L);
		pb.setProductFamily("productFamily");

		ConnectHomeDurationBean connectHomeDuration = null;
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		when(mapper.getProductChangeEvent(anyLong())).thenReturn(productChangeEvent);
		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getInstallBaseProduct(1, pb.getInstanceNumber())).thenReturn(ibProduct);

		// Act
		Map<String, Object> result = service.insertContractRenewalRecord(contractDetails, uid, userName,
				userIdentityType);

		// Assert
		assertNotNull(result);
		assertEquals(uid, result.get("uid"));
		assertEquals(userName, result.get("userName"));
		assertEquals(userIdentityType, result.get("userIdentityType"));
		assertNotNull(result.get("relationshipType"));
		assertEquals(contractDetails.get("contractRequestType"), result.get("contractRequestType"));
		assertNotNull(result.get("contractEndDate"));
		assertEquals(contractDetails.get("contractRenewalAction"), result.get("contractRenewalAction"));
		assertNotNull(result.get("contractSubmissionDate"));

		// Add more assertions based on your requirements
	}

	@Test
	public void testInsertContractRenewalRecord_RefreshEquipment() throws IOException {
		// Arrange
		Map<String, Object> contractDetails = new HashMap<>();
		contractDetails.put("serialNumber", "789");
		contractDetails.put("siteId", "101");
		contractDetails.put("contractRequestType", "refreshEquipment");
		contractDetails.put("contractRenewalAction", "Renew");

		String uid = "user456";
		String userName = "Jane Doe";
		String userIdentityType = "manager";

		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("currentPartitionId", "yourPartitionId"); // Replace with actual partition ID
		filterParams.put("serialNumberIsIn", contractDetails.get("serialNumber"));

		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setEops(1577750400000L);
		pb.setShipDate(1530316800000L);
		pb.setInstanceNumber("12345");
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		ProductSiteChangeBean productChangeEvent = new ProductSiteChangeBean();
		productChangeEvent.setId(2);
		productChangeEvent.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");
		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{\"serialNumber\": 1000}");

		pb.setContractEndDate(1490918400L);
		pb.setProductFamily("productFamily");

		ConnectHomeDurationBean connectHomeDuration = null;
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		when(mapper.getProductChangeEvent(anyLong())).thenReturn(productChangeEvent);
		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getInstallBaseProduct(1, pb.getInstanceNumber())).thenReturn(ibProduct);

		// Act
		Map<String, Object> result = service.insertContractRenewalRecord(contractDetails, uid, userName,
				userIdentityType);

		// Assert
		assertNotNull(result);
		assertEquals(uid, result.get("uid"));
		assertEquals(userName, result.get("userName"));
		assertEquals(userIdentityType, result.get("userIdentityType"));
		assertNotNull(result.get("relationshipType"));
		assertEquals(contractDetails.get("contractRequestType"), result.get("contractRequestType"));
		assertNotNull(result.get("contractEndDate"));
		assertEquals(contractDetails.get("contractRenewalAction"), result.get("contractRenewalAction"));
		assertNotNull(result.get("contractSubmissionDate"));

		// Add more assertions based on your requirements
	}

	private ProductBean createMockProduct() {
		// Create a mock ProductBean for testing
		ProductBean product = new ProductBean();
		product.setConnectFlag("CONNECTED");
		product.setInstanceNumber("12345");

		return product;
	}

	@Test
	public void testInsertSiteEventChangeNewRecord() throws Exception {

		Map<String, Object> reqMap = new HashMap<>();

		reqMap.put("originalSiteNumber", "1004085654");
		ProductBean product = new ProductBean();
		product.setSerialNumber("1000");
		product.setContractEndDate(1490918400L);
		List<ProductBean> productsList = new ArrayList<>();
		productsList.add(product);

		ProductSiteChangeBean siteBean = new ProductSiteChangeBean();
		siteBean.setId(2);
		siteBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{\"serialNumber\": 1000}");

		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		when(mapper.getSiteChangeEvent(reqMap.get("originalSiteNumber").toString())).thenReturn(null);

		service.insertSiteChangeEvent(reqMap, "12345", "TestUser", "E");

		verify(mapper, times(1)).getSiteChangeEvent(reqMap.get("originalSiteNumber").toString());
		verify(mapper, times(1)).insertSiteChangeEvent(eq(reqMap.get("originalSiteNumber").toString()), anyString());

	}

	@Test
	public void testUpdateSiteEventChangeRecord() throws Exception {

		Map<String, Object> reqMap = new HashMap<>();

		reqMap.put("originalSiteNumber", "1004085654");
		ProductBean product = new ProductBean();
		product.setSerialNumber("1000");
		product.setContractEndDate(1490918400L);
		List<ProductBean> productsList = new ArrayList<>();
		productsList.add(product);

		ProductSiteChangeBean siteBean = new ProductSiteChangeBean();
		siteBean.setId(2);
		siteBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{\"serialNumber\": 1000}");

		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		when(mapper.getSiteChangeEvent(reqMap.get("originalSiteNumber").toString())).thenReturn(siteBean);

		service.insertSiteChangeEvent(reqMap, "12345", "TestUser", "E");

		verify(mapper, times(1)).getSiteChangeEvent(reqMap.get("originalSiteNumber").toString());

		verify(mapper, times(1)).updateSiteChangeEvent(eq(reqMap.get("originalSiteNumber").toString()), anyString());

	}

	@Test
	public void testGetEsrsAliasChangeEvent() throws Exception {
		Map<String, Object> reqMap = new HashMap<>();
		reqMap.put("deviceId", "123FGGQ666");
		reqMap.put("tlvTimeRangeAfter", 1234567890L);
		reqMap.put("tlvTimeRangeBefore", 1234567890L);
		EsrsChangeEventBean esrsChangeEventBean = new EsrsChangeEventBean();
		esrsChangeEventBean.setId("123FGGQ666");
		esrsChangeEventBean.setData(
				"{\"aliasChange\":[{\"uid\":\"12345\",\"alias\":\"Test Alias Name\",\"updatedBy\":\"User Name\",\"updatedOn\":1498217713502,\"relationshipType\":\"E\",\"userIdentityType\":\"E\",\"action\":\"ADD\",\"clusterConnection\":false}]}");

		when(mapper.getEsrsChangeEvent(reqMap)).thenReturn(Arrays.asList(esrsChangeEventBean));

		List<EsrsChangeEventBean> actual = mapper.getEsrsChangeEvent(reqMap);

		verify(mapper, times(1)).getEsrsChangeEvent(reqMap);
		assertEquals(actual.get(0).getData().contains("aliasChange"), true);
		assertEquals(actual.get(0).getData().contains("uid\":\"12345"), true);
		assertEquals(actual.get(0).getData().contains("alias\":\"Test Alias Name"), true);
		assertEquals(actual.get(0).getData().contains("action\":\"ADD"), true);
	}

	@Test
	public void testInsertEsrsAliasChangeEvent() throws Exception {
		String data = "{\"aliasChange\":[{\"uid\":\"12345\",\"alias\":\"Test Alias Name\",\"updatedBy\":\"User Name\",\"updatedOn\":1498217713502,\"relationshipType\":\"E\",\"userIdentityType\":\"E\",\"action\":\"ADD\",\"clusterConnection\":false}]}";

		doNothing().when(mapper).insertEsrsChangeEvent("123FGGQ666", data);

		mapper.insertEsrsChangeEvent("123FGGQ666", data);

		verify(mapper, times(1)).insertEsrsChangeEvent("123FGGQ666", data);
	}

	@Test
	public void testUpdateEsrsAliasChangeEvent() throws Exception {
		String data = "{\"aliasChange\":[{\"uid\":\"12345\",\"alias\":\"Test Alias Name Update\",\"updatedBy\":\"User Name\",\"updatedOn\":1498217713502,\"relationshipType\":\"E\",\"userIdentityType\":\"E\",\"action\":\"UPDATE\",\"clusterConnection\":false}]}";

		doNothing().when(mapper).updateEsrsChangeEvent("123FGGQ666", data);

		mapper.updateEsrsChangeEvent("123FGGQ666", data);

		verify(mapper, times(1)).updateEsrsChangeEvent("123FGGQ666", data);
	}

	@Test
	public void testGetProductChangeEvent() throws Exception {
		ProductSiteChangeBean productChangeEvent = new ProductSiteChangeBean();
		productChangeEvent.setId(2);
		productChangeEvent.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		when(mapper.getProductChangeEvent(12345L)).thenReturn(productChangeEvent);

		Map<String, Object> actual = service.getProductChangeEvent(12345L);

		verify(mapper, times(1)).getProductChangeEvent(12345L);
		assertEquals(actual.containsKey("locationChange"), true);

	}

	@Test
	public void testGetProductChangeEventNull() throws Exception {
		when(mapper.getProductChangeEvent(12345L)).thenReturn(null);
		Map<String, Object> actual = service.getProductChangeEvent(12345L);
		verify(mapper, times(1)).getProductChangeEvent(12345L);
		assertNull(actual);
	}

	@Test
	public void testLocationChangeEventData() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "Suite 3103");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "Colorado");
		siteDetails.put("originalProvince", "");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("originalZipcode", "123456ZC");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "5th Floor");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "Greater London");
		siteDetails.put("updatedProvince", "");
		siteDetails.put("updatedCountry", "United Kingom");
		siteDetails.put("updatedZipcode", "123456ZC");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(siteChangeBean);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, Greater London 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, Colorado 123456ZC, United States\".*"));
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, Greater London 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, Colorado 123456ZC, United States\".*"));
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testLocationChangeEventDataWithProvince() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "Suite 3103");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "");
		siteDetails.put("originalProvince", "province");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("originalZipcode", "123456ZC");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "5th Floor");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "");
		siteDetails.put("updatedProvince", "province");
		siteDetails.put("updatedCountry", "United Kingom");
		siteDetails.put("updatedZipcode", "123456ZC");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(siteChangeBean);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, province 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, province 123456ZC, United States\".*"));
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, province 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, province 123456ZC, United States\".*"));
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testLocationChangeEventDataStateAndProvince() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "Suite 3103");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "Colorado");
		siteDetails.put("originalProvince", "province");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("originalZipcode", "123456ZC");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "5th Floor");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "Greater London");
		siteDetails.put("updatedProvince", "province");
		siteDetails.put("updatedCountry", "United Kingom");
		siteDetails.put("updatedZipcode", "123456ZC");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(siteChangeBean);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, Greater London 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, Colorado 123456ZC, United States\".*"));
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, 5th Floor, London, Greater London 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Suite 3103, Denver, Colorado 123456ZC, United States\".*"));
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testLocationChangeEventDataNoStateAndProvince() throws Exception {
		Map<String, Object> siteDetails = new HashMap<String, Object>();
		siteDetails.put("serialNumber", "12345");
		siteDetails.put("instanceNumber", "12345");
		siteDetails.put("originalSiteNumber", "1234567899");
		siteDetails.put("originalSiteName", "XYZ Company");
		siteDetails.put("originalAddress1", "620 16th Street");
		siteDetails.put("originalAddress2", "");
		siteDetails.put("originalCity", "Denver");
		siteDetails.put("originalState", "");
		siteDetails.put("originalProvince", "");
		siteDetails.put("originalCountry", "United States");
		siteDetails.put("originalZipcode", "123456ZC");
		siteDetails.put("updatedSiteNumber", "82639881237");
		siteDetails.put("updatedSiteName", "ABC Company");
		siteDetails.put("updatedAddress1", "126-130 Regent Street");
		siteDetails.put("updatedAddress2", "");
		siteDetails.put("updatedCity", "London");
		siteDetails.put("updatedState", "");
		siteDetails.put("updatedProvince", "");
		siteDetails.put("updatedCountry", "United Kingom");
		siteDetails.put("updatedZipcode", "123456ZC");
		String uid = "12345", userName = "flname", userIdentityType = "E";

		Map<String, Object> changeDetailsMap = new HashMap<>();
		changeDetailsMap.put("uid", uid);
		changeDetailsMap.put("requestDate", new Date().getTime());
		changeDetailsMap.put("userName", userName);
		changeDetailsMap.put("userIdentityType", userIdentityType);

		ProductSiteChangeBean siteChangeBean = new ProductSiteChangeBean();
		siteChangeBean.setId(1);
		siteChangeBean.setData(
				"{\"locationChange\":[{\"uid\":\"12345\",\"userName\":\"flname\",\"requestDate\":1498217713502,\"userIdentityType\":\"E\"}]}");

		InstallBaseProductBean ibProduct = new InstallBaseProductBean();
		ibProduct.setId(1L);
		ibProduct.setData("{}");

		when(mapper.getCurrentPartitionId()).thenReturn(1);
		when(mapper.getProductChangeEvent(12345L)).thenReturn(siteChangeBean);
		doNothing().when(mapper).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, London, 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Denver, 123456ZC, United States\".*"));
		when(mapper.getInstallBaseProduct(1, "12345")).thenReturn(ibProduct);

		service.insertProductChangeEvent(siteDetails, uid, userName, userIdentityType);
		verify(mapper, times(1)).updateProductChangeEvent(anyLong(), matches(
				".*\"updatedAddress\":\"126-130 Regent Street, London, 123456ZC, United Kingom\",\"uid\":\"12345\",\"originalSiteDisplayName\":\"1234567899, XYZ Company\",\"relationshipType\":\"E\",\"originalAddress\":\"620 16th Street, Denver, 123456ZC, United States\".*"));
		verify(mapper, times(1)).updateInstallBaseProduct(eq(ibProduct.getId()), eq(1), anyString());
	}

	@Test
	public void testGetDeviceAlias() throws Exception {
		EsrsBean esrsAliasBean = new EsrsBean();
		esrsAliasBean.setAlias("Test Device Alias");
		esrsAliasBean.setId("ABCDE123");

		List<EsrsBean> esrsBeanList = new ArrayList<>();
		esrsBeanList.add(esrsAliasBean);

		Map<String, Object> deviceAliasFilterParams = new HashMap<>();
		deviceAliasFilterParams.put("deviceId", "ABCDE123");
		when(mapper.getEsrsData("ABCDE123")).thenReturn(esrsBeanList);
		Map<String, EsrsBean> actual = service.getEsrsData(deviceAliasFilterParams);
		verify(mapper, times(1)).getEsrsData("ABCDE123");
		assertEquals(actual.get("ABCDE123").getAlias().contains(esrsAliasBean.getAlias()), true);
	}

	@Test
	public void testGetMilestonesTimelineRangeEventCount() throws Exception {
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setEops(1577750400000L);
		pb.setShipDate(1530316800000L);
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		Map<String, Object> filterParams = new HashMap<String, Object>();
		filterParams.put("siteNumberIsIn", "14700576");
		filterParams.put("tlvTimeRangeBefore", "1577750400000");
		filterParams.put("tlvTimeRangeAfter", "123292800000");
		filterParams.put("serialNumberIsIn", "APM00125145580");
		Map<Long, Integer> actualMSB = service.getMilestonesTimelineRangeEventCount(filterParams);
		verify(mapper, times(1)).getProductDetail(filtersCaptor.capture());
		Map<String, Object> filters = filtersCaptor.getValue();
		assertEquals((String) filters.get("serialNumberIsIn"), "APM00125145580");
		assertNotNull(actualMSB);
	}

	@Test
	public void testGetEsrsAliasCount() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "gateway");

		when(mapper.getEsrsAliasChangeCount(filterParams)).thenReturn(10L);

		long actual = service.getEsrsAliasChangeCount(filterParams);
		assertEquals(10, actual);
	}

	@Test
	public void testGetTridentAggregateResponse() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "ELM6CXJH7111G1");
		filterParams.put("isClusterConnection", "true");

		EsrsDeviceGatewaysBean esrsDGBean = new EsrsDeviceGatewaysBean();
		esrsDGBean.setClusterGroupName("SERVICE PLANNING - SVT HA Gateways S12Y");
		esrsDGBean.setGatewayModelName("ESRS-VE");
		esrsDGBean.setClusterId("10953");
		esrsDGBean.setGatewayId("ELM6CXJH7111G1");
		List<String> gatwayStatuses = new ArrayList<>();
		gatwayStatuses.add("Online");
		esrsDGBean.setGatewayDeviceStatuses(gatwayStatuses);
		List<String> esrsVersions = new ArrayList<>();
		esrsVersions.add("3.32.00.08");
		esrsDGBean.setEsrsVersions(esrsVersions);

		when(mapper.getTridentAggregateResponse(filterParams)).thenReturn(esrsDGBean);

		EsrsBean esrsBean = new EsrsBean();
		esrsBean.setAlias("Alias Name");
		List<EsrsBean> esrsBeanList = new ArrayList<>();
		esrsBeanList.add(esrsBean);

		when(mapper.getEsrsData(filterParams.get("deviceId").toString())).thenReturn(esrsBeanList);

		GatewayBean gatewayBean = new GatewayBean();
		List<GatewayBean> gatewayBeans = new ArrayList<>();
		gatewayBeans.add(gatewayBean);

		when(mapper.getTridentGatewayDetails(filterParams)).thenReturn(gatewayBeans);

		EsrsDeviceGatewaysBean actual = service.getTridentAggregateResponse(filterParams);

		assertEquals(esrsDGBean.getClusterId(), actual.getClusterId());
		assertEquals(esrsDGBean.getGatewayId(), actual.getGatewayId());
	}

	@Test
	public void testGetTridentConnectHomeEvents() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", "ELM6CXJH7111G1");

		Map<String, Object> connectHomeEvent = new HashMap<>();
		connectHomeEvent.put("connectDate", 1568745000000L);
		connectHomeEvent.put("serialNumber", "ELMESR0816CF8G");
		connectHomeEvent.put("connectTime", 18355000);
		connectHomeEvent.put("connectDateTime", 1568783155000L);
		connectHomeEvent.put("startTime", 1568783155000L);
		connectHomeEvent.put("productName", "POWERSTORE");

		List<Map<String, Object>> connectHomeEventsList = new ArrayList<>();
		connectHomeEventsList.add(connectHomeEvent);

		when(mapper.getTridentConnectHomeEvents(filterParams)).thenReturn(connectHomeEventsList);

		List<Map<String, Object>> actual = service.getTridentConnectHomeEvents(filterParams);

		assertEquals(connectHomeEventsList.size(), actual.size());
	}

	@Test
	public void testGetTridentConnectedDevices() throws Exception {
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("size", "10");
		filterParams.put("deviceId", "ELM6CXJH7111G1");

		Map<String, Object> tridentDevice = new HashMap<>();
		tridentDevice.put("serialNumber", "FNM00175100036");
		tridentDevice.put("gatewayId", "ELM6CXJH7111G1");
		tridentDevice.put("productName", "POWERSTORE");
		tridentDevice.put("deviceStatus", "Online");
		tridentDevice.put("esrsVersion", "3.32.00.08");

		List<Map<String, Object>> tridentDeviceList = new ArrayList<>();
		tridentDeviceList.add(tridentDevice);

		when(mapper.getTridentConnectedDevices(filterParams)).thenReturn(tridentDeviceList);

		List<Map<String, Object>> actual = service.getTridentConnectedDevices(filterParams);

		assertEquals(tridentDeviceList.size(), actual.size());
	}

	@Test
	public void testGetWarranties() throws Exception {
		Entitlement ent1 = new Entitlement();
		ent1.setContractEndDate(new Date(2021, 2, 2));
		ent1.setContractStartDate(new Date(2019, 2, 2));
		ent1.setSalesOrderNumber("12344");
		ent1.setContractId("1233");
		ent1.setContractTerminationDate(new Date(2022, 2, 2));
		ent1.setServiceDescription("Parts Retention");
		ent1.setType("RET");
		ent1.setServiceLevelCode("MH");
		ent1.setStatus("Active");
		List<Entitlement> result = new ArrayList<Entitlement>();
		result.add(ent1);

		when(mapper.getWarranties("AB1234")).thenReturn(result);

		WarrantyResponse response = service.getWarranties("AB1234");

		assertEquals(response.getEntitlements().size(), 1);
		assertEquals(response.getProductId(), "AB1234");
	}

	@Test
	public void testGetWarrantiesWithServiceDescription() throws Exception {
		// Arrange
		Entitlement ent1 = new Entitlement();
		ent1.setContractEndDate(new Date(2021, 2, 2));
		ent1.setContractStartDate(new Date(2019, 2, 2));
		ent1.setSalesOrderNumber("12344");
		ent1.setContractId("1233");
		ent1.setContractTerminationDate(new Date(2022, 2, 2));
		ent1.setServiceDescription("Parts Retention");
		ent1.setType("RET");
		ent1.setServiceLevelCode("MH");
		ent1.setStatus("Active");
		List<Entitlement> result = new ArrayList<Entitlement>();
		result.add(ent1);

		when(mapper.getWarranties("AB1234")).thenReturn(result);

		// Act
		WarrantyResponse response = service.getWarranties("AB1234");

		// Assert
		assertEquals(response.getEntitlements().size(), 1);
		assertEquals(response.getProductId(), "AB1234");
		// Add assertions to ensure that serviceDescription was set as expected in the
		// result
		for (Entitlement ent : response.getEntitlements()) {
			assertEquals("Parts Retention", ent.getServiceDescription());
		}

	}

	@Test
	public void testGetWarrantiesWithServiceDescription1() throws Exception {
		// Mocked data for the mapper
		Entitlement ent1 = new Entitlement();
		ent1.setType("RET");
		ent1.setServiceLevelCode("MH");

		// Add more mocked data for different service levels if needed
		Entitlement ent2 = new Entitlement();
		ent2.setType("B");
		ent2.setServiceLevelCode("XYZ");

		Entitlement ent3 = new Entitlement();
		ent3.setType("HSN");
		ent3.setServiceLevelCode("XYZ");

		Entitlement ent4 = new Entitlement();
		ent4.setType("HSI");
		ent4.setServiceLevelCode("XYZ");

		Entitlement ent5 = new Entitlement();
		ent5.setType("HSD");
		ent5.setServiceLevelCode("XYZ");

		Entitlement ent6 = new Entitlement();
		ent6.setType("HSS");
		ent6.setServiceLevelCode("XYZ");

		Entitlement ent7 = new Entitlement();
		ent7.setType("HSH");
		ent7.setServiceLevelCode("XYZ");

		Entitlement ent8 = new Entitlement();
		ent8.setType("HSE");
		ent8.setServiceLevelCode("XYZ");

		Entitlement ent9 = new Entitlement();
		ent9.setType("HSC");
		ent9.setServiceLevelCode("XYZ");

		Entitlement ent10 = new Entitlement();
		ent10.setType("HSA");
		ent10.setServiceLevelCode("XYZ");

		Entitlement ent11 = new Entitlement();
		ent11.setType("HSO");
		ent11.setServiceLevelCode("XYZ");

		Entitlement ent12 = new Entitlement();
		ent12.setType("HSP");
		ent12.setServiceLevelCode("XYZ");

		Entitlement ent13 = new Entitlement();
		ent13.setType("PSM");
		ent13.setServiceLevelCode("XYZ");

		Entitlement ent14 = new Entitlement();
		ent14.setType("PSN");
		ent14.setServiceLevelCode("XYZ");

		Entitlement ent15 = new Entitlement();
		ent15.setType("L");
		ent15.setServiceLevelCode("XYZ");

		Entitlement ent16 = new Entitlement();
		ent16.setType("NA");
		ent16.setServiceLevelCode("XYZ");

		Entitlement ent17 = new Entitlement();
		ent17.setType("999");
		ent17.setServiceLevelCode("XYZ");

		Entitlement ent18 = new Entitlement();
		ent18.setType("RET");
		ent18.setServiceLevelCode("XYZ");

		Entitlement ent19 = new Entitlement();
		ent19.setType("P");
		ent19.setServiceLevelCode("XYZ");

		Entitlement ent20 = new Entitlement();
		ent20.setType("E");
		ent20.setServiceLevelCode("XYZ");

		Entitlement ent21 = new Entitlement();
		ent21.setType("BE");
		ent21.setServiceLevelCode("XYZ");

		Entitlement ent22 = new Entitlement();
		ent22.setType("PS1");
		ent22.setServiceLevelCode("XYZ");

		Entitlement ent23 = new Entitlement();
		ent23.setType("PPN");
		ent23.setServiceLevelCode("XYZ");

		Entitlement ent24 = new Entitlement();
		ent24.setType("BPN");
		ent24.setServiceLevelCode("XYZ");

		Entitlement ent25 = new Entitlement();
		ent25.setType("EPN");
		ent25.setServiceLevelCode("XYZ");

		Entitlement ent26 = new Entitlement();
		ent26.setType("SSC");
		ent26.setServiceLevelCode("XYZ");

		Entitlement ent27 = new Entitlement();
		ent27.setType("SSF");
		ent27.setServiceLevelCode("XYZ");

		Entitlement ent28 = new Entitlement();
		ent28.setType("SSB");
		ent28.setServiceLevelCode("XYZ");

		Entitlement ent29 = new Entitlement();
		ent29.setType("SSA");
		ent29.setServiceLevelCode("XYZ");
		
		Entitlement ent30 = new Entitlement();
		ent30.setType("SSD");
		ent30.setServiceLevelCode("XYZ");
		
		Entitlement ent31 = new Entitlement();
		ent31.setType("HSR");
		ent31.setServiceLevelCode("XYZ");
		
		Entitlement ent32 = new Entitlement();
		ent32.setType("HSB");
		ent32.setServiceLevelCode("XYZ");
		
		Entitlement ent33 = new Entitlement();
		ent33.setType("X");
		ent33.setServiceLevelCode("XYZ");
		
		Entitlement ent34 = new Entitlement();
		ent34.setType("HSJ");
		ent34.setServiceLevelCode("XYZ");
		
		Entitlement ent35 = new Entitlement();
		ent35.setType("HSG");
		ent35.setServiceLevelCode("XYZ");
		
		Entitlement ent36 = new Entitlement();
		ent36.setType("HSQ");
		ent36.setServiceLevelCode("XYZ");
		
		Entitlement ent37 = new Entitlement();
		ent37.setType("HSM");
		ent37.setServiceLevelCode("XYZ");
		
		Entitlement ent38 = new Entitlement();
		ent38.setType("HSV");
		ent38.setServiceLevelCode("XYZ");
		
		Entitlement ent39 = new Entitlement();
		ent39.setType("HSW");
		ent39.setServiceLevelCode("XYZ");
		
		Entitlement ent40 = new Entitlement();
		ent40.setType("HSL");
		ent40.setServiceLevelCode("XYZ");
		
		Entitlement ent41 = new Entitlement();
		ent41.setType("HSX");
		ent41.setServiceLevelCode("XYZ");
		
		Entitlement ent42 = new Entitlement();
		ent42.setType("HSY");
		ent42.setServiceLevelCode("XYZ");
		
		Entitlement ent43 = new Entitlement();
		ent43.setType("HSZ");
		ent43.setServiceLevelCode("XYZ");
		
		Entitlement ent44 = new Entitlement();
		ent44.setType("HTA");
		ent44.setServiceLevelCode("XYZ");
		
		Entitlement ent45 = new Entitlement();
		ent45.setType("HSK");
		ent45.setServiceLevelCode("XYZ");
		
		Entitlement ent46 = new Entitlement();
		ent46.setType("HTB");
		ent46.setServiceLevelCode("XYZ");
		
		Entitlement ent47 = new Entitlement();
		ent47.setType("O1M");
		ent47.setServiceLevelCode("XYZ");
		
		Entitlement ent48 = new Entitlement();
		ent48.setType("O1A");
		ent48.setServiceLevelCode("XYZ");
		
		Entitlement ent49 = new Entitlement();
		ent49.setType("O2R");
		ent49.setServiceLevelCode("XYZ");
		
		Entitlement ent50 = new Entitlement();
		ent50.setType("O2M");
		ent50.setServiceLevelCode("XYZ");
				
		Entitlement ent51 = new Entitlement();
		ent51.setType("O2P");
		ent51.setServiceLevelCode("XYZ");
		
		Entitlement ent52 = new Entitlement();
		ent52.setType("O2A");
		ent52.setServiceLevelCode("XYZ");
		
		Entitlement ent53 = new Entitlement();
		ent53.setType("O3R");
		ent53.setServiceLevelCode("XYZ");
		
		Entitlement ent54 = new Entitlement();
		ent54.setType("O3M");
		ent54.setServiceLevelCode("XYZ");
		
		Entitlement ent55 = new Entitlement();
		ent55.setType("O3P");
		ent55.setServiceLevelCode("XYZ");
		
		Entitlement ent56 = new Entitlement();
		ent56.setType("O3A");
		ent56.setServiceLevelCode("XYZ");
		
		Entitlement ent57 = new Entitlement();
		ent57.setType("HST");
		ent57.setServiceLevelCode("XYZ");
		
		Entitlement ent58 = new Entitlement();
		ent58.setType("HSU");
		ent58.setServiceLevelCode("XYZ");
		
		Entitlement ent59 = new Entitlement();
		ent59.setType("R1");
		ent59.setServiceLevelCode("XYZ");
		
		Entitlement ent60 = new Entitlement();
		ent60.setType("R2");
		ent60.setServiceLevelCode("XYZ");
		
		Entitlement ent61 = new Entitlement();
		ent61.setType("R3");
		ent61.setServiceLevelCode("XYZ");
		
		Entitlement ent62 = new Entitlement();
		ent62.setType("R3M");
		ent62.setServiceLevelCode("XYZ");
		
		Entitlement ent63 = new Entitlement();
		ent63.setType("SSE");
		ent63.setServiceLevelCode("XYZ");
		
		Entitlement ent64 = new Entitlement();
		ent64.setType("ENH");
		ent64.setServiceLevelCode("XYZ");
		
		Entitlement ent65 = new Entitlement();
		ent65.setType("KHD");
		ent65.setServiceLevelCode("XYZ");
		
		Entitlement ent66 = new Entitlement();
		ent66.setType("KYC");
		ent66.setServiceLevelCode("XYZ");
		
		Entitlement ent67 = new Entitlement();
		ent67.setType("P1N");
		ent67.setServiceLevelCode("XYZ");
		
		Entitlement ent68 = new Entitlement();
		ent68.setType("U0");
		ent68.setServiceLevelCode("XYZ");
		
		Entitlement ent69 = new Entitlement();
		ent69.setType("VD");
		ent69.setServiceLevelCode("XYZ");
		
		Entitlement ent70 = new Entitlement();
		ent70.setType("C8");
		ent70.setServiceLevelCode("XYZ");
		
		Entitlement ent71 = new Entitlement();
		ent71.setType("P8");
		ent71.setServiceLevelCode("XYZ");
		
		Entitlement ent72 = new Entitlement();
		ent72.setType("T2");
		ent72.setServiceLevelCode("XYZ");
		
		Entitlement ent73 = new Entitlement();
		ent73.setType("T4");
		ent73.setServiceLevelCode("XYZ");
		
				
		List<Entitlement> result = new ArrayList<>();
		result.add(ent1);
		result.add(ent2);
		result.add(ent3);
		result.add(ent4);
		result.add(ent5);
		result.add(ent6);
		result.add(ent7);
		result.add(ent8);
		result.add(ent9);
		result.add(ent10);
		result.add(ent11);
		result.add(ent12);
		result.add(ent13);
		result.add(ent14);
		result.add(ent15);
		result.add(ent16);
		result.add(ent17);
		result.add(ent18);
		result.add(ent19);
		result.add(ent20);
		result.add(ent21);
		result.add(ent22);
		result.add(ent23);
		result.add(ent24);
		result.add(ent25);
		result.add(ent26);
		result.add(ent27);
		result.add(ent28);
		result.add(ent29);
		result.add(ent30);
		result.add(ent31);
		result.add(ent32);
		result.add(ent33);
		result.add(ent34);
		result.add(ent35);
		result.add(ent36);
		result.add(ent37);
		result.add(ent38);
		result.add(ent39);
		result.add(ent40);
		result.add(ent41);
		result.add(ent42);
		result.add(ent43);
		result.add(ent44);
		result.add(ent45);
		result.add(ent46);
		result.add(ent47);
		result.add(ent48);
		result.add(ent49);
		result.add(ent50);
		result.add(ent51);
		result.add(ent52);
		result.add(ent53);
		result.add(ent54);
		result.add(ent55);
		result.add(ent56);
		result.add(ent57);
		result.add(ent58);
		result.add(ent59);
		result.add(ent60);
		result.add(ent61);
		result.add(ent62);
		result.add(ent63);
		result.add(ent64);
		result.add(ent65);
		result.add(ent66);
		result.add(ent67);
		result.add(ent68);
		result.add(ent69);
		result.add(ent70);
		result.add(ent71);
		result.add(ent72);
		result.add(ent73);

		// Mock behavior of the mapper
		when(mapper.getWarranties("AB1234")).thenReturn(result);

		// Act
		WarrantyResponse response = service.getWarranties("AB1234");

		// Assert
		assertEquals(73, response.getEntitlements().size()); // Assuming two different entitlements are returned

		// Validate service descriptions for different entitlements
		assertEquals("Parts Retention", response.getEntitlements().get(0).getServiceDescription());
		// Validate service description for the second entitlement with a different
		// service level
		// Add assertions for different service levels and expected descriptions
		assertEquals("Basic Support", response.getEntitlements().get(1).getServiceDescription());
		// Add more assertions as needed for different scenarios
		assertEquals("HW L1 L2 L3  MON B/F PART-DEL RTF NBD",
				response.getEntitlements().get(2).getServiceDescription());
		assertEquals("HW L2 L3 MON PART-DEL RTF", response.getEntitlements().get(3).getServiceDescription());
		assertEquals("HW L2 L3 PART-DEL RT", response.getEntitlements().get(4).getServiceDescription());
		assertEquals("HW L3", response.getEntitlements().get(5).getServiceDescription());
		assertEquals("HW L3 MON PART-DEL RTF", response.getEntitlements().get(6).getServiceDescription());
		assertEquals("HW L3 MON RTF", response.getEntitlements().get(7).getServiceDescription());
		assertEquals("HW L3 PART-DEL RTF", response.getEntitlements().get(8).getServiceDescription());
		assertEquals("HW L3 RTF", response.getEntitlements().get(9).getServiceDescription());
		assertEquals("HW L3 B/F PART-DEL RTF 4HR", response.getEntitlements().get(10).getServiceDescription());
		assertEquals("HW L3 MON B/F PART-DEL RTF 4HR", response.getEntitlements().get(11).getServiceDescription());
		assertEquals("Post Std Support 4HR/Mission Critical",
				response.getEntitlements().get(12).getServiceDescription());
		assertEquals("Post Std Support NBD", response.getEntitlements().get(13).getServiceDescription());
		assertEquals("Limited Warranty", response.getEntitlements().get(14).getServiceDescription());
		assertEquals("Not Applicable", response.getEntitlements().get(15).getServiceDescription());
		assertEquals("NPR", response.getEntitlements().get(16).getServiceDescription());
		assertEquals("Parts Retention", response.getEntitlements().get(17).getServiceDescription());
		assertEquals("ProSupport 4HR/Mission Critical", response.getEntitlements().get(18).getServiceDescription());
		assertEquals("ProSupport NBD", response.getEntitlements().get(19).getServiceDescription());
		assertEquals("ProSupport NBD", response.getEntitlements().get(20).getServiceDescription());
		assertEquals("ProSupport One", response.getEntitlements().get(21).getServiceDescription());
		assertEquals("ProSupport Plus NBD", response.getEntitlements().get(22).getServiceDescription());
		assertEquals("ProSupport Plus NBD", response.getEntitlements().get(23).getServiceDescription());
		assertEquals("ProSupport Plus NBD", response.getEntitlements().get(24).getServiceDescription());
		assertEquals("SW L1 L2  L3 SPPT", response.getEntitlements().get(25).getServiceDescription());
		assertEquals("SW L1 L2 L3 SPPT RR", response.getEntitlements().get(26).getServiceDescription());
		assertEquals("SW L2 L3 SPPT", response.getEntitlements().get(27).getServiceDescription());
		assertEquals("SW L3 SPPT", response.getEntitlements().get(28).getServiceDescription());
		assertEquals("SW L3 SPPT RR SLO", response.getEntitlements().get(29).getServiceDescription());
		assertEquals("HW L1 L2 L3 MON B/F PART-DEL RTF 4HR",
				response.getEntitlements().get(30).getServiceDescription());
		assertEquals("HW L2 L3 RTF", response.getEntitlements().get(31).getServiceDescription());
		assertEquals("Extended Support", response.getEntitlements().get(32).getServiceDescription());
		assertEquals("HW L1 L2 L3 MON PART-DEL RTF", response.getEntitlements().get(33).getServiceDescription());
		assertEquals("HW L1 L2 L3 MON RTF", response.getEntitlements().get(34).getServiceDescription());
		assertEquals("HW L2 L3 MON B/F PART-DEL RTF 4HR", response.getEntitlements().get(35).getServiceDescription());
		assertEquals("HW L2 L3 MON B/F PART-DEL RTF NBD", response.getEntitlements().get(36).getServiceDescription());
		assertEquals("HW L2 L3 MON PART-DEL RTF PSS", response.getEntitlements().get(37).getServiceDescription());
		assertEquals("HW L2 L3 MON RTF PSS", response.getEntitlements().get(38).getServiceDescription());
		assertEquals("HW L3 MON B/F PART-DEL RTF NBD", response.getEntitlements().get(39).getServiceDescription());
		assertEquals("HW L3 MON PART-DEL RTF PSS", response.getEntitlements().get(40).getServiceDescription());
		assertEquals("HW L3 MON RTF PSS", response.getEntitlements().get(41).getServiceDescription());
		assertEquals("HW L3 PART-DEL RTF PSS", response.getEntitlements().get(42).getServiceDescription());
		assertEquals("HW L3 RTF PSS", response.getEntitlements().get(43).getServiceDescription());
		assertEquals("HW L3, B/F PART-DEL RTF NBD", response.getEntitlements().get(44).getServiceDescription());
		assertEquals("HW L3-PSS", response.getEntitlements().get(45).getServiceDescription());
		assertEquals("Onsite L1, L2, L3, RTF, Monitoring", response.getEntitlements().get(46).getServiceDescription());
		assertEquals("Onsite L1, L2, L3, RTF, Part Suppt, Mon", response.getEntitlements().get(47).getServiceDescription());
		assertEquals("Onsite L2, L3, RTF", response.getEntitlements().get(48).getServiceDescription());
		assertEquals("Onsite L2, L3, RTF, Monitoring", response.getEntitlements().get(49).getServiceDescription());
		assertEquals("Onsite L2, L3, RTF, Part Suppt", response.getEntitlements().get(50).getServiceDescription());
		assertEquals("Onsite L2, L3, RTF, Part Suppt, Mon", response.getEntitlements().get(51).getServiceDescription());
		assertEquals("Onsite L3, RTF", response.getEntitlements().get(52).getServiceDescription());
		assertEquals("Onsite L3, RTF, Monitoring", response.getEntitlements().get(53).getServiceDescription());
		assertEquals("Onsite L3, RTF, Part Suppt", response.getEntitlements().get(54).getServiceDescription());
		assertEquals("Onsite L3, RTF, Part Suppt, Monitoring",
				response.getEntitlements().get(55).getServiceDescription());
		assertEquals("Remote Connection L3 NBD Parts Support",
				response.getEntitlements().get(56).getServiceDescription());
		assertEquals("Remote Connection L3 RTF", response.getEntitlements().get(57).getServiceDescription());
		assertEquals("Remote L1, L2, L3", response.getEntitlements().get(58).getServiceDescription());
		assertEquals("Remote L2, L3", response.getEntitlements().get(59).getServiceDescription());
		assertEquals("Remote L3", response.getEntitlements().get(60).getServiceDescription());
		assertEquals("Remote L3, partner monitored", response.getEntitlements().get(61).getServiceDescription());
		assertEquals("SW L2 L3 SPPT RR SLO", response.getEntitlements().get(62).getServiceDescription());
		assertEquals("Enhanced", response.getEntitlements().get(63).getServiceDescription());
		assertEquals("Keep Your Hard Drive", response.getEntitlements().get(64).getServiceDescription());
		assertEquals("Keep Your Component", response.getEntitlements().get(65).getServiceDescription());
		assertEquals("ProSupport One NBD", response.getEntitlements().get(66).getServiceDescription());
		assertEquals("VxFlex Ready Node", response.getEntitlements().get(67).getServiceDescription());
		assertEquals("Advanced Distributers Support", response.getEntitlements().get(68).getServiceDescription());
		assertEquals("ProSupport", response.getEntitlements().get(69).getServiceDescription());
		assertEquals("ProSupport", response.getEntitlements().get(70).getServiceDescription());
		assertEquals("ProSupport", response.getEntitlements().get(71).getServiceDescription());
		assertEquals("ProSupport", response.getEntitlements().get(72).getServiceDescription());
		

	}

	@Test
	public void testGetWarrantiesWithNullServiceDescription() throws Exception {
		// Arrange

		Entitlement ent1 = new Entitlement();
		ent1.setType("RET");
		// Set other properties as needed

		List<Entitlement> result = new ArrayList<Entitlement>();
		result.add(ent1);

		when(mapper.getWarranties("AB1234")).thenReturn(result);

		// Act
		WarrantyResponse response = service.getWarranties("AB1234");

		// Assert
		assertEquals(response.getEntitlements().size(), 1);
		assertEquals(response.getProductId(), "AB1234");
		// Add assertions to ensure that serviceDescription is set based on the
		// conditions in the service class
		// e.g., check that serviceDescription is set to "Parts Retention" for type
		// "RET"
	}

	@Test
	public void testGetWarrantiesWithNullContractAndType() throws Exception {
		// Arrange

		Entitlement ent1 = new Entitlement();
		// Set other properties as needed

		List<Entitlement> result = new ArrayList<Entitlement>();
		result.add(ent1);

		when(mapper.getWarranties("AB1234")).thenReturn(result);

		// Act
		WarrantyResponse response = service.getWarranties("AB1234");

		// Assert
		assertEquals(response.getEntitlements().size(), 1);
		assertEquals(response.getProductId(), "AB1234");
		// Add assertions to ensure that the "if" condition related to contract and type
		// is covered
	}

//	@Test
//    public void testGetCurrentIBtable() {
//        // Arrange
//        when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(String.class))).thenReturn("ib_p1");
//
//        // Act
//        String currentIBTable = service.getCurrentIBtable();
//
//        // Assert
//        assertEquals("ib_p1", currentIBTable);
//    }

	@Test
	public void testInstanceNumber() throws JsonProcessingException {
		// Create a sample JSON object with the "instanceNumber" field
		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode jsonNode = JsonNodeFactory.instance.objectNode();
		jsonNode.put("instanceNumber", 42);

		// Serialize the JSON object to a string
		String jsonString = objectMapper.writeValueAsString(jsonNode);

		// Call the instanceNumber method and validate the result
		int result = service.instanceNumber(jsonString);

		// Assert that the result matches the expected value (42)
		assertEquals(42, result);
	}

	@Test(expected = JsonProcessingException.class)
	public void testInstanceNumberInvalidJson() throws JsonProcessingException {
		// Provide invalid JSON to test the JsonProcessingException
		String invalidJson = "{ invalidJson }";

		// Call the instanceNumber method with invalid JSON, which should throw an
		// exception
		service.instanceNumber(invalidJson);
	}

	@Test
	public void testInsertConnectHomeData() {
		// Prepare the test data
		Map<String, Object> params = new HashMap<>();
		params.put("param1", "value1");
		params.put("param2", "value2");

		// Call the method to be tested
		service.insertConnectHomeData(params);

		// Verify that installBaseMapper.insertConnectHomeData is called with the
		// expected parameters
		Mockito.verify(mapper).insertConnectHomeData(params);
	}

	@Test
	public void testUpdateConnectHomeData() {
		// Prepare the test data
		Map<String, Object> params = new HashMap<>();
		params.put("param1", "value1");
		params.put("param2", "value2");

		// Call the method to be tested
		service.updateConnectHomeData(params);

		// Verify that installBaseMapper.updateConnectHomeData is called with the
		// expected parameters
		Mockito.verify(mapper).updateConnectHomeData(params);
	}

	@Test
	public void testUpdateGatewayData() {
		// Prepare test data
		Map<String, Object> deviceData = new HashMap<>();
		deviceData.put("param1", "value1");
		deviceData.put("param2", "value2");
		List<Map<String, Object>> params = Collections.singletonList(deviceData);

		// Mock behavior for installBaseMapper.deleteDeviceData
		Mockito.when(mapper.deleteDeviceData(deviceData)).thenReturn(1);

		// Call the method to be tested
		service.updateGatewayData(params);

		// Verify that installBaseMapper.deleteDeviceData and
		// installBaseMapper.insertDeviceData are called as expected
		Mockito.verify(mapper).deleteDeviceData(deviceData);
		Mockito.verify(mapper).insertDeviceData(params);
	}

	@Test
	public void testUpsertEsrsDeviceStatus() {
		// Prepare test data for device status details
		Map<String, Object> deviceStatusDetails = createDeviceStatusDetails(); // Implement this method

		// Call the method to be tested
		service.upsertEsrsDeviceStatus(deviceStatusDetails);

		// Verify that installBaseMapper.updateEsrsDeviceStatus is called with the
		// expected parameters
		Mockito.verify(mapper).updateEsrsDeviceStatus(deviceStatusDetails);
	}

	// Helper method to create sample device status details
	private Map<String, Object> createDeviceStatusDetails() {
		Map<String, Object> deviceStatusDetails = new HashMap<>();
		deviceStatusDetails.put("deviceId", "device123");
		deviceStatusDetails.put("status", "active");
		// Add more key-value pairs as needed
		return deviceStatusDetails;
	}

	@Test
	public void testGetCodeLevelsProductsTest() {
		// Scenario 1: Basic test case
		OutputStream outputStream = mock(OutputStream.class);
		Map<String, Object> filterParams = new HashMap<>();
		List<Column> columns = Arrays.asList(new Column(), new Column());

		service.getCodeLevelsProducts(outputStream, filterParams, columns);

		Map<String, String> expectedColumns = new LinkedHashMap<>();
		columns.forEach(col -> expectedColumns.put(col.getTitle(), col.getField()));
		verify(mapper).getCodeLevelsProducts(any(StreamResultHandler.class), eq(filterParams));

		// Scenario 2: Test with additional filterParams
		filterParams.put("additionalParam", "value");
		service.getCodeLevelsProducts(outputStream, filterParams, columns);
		verify(mapper, times(2)).getCodeLevelsProducts(any(StreamResultHandler.class), eq(filterParams));

		// Add more scenarios as needed...
	}

	@Test
	public void testGetSolutionComponents() {
		// Arrange
		OutputStream outputStream = mock(OutputStream.class);

		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("timeZone", "UTC");

		List<Column> columns = Arrays.asList(new Column(), new Column()
		// Add more columns as needed
		);

		// Act
		service.getSolutionComponents(outputStream, filterParams, columns);

		// Assert
		// You can add more specific assertions based on your requirements
		verify(mapper, times(1)).getSolutionComponents(any(), eq(filterParams));
	}

	@Test
	public void testGetMilestoneStats_NonNullProduct() {
		// Arrange
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("tlvTimeRangeBefore", 1636128000000L); // Replace with your before date
		filterParams.put("tlvTimeRangeAfter", 1667664000000L); // Replace with your after date

		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		// Mock the getProductDetail method to return a non-null product
		Mockito.when(mapper.getProductDetail(Mockito.any())).thenReturn(productsList);

		// Act
		MilestoneStatsBean result = service.getMilestoneStats(filterParams);

		// Assert
		assertNotNull(result); // When the product is not null, the result should not be null
		// Add more assertions based on your logic
	}

	@Test
	public void testMilestoneStatsWithTimeRange() {
		// Create your service and mapper mocks

		// Prepare sample filterParams
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("tlvTimeRangeBefore", 1636128000000L); // Replace with your before date
		filterParams.put("tlvTimeRangeAfter", 1667664000000L); // Replace with your after date

		// Prepare a dummy product for the test
		ProductBean product = new ProductBean();
		product.setEops(1635000000000L); // Replace with an EOPS date
		product.setContractEndDate(1640000000000L); // Replace with a Contract End Date
		// Set other relevant dates on the product...
		List<ProductBean> productsList = new ArrayList<>();
		ProductBean pb = new ProductBean();
		pb.setProductFamily("productFamily");
		productsList.add(pb);
		when(mapper.getProductDetail(anyMap())).thenReturn(productsList);
		// Mock the getProductDetail method to return a non-null product
		Mockito.when(mapper.getProductDetail(Mockito.any())).thenReturn(productsList);

		// Call the method being tested
		MilestoneStatsBean milestoneStatsBean = service.getMilestoneStats(filterParams);

		// Assert the results based on the provided sample dates
		assertEquals(0, milestoneStatsBean.getEopsDateCount());
		assertEquals(0, milestoneStatsBean.getContractEndDateCount());
		// Check other date comparisons...

		// Optionally, verify that the getProductDetail method was called with the
		// expected filterParams
		verify(mapper).getProductDetail(filterParams);
	}

	@Test
	public void testGetContractRenewal() throws IOException {
		// Mocks for dependencies and objects
		OutputStream outputStream = mock(OutputStream.class);
		// Sample data
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("timeZone", "UTC");

		// Create columns with specific behavior using mockito
		Column mockedColumn1 = mock(Column.class);
		when(mockedColumn1.getTitle()).thenReturn("Title1");
		when(mockedColumn1.getField()).thenReturn("Field1");

		Column mockedColumn2 = mock(Column.class);
		when(mockedColumn2.getTitle()).thenReturn("Title2");
		when(mockedColumn2.getField()).thenReturn("Field2");

		List<Column> columns = new ArrayList<>();
		columns.add(mockedColumn1);
		columns.add(mockedColumn2);

		// Capture the OutputStream and verify its interaction
		ArgumentCaptor<OutputStream> outputStreamCaptor = ArgumentCaptor.forClass(OutputStream.class);

		// Invoke the method
		service.getContractRenewal(outputStream, filterParams, columns);

		// Verify the interactions and method invocations
		verify(mapper).getContractRenewal(any(), eq(filterParams)); // You might need to adjust the argument capture
																	// here

		// Assert other interactions as needed based on the behavior within
		// StreamResultHandler or the service method.
	}

	@Test
	public void testGetAliasChanges() {
		OutputStream outputStream = mock(OutputStream.class);

		Map<String, Object> filterParams = new LinkedHashMap<>();
		filterParams.put("timeZone", "UTC");

		// Create columns with specific behavior using mockito
		Column mockedColumn1 = mock(Column.class);
		when(mockedColumn1.getTitle()).thenReturn("Title1");
		when(mockedColumn1.getField()).thenReturn("Field1");

		Column mockedColumn2 = mock(Column.class);
		when(mockedColumn2.getTitle()).thenReturn("Title2");
		when(mockedColumn2.getField()).thenReturn("Field2");

		List<Column> columns = new ArrayList<>();
		columns.add(mockedColumn1);
		columns.add(mockedColumn2);

		ArgumentCaptor<OutputStream> outputStreamCaptor = ArgumentCaptor.forClass(OutputStream.class);

		service.getAliasChanges(outputStream, filterParams, columns);

		verify(mapper).getAliasChanges(any(), eq(filterParams));

		// You might need to capture the StreamResultHandler constructor arguments for
		// further verification
		// verifyNew(StreamResultHandler.class).withArguments(eq(outputStreamCaptor.capture()),
		// eq(columns), eq(true), anyString());
		// Assert any interactions or expected behavior based on StreamResultHandler and
		// installBaseMapper.
	}

	@Test
	public void testGetLocationChanges() {
		OutputStream outputStream = mock(OutputStream.class);

		Map<String, Object> filterParams = new LinkedHashMap<>();
		filterParams.put("timeZone", "UTC");

		// Mock the columns
		Column mockedColumn1 = mock(Column.class);
		when(mockedColumn1.getTitle()).thenReturn("Title1");
		when(mockedColumn1.getField()).thenReturn("Field1");

		Column mockedColumn2 = mock(Column.class);
		when(mockedColumn2.getTitle()).thenReturn("Title2");
		when(mockedColumn2.getField()).thenReturn("Field2");

		List<Column> columns = new ArrayList<>();
		columns.add(mockedColumn1);
		columns.add(mockedColumn2);

		ArgumentCaptor<OutputStream> outputStreamCaptor = ArgumentCaptor.forClass(OutputStream.class);

		service.getLocationChanges(outputStream, filterParams, columns);

		verify(mapper).getLocationChanges(any(), eq(filterParams));

		// You might need to capture the StreamResultHandler constructor arguments for
		// further verification
		// verifyNew(StreamResultHandler.class).withArguments(eq(outputStreamCaptor.capture()),
		// eq(columns), eq(true), anyString());
		// Assert any interactions or expected behavior based on StreamResultHandler and
		// installBaseMapper.
	}

	@Test
	public void testGetEsrsChangeEvent() {

		List<EsrsChangeEventBean> esrsChangeEventBeans = new ArrayList<>();
		// Populate the 'esrsChangeEventBeans' with test data

		// Mock the behavior of installBaseMapper
		when(mapper.getEsrsChangeEvent(any())).thenReturn(esrsChangeEventBeans);

		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("deviceId", 1); // Mocking deviceId

		// Adding test data to filterParams for gatewayDeviceIds
		filterParams.put("gatewayDeviceIds", "2,3,4");

		List<Map<String, Object>> expectedData = new ArrayList<>();
		// Add expected data as per the logic in your 'getEsrsChangeEvent' method

		List<Map<String, Object>> actualData = service.getEsrsChangeEvent(filterParams);

		// Assert statements to compare expected and actual data
		assertEquals(expectedData, actualData);
		verify(mapper).getEsrsChangeEvent(any());
		// Include more assertions or verifications based on the behavior of your
		// 'getEsrsChangeEvent' method
	}

	@Test
	public void testGetChangesAndSubmissionsStats() {
		// Sample test data
		List<Map<String, Object>> sampleStats = Arrays.asList(Map.of("type", "Type1", "count", 10),
				Map.of("type", "Type2", "count", 5)
		// Add more as needed
		);

		// Mock the behavior of installBaseMapper.getChangesAndSubmissionsStats()
		when(mapper.getChangesAndSubmissionsStats(any())).thenReturn(sampleStats);

		// Call the method being tested
		Map<String, Object> result = service.getChangesAndSubmissionsStats(anyMap());

		// Test if the resulting map contains the expected keys and values
		assertEquals(10, result.get("Type1"));
		assertEquals(5, result.get("Type2"));
		// Add more assertions if needed based on your test data
	}

	

}
