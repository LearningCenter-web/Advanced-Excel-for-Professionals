package com.emc.dvs.ib.exception;

import org.junit.Test;

public class BadRequestExceptionTests {

    @Test
    public void testExceptionWithMessage() {
        // Arrange
        String errorMessage = "Bad Request Exception Message";

        // Act
        BadRequestException exception = new BadRequestException(errorMessage);

        // Assert
        assert(exception.getMessage().equals(errorMessage));
    }

    @Test
    public void testExceptionWithMessageAndCause() {
        // Arrange
        String errorMessage = "Bad Request Exception Message";
        Throwable cause = new RuntimeException("Root cause");

        // Act
        BadRequestException exception = new BadRequestException(errorMessage, cause);

        // Assert
        assert(exception.getMessage().equals(errorMessage));
        assert(exception.getCause() == cause);
    }
}

