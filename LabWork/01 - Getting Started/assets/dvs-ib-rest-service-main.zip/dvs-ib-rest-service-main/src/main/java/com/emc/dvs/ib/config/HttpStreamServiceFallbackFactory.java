package com.emc.dvs.ib.config;

import org.springframework.stereotype.Component;

import com.emc.dvs.ib.fallback.HttpStreamServiceFallbackImpl;
import com.emc.dvs.ib.service.HttpStreamService;

import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class HttpStreamServiceFallbackFactory implements FallbackFactory<HttpStreamService>{

	@Override
	public HttpStreamService create(Throwable cause) {
		log.info("Feign client call failed");
		return new HttpStreamServiceFallbackImpl(cause);
	}

}
