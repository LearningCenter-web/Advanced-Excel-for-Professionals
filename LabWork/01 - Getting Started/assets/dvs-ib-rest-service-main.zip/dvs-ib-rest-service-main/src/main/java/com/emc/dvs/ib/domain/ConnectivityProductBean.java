package com.emc.dvs.ib.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class ConnectivityProductBean {
		
	private String serialNumber;
	private String productName;
	private String productFamily;
	private String siteDisplayName;
	private String connectionType;
	private String lastConnectHome;
	private String connectFlag;
	private String instanceNumber;
	private String lemcInstanceNumber;
	@JsonIgnore
	private String ibStatus;
	private boolean serialNumberProductPage;
	private String productPageUrl;
}
