package com.emc.dvs.ib.domain;

import java.util.List;

import lombok.Data;

@Data
public class WarrantyResponse {
	private List<Entitlement> entitlements;
	private boolean entitlementPresent;
	private String  productId;
}
