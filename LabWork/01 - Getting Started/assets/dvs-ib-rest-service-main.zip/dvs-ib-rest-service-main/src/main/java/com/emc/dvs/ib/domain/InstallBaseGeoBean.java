package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class InstallBaseGeoBean {
	
	private String siteNumber;
	private String siteName;
	private String latitude;
	private String longitude;
	private String city;
	private int productCount;

}
