
package com.emc.dvs.ib.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class IpsNote {

	String userName;
	String email;
	String ntId;
	String advisoryNote;
	String role;
	String resolution;
	String articleId;
	String instanceId;
	String flag;
	String companyName;
	String productId;
	String recordType;
	@ExportDate(value = "d MMM yyyy, hh:mm a")
	private Long timestamp;
	
	
	public boolean isEquals(IpsNote ipsNote) {
		boolean isEquals = true;
		if (!this.getUserName().equalsIgnoreCase(ipsNote.getUserName())) {
			isEquals = false;
		}
		if (!this.getEmail().equalsIgnoreCase(ipsNote.getEmail())) {
			isEquals = false;
		}
		if (!this.getResolution().equalsIgnoreCase(ipsNote.getResolution())) {
			isEquals = false;
		}
		if (!this.getArticleId().equalsIgnoreCase(ipsNote.getArticleId())) {
			isEquals = false;
		}
		if (!this.getInstanceId().equalsIgnoreCase(ipsNote.getInstanceId())) {
			isEquals = false;
		}
		if (!this.getProductId().equalsIgnoreCase(ipsNote.getProductId())) {
			isEquals = false;
		}
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		Date thisDate = new Date(this.getTimestamp()); 
		Date ipsNoteDate = new Date(ipsNote.getTimestamp()); 
		
		if (!ipsNoteDate.toString().equalsIgnoreCase(thisDate.toString())) {
			isEquals = false;
		}		
		return isEquals;
	}
}
