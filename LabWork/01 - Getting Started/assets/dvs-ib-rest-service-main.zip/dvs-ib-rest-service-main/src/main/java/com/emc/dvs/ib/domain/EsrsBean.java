package com.emc.dvs.ib.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class EsrsBean {
	@JsonIgnore
	private String id;
	private String uidForAlias;
	private String alias;
	private Long aliasLastUpdatedOn;
	private String aliasLastUpdatedBy;
	private String relationshipTypeForAlias;
	private String userIdentityTypeForAlias; 	
}
