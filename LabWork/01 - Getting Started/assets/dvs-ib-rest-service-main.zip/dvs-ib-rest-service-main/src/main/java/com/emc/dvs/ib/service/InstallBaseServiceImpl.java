package com.emc.dvs.ib.service;

import static  java.util.stream.Collectors.joining;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.emc.dvs.export.StreamResultHandler;
import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectHomeDurationBean;
import com.emc.dvs.ib.domain.ConnectivityAggBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractInventoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.Entitlement;
import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsChangeEventBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.domain.GatewayBean;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseProductBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.MilestoneStatsBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.ProductSiteChangeBean;
import com.emc.dvs.ib.domain.SiteBean;
import com.emc.dvs.ib.domain.WarrantyResponse;
import com.emc.dvs.ib.exception.PersistenceException;
import com.emc.dvs.ib.exception.ResourceNotFoundException;
import com.emc.dvs.ib.persistance.InstallBaseMapper;
import com.emc.dvs.ib.util.CommonUtils;
import com.emc.dvs.ib.util.SiteRelationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("InstallBaseService")
@CacheConfig(cacheNames = { "ib" })
public class InstallBaseServiceImpl implements InstallBaseService {

	private final String CONNECTED = "Connected";
	private final String PRODUCT_NAME_IS_IN = "productNameIsIn";
	private final String CONTRACT_STATUS_IS_IN = "contractStatusIsIn";
	private final String INSTANCE_NUMBER_FILTER_IS_IN = "instanceNumberFilterIsIn";
	private static final String CLUSTER_ID = "clusterId";
	private final JdbcTemplate jdbcTemplate;
	ObjectMapper objectMapper = new ObjectMapper();
	
	@Setter
	@Value("${dvs.defaultConnectHomeStatusDuration}")
	private Long defaultConnectHomeStatusDuration;
	
	@Setter
	@Value("${dvs.sendEmailDuration}")
	private Long sendEmailDuration;
	
	@Value("${spring.profiles.active:default}")
	@Setter
	private String activeProfile;
	
	@Value("${dvs.tridentConnectHomeStatusDuration}")
	private String tridentConnectHomeStatusDuration;
	
	@Value("${bdl.esrs.apiKey}")
	private String apiKey;
	
	private static final DateTimeFormatter lastContactFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneOffset.UTC);
	
	private InstallBaseMapper installBaseMapper;	
	
	private MailService mailService;
	
	private EsrsService esrsService;
	
	private SiteRelationService siteRelationService;
	
	private static String proSupportPlusMissionCritical = "PP|BPP|MPN|EPP|PPP|PPV|PQ1";

	@Value("${installbase.sdata.updatesql}")
	private String updateSql;

	@Value("${installbase.sdata.insertsql}")
	private String insertSql;

	@Value("${installbase.sdata.idexistssql}")
	private String idExistsSql;
	@Autowired
	public InstallBaseServiceImpl(InstallBaseMapper installBaseMapper, SiteRelationService siteRelationService,MailService mailService,
								  EsrsService esrsService, JdbcTemplate jdbcTemplate) {
		this.installBaseMapper = installBaseMapper;		
		this.mailService = mailService;
		this.esrsService = esrsService;
		this.siteRelationService =siteRelationService;
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * Install Base stats - connected, expired contract etc.
	 */
	@Async
	public Future<InstallBaseStatsBean> getInstallBaseStats(Map<String, Object> filterParams) {
		InstallBaseStatsBean stats = installBaseMapper.getInstallBaseStats(filterParams);
		// convert connected to a % of total (HW) - Not Eligible
		int total = stats.getTotal() - stats.getNotConnectedEligible();
		if (total > 0) {
			stats.setConnectedPercent((int) Math.round(stats.getConnected() * 100.0 / total));
		}
		return new AsyncResult<InstallBaseStatsBean>(stats);
	}

	/**
	 * Install Base details - product count grouped by location
	 */
	@Async
	public Future<List<InstallBaseGeoBean>> getInstallBaseGeoDetails(Map<String, Object> filterParams) {
		List<InstallBaseGeoBean> details = installBaseMapper.getInstallBaseGeoDetails(filterParams);
		return new AsyncResult<List<InstallBaseGeoBean>>(details);
	}

	/**
	 * Return the filter values associated with the resultset
	 * 
	 * <p>
	 * All Filter Values in the data set
	 * <ul>
	 * <li>tlaFlagIsIn
	 * <li>isStatusIsIn
	 * <li>siteDisplayNameIsIn
	 * <li>productFamilyIsIn
	 * </ul>
	 * 
	 * @param filterParams
	 * @return
	 */
	@Override
	@Async
	public Future<InstallBaseFilterValuesBean> getInstallBaseFilterValues(Map<String, Object> filterParams) {
		InstallBaseFilterValuesBean filterValues = installBaseMapper.getInstallBaseAllFilterValues(filterParams);
		return new AsyncResult<InstallBaseFilterValuesBean>(filterValues);
	}

	/**
	 * Return the serial numbers associated with the data set These are
	 * "Relevant Filter Values"
	 * 
	 * @param filterParams
	 * @return
	 */
	@Override
	public List<String> getSerialNumbers(Map<String, Object> filterParams) {
		//filterParams.remove(SERIAL_NUMBER_IS_IN);
		return installBaseMapper.getInstallBaseSerialNumbers(filterParams);
	}
	
	/**
	 * Return the instance ids associated with the data set These are "Relevant
	 * Filter Values"
	 * 
	 * @param filterParams
	 * @return
	 */
	@Override
	public List<String> getInstanceIds(Map<String, Object> filterParams){
		filterParams.remove(INSTANCE_NUMBER_FILTER_IS_IN);
		return installBaseMapper.getInstallBaseInstanceNumbers(filterParams);
	}

	/**
	 * Return the product names associated with the data set These are "Relevant
	 * Filter Values"
	 * 
	 * @param filterParams
	 * @return
	 */
	@Override
	@Async
	public Future<List<String>> getProductNames(Map<String, Object> filterParams) {
		filterParams.remove(PRODUCT_NAME_IS_IN);
		List<String> serials = installBaseMapper.getInstallBaseProductNames(filterParams);
		return new AsyncResult<List<String>>(serials);
	}

	/**
	 * Return the Contract Status associated with the data set These are
	 * "Relevant Filter Values"
	 * 
	 * @param filterParams
	 * @return
	 */
	@Override
	@Async
	public Future<List<String>> getContractStatus(Map<String, Object> filterParams) {
		filterParams.remove(CONTRACT_STATUS_IS_IN);
		List<String> ContractStatus = installBaseMapper.getContractStatus(filterParams);
		return new AsyncResult<List<String>>(ContractStatus);
	}

	@Override
	@Async
	public Future<Map<String, Object>> getConnectivityAggregate(Map<String, Object> filterParams) {
		List<ConnectivityAggBean> aggList = installBaseMapper.getConnectivityAggregate(filterParams);
		Map<String, List<ConnectivityAggBean>> connectFlagMap = aggList.stream()
				.collect(Collectors.groupingBy(l -> l.getConnectFlag()));
		// Ensure Connected and Not Connected is always returned even when none
		// are in the result set
		if (!connectFlagMap.containsKey("Connected")) {
			connectFlagMap.put("Connected", new ArrayList<ConnectivityAggBean>());
		}
		if (!connectFlagMap.containsKey("Not Connected")) {
			connectFlagMap.put("Not Connected", new ArrayList<ConnectivityAggBean>());
		}

		List<ConnectivityAggBean> connectedList = connectFlagMap.get("Connected");
		Map<String, Integer> connectedConnectionTypeMapFormat = new HashMap<String, Integer>();
		Map<String, Object> connectedProductFamilyMapFormat = new HashMap<String, Object>();
		if (connectedList.size() != 0) {
			Map<String, List<ConnectivityAggBean>> connectedConnectionTypeMap = connectedList.stream()
					.collect(Collectors.groupingBy(l -> l.getConnectionType()));
			connectedConnectionTypeMap.keySet().forEach(k -> {
				connectedConnectionTypeMapFormat.put(k, connectedConnectionTypeMap.get(k).stream()
						.mapToInt(ConnectivityAggBean::getConnectionTypeCount).sum());
			});

			Map<String, List<ConnectivityAggBean>> connectedProductFamilyMap = connectedList.stream()
					.collect(Collectors.groupingBy(l -> l.getProductFamily()));
			connectedProductFamilyMap.keySet().forEach(k -> {
				Map<String, List<ConnectivityAggBean>> connectedProductFamilyConnectionTypeMap = connectedProductFamilyMap
						.get(k).stream().collect(Collectors.groupingBy(l -> l.getConnectionType()));
				Map<String, Integer> connectedProductFamilyConnectionTypeMapFormat = new HashMap<String, Integer>();
				connectedProductFamilyConnectionTypeMap.keySet().forEach(e -> {
					connectedProductFamilyConnectionTypeMapFormat.put(e, connectedProductFamilyConnectionTypeMap.get(e)
							.stream().mapToInt(ConnectivityAggBean::getConnectionTypeCount).sum());
				});
				connectedProductFamilyMapFormat.put(k, connectedProductFamilyConnectionTypeMapFormat);
			});
		}
		Map<String, Object> connectedMap = new HashMap<String, Object>();
		connectedMap.put("connectionTypeMap", connectedConnectionTypeMapFormat);
		connectedMap.put("productFamilyMap", connectedProductFamilyMapFormat);

		List<ConnectivityAggBean> notConnectedList = connectFlagMap.get("Not Connected");
		Map<String, Integer> notConnectedConnectionTypeMapFormat = new HashMap<String, Integer>();
		Map<String, Object> notConnectedProductFamilyMapFormat = new HashMap<String, Object>();
		if (notConnectedList.size() != 0) {
			Map<String, List<ConnectivityAggBean>> notConnectedConnectionTypeMap = notConnectedList.stream()
					.collect(Collectors.groupingBy(l -> l.getConnectionType()));
			notConnectedConnectionTypeMap.keySet().forEach(k -> {
				notConnectedConnectionTypeMapFormat.put(k, notConnectedConnectionTypeMap.get(k).stream()
						.mapToInt(ConnectivityAggBean::getConnectionTypeCount).sum());
			});

			Map<String, List<ConnectivityAggBean>> notConnectedProductFamilyMap = notConnectedList.stream()
					.collect(Collectors.groupingBy(l -> l.getProductFamily()));
			notConnectedProductFamilyMap.keySet().forEach(k -> {
				Map<String, List<ConnectivityAggBean>> notConnectedProductFamilyConnectionTypeMap = notConnectedProductFamilyMap
						.get(k).stream().collect(Collectors.groupingBy(l -> l.getConnectionType()));
				Map<String, Integer> notConnectedProductFamilyConnectionTypeMapFormat = new HashMap<String, Integer>();
				notConnectedProductFamilyConnectionTypeMap.keySet().forEach(e -> {
					notConnectedProductFamilyConnectionTypeMapFormat.put(e, notConnectedProductFamilyConnectionTypeMap
							.get(e).stream().mapToInt(ConnectivityAggBean::getConnectionTypeCount).sum());
				});
				notConnectedProductFamilyMapFormat.put(k, notConnectedProductFamilyConnectionTypeMapFormat);
			});
		}
		Map<String, Object> notConnectedMap = new HashMap<String, Object>();
		notConnectedMap.put("connectionTypeMap", notConnectedConnectionTypeMapFormat);
		notConnectedMap.put("productFamilyMap", notConnectedProductFamilyMapFormat);

		Map<String, Object> aggMap = new HashMap<String, Object>();
		aggMap.put("connected", connectedMap);
		aggMap.put("notConnected", notConnectedMap);

		return new AsyncResult<Map<String, Object>>(aggMap);
	}

	@Override
	@Async
	public Future<Integer> getConnectivityTotalRecord(Map<String, Object> filterParams) {
		return new AsyncResult<Integer>(installBaseMapper.getConnectivityTotalRecord(filterParams));
	}

	@Override
	@Async
	public Future<List<ConnectivityProductBean>> getConnectivityList(Map<String, Object> filterParams) {
		return new AsyncResult<List<ConnectivityProductBean>>(installBaseMapper.getConnectivityList(filterParams));
	}

	/**
	 * 
	 */
	@Async
	public Future<Integer> getCodeLevelsTotalRecord(Map<String, Object> filterParams) {
		return new AsyncResult<Integer>(installBaseMapper.getCodeLevelsTotalRecord(filterParams));
	}

	@Async
	public Future<List<CodeLevelsProductBean>> getCodeLevelsProducts(Map<String, Object> filterParams) {
		return new AsyncResult<List<CodeLevelsProductBean>>(installBaseMapper.getCodeLevelsProducts(filterParams));
	}

	@Override
	public List<CodeLevelsAggBean> getCodeLevelsAggregate(Map<String, Object> filterParams) {
		// TODO Auto-generated method stub
		return installBaseMapper.getCodeLevelsAggregate(filterParams);
	}

	@Override
	public List<ContractCategoryBean> getContractCategoryAggregate(Map<String, Object> filterParams) {
		return installBaseMapper.getContractCategoryAggregate(filterParams);
	}

	@Async
	public Future<Integer> getContractTimelineTotal(Map<String, Object> filterParams) {
		return new AsyncResult<Integer>(installBaseMapper.getContractTimelineTotal(filterParams));
	}

	@Async
	public Future<List<ContractTimelineBean>> getContractTimeline(Map<String, Object> filterParams) {
		return new AsyncResult<List<ContractTimelineBean>>(installBaseMapper.getContractTimeline(filterParams));
	}

	@Async
	public Future<Integer> getContractInventoryTotal(Map<String, Object> filterParams) {
		return new AsyncResult<Integer>(installBaseMapper.getContractInventoryTotal(filterParams));
	}

	@Async
	public Future<List<ContractInventoryBean>> getContractInventory(Map<String, Object> filterParams) {
		return new AsyncResult<List<ContractInventoryBean>>(installBaseMapper.getContractInventory(filterParams));
	}

	@Override
	public void getConnectivityList(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String, String> columns = new LinkedHashMap<String, String>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));

		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getConnectivityList(resultHandler, filterParams);

	}

	@Override
	public void getCodeLevelsProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String, String> columns = new LinkedHashMap<String, String>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));

		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getCodeLevelsProducts(resultHandler, filterParams);

	}

	@Override
	public void getContractInventory(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String, String> columns = new LinkedHashMap<String, String>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));

		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getContractInventory(resultHandler, filterParams);

	}

	@Override
	public ProductBean getProductDetail(Map<String, Object> filterParams) {
		List<ProductBean> products = installBaseMapper.getProductDetail(filterParams);
		if (!products.isEmpty()) {
			ProductBean product = products.get(0);
			if (CONNECTED.equalsIgnoreCase(product.getConnectFlag())) {
				product.setConnectHomeStatusDuration(getConnectHomeStatusDuration(product.getProductFamily()));
			}
			return product;
		}
		return null;
	}
	
	@Override
	public MilestoneStatsBean getMilestoneStats(Map<String, Object> filterParams) {
		MilestoneStatsBean milestoneStatsBean = new MilestoneStatsBean();
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		ProductBean product = getProductDetail(filterParams);
		if (product != null) {
			boolean isTimeRangeExist = false;
            if (filterParams.containsKey("tlvTimeRangeBefore") && filterParams.containsKey("tlvTimeRangeAfter")) {
                isTimeRangeExist = true;
            }

            LocalDate tlvTimeRangeBeforeDate = null;
            LocalDate tlvTimeRangeAfterDate = null;
            if (isTimeRangeExist) {
                Long tlvTimeRangeBefore = Long.parseLong(filterParams.get("tlvTimeRangeBefore").toString());
                Long tlvTimeRangeAfter = Long.parseLong(filterParams.get("tlvTimeRangeAfter").toString());
                tlvTimeRangeBeforeDate = Instant.ofEpochMilli(tlvTimeRangeBefore).atZone(ZoneId.systemDefault()).toLocalDate();
                tlvTimeRangeAfterDate = Instant.ofEpochMilli(tlvTimeRangeAfter).atZone(ZoneId.systemDefault()).toLocalDate();
            }
			milestoneStatsBean.setEopsDateCount(CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getEops(),isTimeRangeExist) ? 1 : 0);
			milestoneStatsBean.setContractEndDateCount(CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getContractEndDate(),isTimeRangeExist)? 1 : 0);
			milestoneStatsBean.setInstallDateCount(CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getInstallDateLong(),isTimeRangeExist)? 1 : 0);
			milestoneStatsBean.setShipDateCount(CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getShipDate(),isTimeRangeExist) ? 1 : 0);
			milestoneStatsBean.setPurchaseDateCount(CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getPurchaseDate(),isTimeRangeExist)? 1 : 0);
			return milestoneStatsBean;
		}
		return null;
	}
	
	@Override
	@Cacheable
	public List<ComponentBean> getSolutionComponents(Map<String, Object> filterParams) {
		return installBaseMapper.getSolutionComponents(filterParams);
	}
	
	@Override
	public void getSolutionComponents(OutputStream out,Map<String, Object> filterParams,List<Column> cols) {
		Map<String, String> columns = new LinkedHashMap<String, String>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));

		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
				
		filterParams.remove("size");
		installBaseMapper.getSolutionComponents(resultHandler, filterParams);
	}

	public int getCurrentPartitionId() {
		return installBaseMapper.getCurrentPartitionId();
	}

	/**
	 * This method saves the uid, product serial number, contract renewal date
	 * and contract end date in product_change_event table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = PersistenceException.class)
	public Map<String, Object> insertContractRenewalRecord(Map<String, Object> contractDetails, String uid, String userName, String userIdentityType) {
		try {

			
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> filterParams = new HashMap<>();
 			filterParams.put("currentPartitionId", getCurrentPartitionId());
			filterParams.put("serialNumberIsIn", contractDetails.get("serialNumber"));
			ProductBean product = getProductDetail(filterParams);
			if (null == product) {
				throw new ResourceNotFoundException();
			}
			String siteId = Objects.toString(contractDetails.get("siteId"));
			Map<String, Object> contractRenewalMap = new HashMap<>();
			contractRenewalMap.put("uid", uid);
			contractRenewalMap.put("userName", userName);
			contractRenewalMap.put("userIdentityType", userIdentityType);
			contractRenewalMap.put("relationshipType", getRelationshipType(uid,siteId,userIdentityType,userName));
			contractRenewalMap.put("contractRequestType", contractDetails.get("contractRequestType"));
			contractRenewalMap.put("contractEndDate", product.getContractEndDate());
			contractRenewalMap.put("contractRenewalAction", contractDetails.get("contractRenewalAction"));
			contractRenewalMap.put("contractSubmissionDate", new Date().getTime());
			
			if("refreshEquipment".equals(contractDetails.get("contractRequestType"))) {
				product.setRefreshEquipmentRenewalDate(new Date().getTime());
				product.setRefreshEquipmentRenewalAction((String)contractDetails.get("contractRenewalAction"));
				product.setRefreshEquipmentContractSubmittedBy(userName);
			}
			else if("optimizeForStorage".equals(contractDetails.get("contractRequestType"))) {
				product.setOptimizedStorageRenewalDate(new Date().getTime());
				product.setOptimizedStorageRenewalAction((String)contractDetails.get("contractRenewalAction"));
				product.setOptimizedStorageContractSubmittedBy(userName);
			}
			else {
				product.setContractRenewalDate(new Date().getTime());
				product.setContractRenewalAction((String)contractDetails.get("contractRenewalAction"));
				product.setContractSubmittedBy(userName);
			}
			
			ProductSiteChangeBean productChangeBean = installBaseMapper.getProductChangeEvent(Long.parseLong(product.getInstanceNumber()));
			List<Map<String, Object>> listOfContractRenewal = new ArrayList<>();
			//Update the existing contract renewal entry
			if (productChangeBean != null) {
				Map<String, Object> productChangeData = mapper.readValue(productChangeBean.getData(), Map.class);
				//Add a new entry in existing contract renewal list
				if(productChangeData.get("contractRenewal") != null) {
					listOfContractRenewal = (List<Map<String, Object>>) productChangeData.get("contractRenewal");
				}
				listOfContractRenewal.add(contractRenewalMap);
				productChangeData.put("contractRenewal", listOfContractRenewal);
				String newValue = mapper.writeValueAsString(productChangeData);
				installBaseMapper.updateProductChangeEvent(Long.parseLong(product.getInstanceNumber()), newValue);
			} 
			//Insert a new contract renewal record
			else {
				Map<String, List<Map<String, Object>>> productChangeDataMap = new HashMap<>();
				listOfContractRenewal.add(contractRenewalMap);
				productChangeDataMap.put("contractRenewal", listOfContractRenewal);
				String newValue = mapper.writeValueAsString(productChangeDataMap);
				installBaseMapper.insertProductChangeEvent(Long.parseLong(product.getInstanceNumber()), newValue);
			}
			updateContractRenewalDate(product);
			return contractRenewalMap;
			
		} catch (IOException e) {
			log.error("Error inserting contract renewal data for serial number: {} \n {}", contractDetails.get("serialNumber"), e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}
	}
	
	/**
	 * This method adds/ updates a contractRenewalDate field in
	 * InstallBaseProduct JSON after contract renewal details are saved in the
	 * DB
	 * 
	 * @param product
	 */
	@SuppressWarnings("unchecked")
	private void updateContractRenewalDate(ProductBean product) {
		try {
			int partitionId = getCurrentPartitionId();
			InstallBaseProductBean ibProduct = installBaseMapper.getInstallBaseProduct(partitionId,
					product.getInstanceNumber());
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, Object> json = objectMapper.readValue(ibProduct.getData(), Map.class);
			json.put("contractRenewalDate", product.getContractRenewalDate());
			json.put("contractRenewalAction", product.getContractRenewalAction());
			json.put("refreshEquipmentRenewalDate", product.getRefreshEquipmentRenewalDate());
			json.put("refreshEquipmentRenewalAction", product.getRefreshEquipmentRenewalAction());
			json.put("optimizedStorageRenewalDate", product.getOptimizedStorageRenewalDate());
			json.put("optimizedStorageRenewalAction", product.getOptimizedStorageRenewalAction());
			json.put("optimizedStorageContractSubmittedBy", product.getOptimizedStorageContractSubmittedBy());
			json.put("contractSubmittedBy", product.getContractSubmittedBy());
			json.put("refreshEquipmentContractSubmittedBy", product.getRefreshEquipmentContractSubmittedBy());
			String newValue = objectMapper.writeValueAsString(json);
			installBaseMapper.updateInstallBaseProduct(ibProduct.getId(), partitionId, newValue);
		} catch (Exception e) {
			log.error("Error updatating contract renewal date for serial number: {} \n {}", product.getSerialNumber(),
					e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}
	}

	/**
	 * This method saves the site number and its corresponding data such as
	 * user_id, user_name and request_date in site_change_event table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = PersistenceException.class)
	public void insertSiteChangeEvent(Map<String, Object> requestMap, String uid, String userName, String userIdentityType) {

		try {
			Map<String, List<Map<String, Object>>> siteChangeDataMap = new HashMap<>();

			Map<String, Object> changeDetailMap = new HashMap<>();
			changeDetailMap.put("uid", uid);
			changeDetailMap.put("requestDate", new Date().getTime());
			changeDetailMap.put("userName", userName);
			changeDetailMap.put("userIdentityType", userIdentityType);
			changeDetailMap.put("relationshipType", getRelationshipType(uid,requestMap.get("originalSiteNumber").toString(),userIdentityType,userName));

			ProductSiteChangeBean productSiteChangeBean = installBaseMapper
					.getSiteChangeEvent(requestMap.get("originalSiteNumber").toString());

			// Existing entry of any site change information
			if (productSiteChangeBean != null) {

				ObjectMapper objectMapper = new ObjectMapper();
				Map<String, Object> json = objectMapper.readValue(productSiteChangeBean.getData(), Map.class);

				List<Map<String, Object>> listOfAddressChange = (List<Map<String, Object>>) json.get("locationChange");

				listOfAddressChange.add(changeDetailMap);

				String newValue = objectMapper.writeValueAsString(json);
				installBaseMapper.updateSiteChangeEvent(requestMap.get("originalSiteNumber").toString(), newValue);

			} else {

				List<Map<String, Object>> listOfChanges = new ArrayList<>();
				listOfChanges.add(changeDetailMap);

				siteChangeDataMap.put("locationChange", listOfChanges);

				ObjectMapper objectMapper = new ObjectMapper();
				String siteChangeData = objectMapper.writeValueAsString(siteChangeDataMap);

				installBaseMapper.insertSiteChangeEvent(requestMap.get("originalSiteNumber").toString(),
						siteChangeData);

			}			

		} catch (Exception e) {
			log.error("Error inserting site change information for site number: {} \n {}",
					requestMap.get("originalSiteNumber").toString(), e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}

	}

	/**
	 * This method returns the total number of products for specific site
	 * numbers
	 * 
	 * @param filterParams
	 * @return
	 */
	@Async
	@Override
	public Future<Integer> getProductsTotal(Map<String, Object> filterParams) {
		return new AsyncResult<Integer>(installBaseMapper.getProductsTotal(filterParams));
	}

	/**
	 * This method returns the paginated list of products for specific site
	 * numbers
	 * 
	 * @param filterParams
	 * @return
	 */
	@Async
	@Override
	public Future<List<ProductBean>> getProducts(Map<String, Object> filterParams) {
		List<ProductBean> products = installBaseMapper.getProductDetail(filterParams);
		return new AsyncResult<List<ProductBean>>(products);
	}

	@Override
	public void getProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String, String> columns = new LinkedHashMap<String, String>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));

		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getProductDetail(resultHandler, filterParams);
	}

	/**
	 * This method saves the instance number and its corresponding data such as
	 * user_id, user_name and request_date in product_change_event table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = PersistenceException.class)
	public void insertProductChangeEvent(Map<String, Object> siteDetails, String uid, String userName, String userIdentityType) {
		try {
			
			ObjectMapper mapper = new ObjectMapper();
			int partitionId = getCurrentPartitionId();
			
			String originalAddress = formatAddress(
					Objects.toString(siteDetails.get("originalAddress1"),null),
					Objects.toString(siteDetails.get("originalAddress2"),null),
					Objects.toString(siteDetails.get("originalCity"),null),
					Objects.toString(siteDetails.get("originalState"),null),
					Objects.toString(siteDetails.get("originalProvince"),null),
					Objects.toString(siteDetails.get("originalZipcode"),null),
					Objects.toString(siteDetails.get("originalCountry"),null));
			
			String updatedAddress = formatAddress(
					Objects.toString(siteDetails.get("updatedAddress1"),null),
					Objects.toString(siteDetails.get("updatedAddress2"),null),
					Objects.toString(siteDetails.get("updatedCity"),null),
					Objects.toString(siteDetails.get("updatedState"),null),
					Objects.toString(siteDetails.get("updatedProvince"),null),
					Objects.toString(siteDetails.get("updatedZipcode"),null),
					Objects.toString(siteDetails.get("updatedCountry"),null));

			Map<String, Object> changeDetailsMap = new HashMap<>();
			changeDetailsMap.put("uid", uid);
			changeDetailsMap.put("requestDate", new Date().getTime());
			changeDetailsMap.put("userName", userName);			
			changeDetailsMap.put("relationshipType", getRelationshipType(uid,siteDetails.get("originalSiteNumber").toString(),userIdentityType,userName));
			changeDetailsMap.put("originalSiteDisplayName", String.join(", ", siteDetails.get("originalSiteNumber").toString(), siteDetails.get("originalSiteName").toString()));
			changeDetailsMap.put("originalAddress", originalAddress);
			changeDetailsMap.put("updatedSiteDisplayName", String.join(", ", siteDetails.get("updatedSiteNumber").toString(), siteDetails.get("updatedSiteName").toString()));
			changeDetailsMap.put("updatedAddress", updatedAddress);
			
			
			ProductSiteChangeBean productChangeBean = installBaseMapper.getProductChangeEvent(Long.parseLong(siteDetails.get("instanceNumber").toString()));
			List<Map<String, Object>> listOfLocationChange = new ArrayList<Map<String, Object>>();
			//Update existing entry
			if (productChangeBean != null) {
				Map<String, Object> productChangeData = mapper.readValue(productChangeBean.getData(), Map.class);
				if(productChangeData.get("locationChange") != null) {
					//Add a new location change entry in existing location change list
					listOfLocationChange = (List<Map<String, Object>>) productChangeData.get("locationChange");
				}
				listOfLocationChange.add(changeDetailsMap);
				productChangeData.put("locationChange", listOfLocationChange);
				String newValue = mapper.writeValueAsString(productChangeData);				
				installBaseMapper.updateProductChangeEvent(Long.parseLong(siteDetails.get("instanceNumber").toString()), newValue);
			}
			//Insert a new entry
			else {
				Map<String, List<Map<String, Object>>> productChangeDataMap = new HashMap<>();
				listOfLocationChange.add(changeDetailsMap);
				productChangeDataMap.put("locationChange", listOfLocationChange);
				String newValue = mapper.writeValueAsString(productChangeDataMap);
				installBaseMapper.insertProductChangeEvent(Long.parseLong(siteDetails.get("instanceNumber").toString()), newValue);
			}
			InstallBaseProductBean ibProduct = installBaseMapper.getInstallBaseProduct(partitionId,	siteDetails.get("instanceNumber").toString());
			updateProductAfterLocationChange(userName, partitionId, ibProduct);

		} catch (IOException e) {
			log.error("Error inserting product change information for instance number: {} \n {}", siteDetails.get("instanceNumber").toString(), e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}
		
	}
	
	private String formatAddress(String address1, String address2, String city, String state, String province, String zip,String country) {		
		String stateProvinceZip = state == null  || state.isEmpty() ? Stream.of(province,zip).filter(s->s != null && !s.isEmpty()).collect(joining(" ")) :
			Stream.of(state,zip).filter(s->s != null && !s.isEmpty()).collect(joining(" "));
		
		return Stream
				.of(address1,address2,city,stateProvinceZip,country)
				.filter(s-> s != null && !s.isEmpty())
				.collect(joining(", "));
	}
	
	/**
	 * Updating locationUpdatedOn and locationUpdatedBy for a particular product in IB table
	 * after user submits edit site name/ location request
	 * @param userName
	 * @param partitionId
	 * @param ibProduct
	 */
	@SuppressWarnings("unchecked")
	private void updateProductAfterLocationChange(String userName, int partitionId, InstallBaseProductBean ibProduct) {
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> json;
		try {
			json = objectMapper.readValue(ibProduct.getData(), Map.class);
			json.put("locationUpdatedOn", new Date().getTime());
			json.put("locationUpdatedBy", userName);
			String newValue = objectMapper.writeValueAsString(json);
			installBaseMapper.updateInstallBaseProduct(ibProduct.getId(), partitionId, newValue);
			log.info("Updated location fields in the ib table for serialNumber: {}", json.get("serialNumber"));
		} catch (IOException e) {
			log.error("Error updatating locationUpdatedBy and locationUpdatedOn \n {} ", e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}
		
	}

	/**
	 * This method returns all the product change events such as contract renewal and site location change for a particular instance number
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getProductChangeEvent(Long instanceNumber) {
		
		ObjectMapper mapper = new ObjectMapper();
		ProductSiteChangeBean productChangeBean = installBaseMapper.getProductChangeEvent(instanceNumber);
		try {
			if (productChangeBean != null) {
				log.info("Returning product change event data for instance number: ", instanceNumber);
				return mapper.readValue(productChangeBean.getData(), Map.class);
			}
		} catch (IOException e) {
			log.error("Error parsing product change event object for instance number: {} \n {}", instanceNumber, e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		log.info("No product change event data found for instance number: ", instanceNumber);
		return null;
	}
	
	private String getRelationshipType(String uid,String siteId, String userIdentityType,String userName ){
		if (!userIdentityType.matches("E|V|T") ){
			//Temporary returning the relationship type as C because trident products don't have site id data yet
			if (siteId == null) {
				return "C";
			}
			String relationshipType = "C";//this.siteRelationService.getSiteRelationShip(siteId, userIdentityType,uid,userName);
			if(relationshipType.equalsIgnoreCase("PARTNER")) {
				relationshipType="P";
			}else {
				relationshipType="C";
			}
			return relationshipType;
		}
			
		return userIdentityType;
	}
	
	/**
	 * This method saves the uid, editProductAliasDate, productAliasEditedBy, newAliasName
	 * and userIdentityType in product_change_event table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = PersistenceException.class)
	public void insertAliasChangeEvent(Map<String, Object> aliasDetails, String uid, String userName, String newAliasName, String userIdentityType) {
		try {
			
			ObjectMapper mapper = new ObjectMapper();
			Long instanceNumber = Long.parseLong((String) aliasDetails.get("instanceNumber"));
			
			Map<String, Object> editProductAliasMap = new HashMap<>();
			editProductAliasMap.put("uid", uid);
			editProductAliasMap.put("updateDate", new Date().getTime());
			editProductAliasMap.put("userName", userName);
			editProductAliasMap.put("newAlias", newAliasName);
			editProductAliasMap.put("userIdentityType", userIdentityType);
			editProductAliasMap.put("relationshipType", getRelationshipType(uid, aliasDetails.get("siteNumber").toString(), userIdentityType,userName));
			ProductSiteChangeBean productChangeBean = installBaseMapper.getProductChangeEvent(instanceNumber);
			List<Map<String, Object>> listOfEditProductAlias = new ArrayList<>();
			//Update the existing edit product alias entry
			if (productChangeBean != null) {
				Map<String, Object> productChangeData = mapper.readValue(productChangeBean.getData(), Map.class);
				//Add a new entry in existing edit product alias list
				if(productChangeData.containsKey("aliasChange")) {
					listOfEditProductAlias = (List<Map<String, Object>>) productChangeData.get("aliasChange");
				}
				listOfEditProductAlias.add(editProductAliasMap);
				productChangeData.put("aliasChange", listOfEditProductAlias);
				String newValue = mapper.writeValueAsString(productChangeData);
				
				installBaseMapper.updateProductChangeEvent(instanceNumber, newValue);
			} 
			//Insert a fresh entry of edit product alias record for given instance number
			else {
				Map<String, List<Map<String, Object>>> productChangeDataMap = new HashMap<>();
				listOfEditProductAlias.add(editProductAliasMap);
				productChangeDataMap.put("aliasChange", listOfEditProductAlias);
				String newValue = mapper.writeValueAsString(productChangeDataMap);
				installBaseMapper.insertProductChangeEvent(instanceNumber, newValue);
			}
			
		} catch (IOException e) {
			log.error("Error inserting edit product alias data for instance number: {} \n {}", aliasDetails.get("instanceNumber"), e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}
	}
	
	/**
	 * This method saves the uid, editProductAliasDate, productAliasEditedBy, newAliasName
	 * and userIdentityType in product_change_event table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = PersistenceException.class)
	public void insertAliasChangeForESRS(Map<String, Object> aliasDetails, String uid, String userName, String userIdentityType) {
		
		try {
			
			ObjectMapper mapper = new ObjectMapper();
			String id = (String) aliasDetails.get("id");
			String newAliasName = (String) aliasDetails.get("alias");
			String newValue;
			Map<String, Object> filterParams = new HashMap<>();
			filterParams.put("deviceId", id);
			Map<String, EsrsBean> esrsBeanMap = getEsrsData(filterParams);
			EsrsBean esrsBean = null;
			
			List<EsrsChangeEventBean> esrsChangeEventBean = installBaseMapper.getEsrsChangeEvent(filterParams);
			
			Map<String, Object> esrsAliasMap = new HashMap<>();
			esrsAliasMap.put("uid", uid);
			esrsAliasMap.put("updatedOn", new Date().getTime());
			esrsAliasMap.put("updatedBy", userName);
			esrsAliasMap.put("alias", newAliasName);
			esrsAliasMap.put("relationshipType", getRelationshipType(uid, Objects.toString(aliasDetails.get("siteNumber"), null), userIdentityType,userName));
			esrsAliasMap.put("userIdentityType", userIdentityType);
			esrsAliasMap.put("action", (String) aliasDetails.get("action"));
			esrsAliasMap.put("clusterConnection", (Boolean) aliasDetails.get("isCluster"));
			esrsAliasMap.put("deviceId", id);
			
			List<Map<String, Object>> listOfEditEsrsAlias = new ArrayList<>();
			
			//Update the existing gateway/cluster alias entry
			if (null != esrsBeanMap && null != esrsBeanMap.get(id)) {
				esrsBean = esrsBeanMap.get(id);
				setEsrsAliasDetails(aliasDetails, uid, userName, newAliasName, userIdentityType, esrsBean);
				newValue = mapper.writeValueAsString(esrsBean);
				installBaseMapper.updateEsrsData(id, newValue);
			} 
			//Insert a fresh entry of edit gateway/cluster alias record for given gateway serial number/cluster id
			else {
				esrsBean = new EsrsBean();
				setEsrsAliasDetails(aliasDetails, uid, userName, newAliasName, userIdentityType, esrsBean);
				newValue = mapper.writeValueAsString(esrsBean);
				installBaseMapper.insertEsrsdata(id, newValue);
			}
			
			// updates, appends entries for alias change for esrs device
			if (!esrsChangeEventBean.isEmpty()) {
				Map<String, Object> esrsChangeData = mapper.readValue(esrsChangeEventBean.get(0).getData(),	new TypeReference<Map<String, Object>>() {});
				// Add a new entry in existing edit esrs alias list
				if (esrsChangeData.containsKey("aliasChange")) {
					listOfEditEsrsAlias = (List<Map<String, Object>>) esrsChangeData.get("aliasChange");
				}
				listOfEditEsrsAlias.add(esrsAliasMap);
				esrsChangeData.put("aliasChange", listOfEditEsrsAlias);
				String newEsrsChangeEventValue = mapper.writeValueAsString(esrsChangeData);
				installBaseMapper.updateEsrsChangeEvent(id, newEsrsChangeEventValue);
			} else {
				// create new esrs alias change event
				Map<String, List<Map<String, Object>>> esrsChangeDataMap = new HashMap<>();
				listOfEditEsrsAlias.add(esrsAliasMap);
				esrsChangeDataMap.put("aliasChange", listOfEditEsrsAlias);
				String newEsrsChangeEventValue = mapper.writeValueAsString(esrsChangeDataMap);
				installBaseMapper.insertEsrsChangeEvent(id, newEsrsChangeEventValue);
			}
				
		} catch (IOException e) {
			log.error("Error inserting edit product alias data for instance number: {} \n {}", aliasDetails.get("instanceNumber"), e.getMessage());
			throw new PersistenceException(e.getMessage(), e);
		}	
		
	}
	
	private void setEsrsAliasDetails(Map<String, Object> aliasDetails, String uid, String userName, String newAliasName,
			String userIdentityType, EsrsBean esrsBean) {
		//Update the entry with new alias and user details
		esrsBean.setUidForAlias(uid);
		esrsBean.setAliasLastUpdatedOn(new Date().getTime());
		esrsBean.setAliasLastUpdatedBy(userName);
		esrsBean.setAlias(newAliasName);
		esrsBean.setUserIdentityTypeForAlias(userIdentityType);
		esrsBean.setRelationshipTypeForAlias(getRelationshipType(uid, Objects.toString(aliasDetails.get("siteNumber"), null), userIdentityType,userName));
	}

	@Override
	public void getContractRenewal(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String,String> columns = new LinkedHashMap<String,String>();
		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));		
		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getContractRenewal(resultHandler, filterParams);
	}
	
	@Override
	public void getAliasChanges(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String,String> columns = new LinkedHashMap<String,String>();
		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));		
		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getAliasChanges(resultHandler, filterParams);
	}

	@Override
	public void getLocationChanges(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String,String> columns = new LinkedHashMap<String,String>();
		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));		
		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,Objects.toString(filterParams.get("timeZone"),"UTC"));
		filterParams.remove("size");
		installBaseMapper.getLocationChanges(resultHandler, filterParams);
	}

	@Override
	public Map<String, Object> getChangesAndSubmissionsStats(Map<String, Object> filterParams) {
		return installBaseMapper.getChangesAndSubmissionsStats(filterParams).stream().collect(
                Collectors.toMap(stats->stats.get("type").toString()
                    	,stats->stats.get("count")));
	}
	
	@Override
	public Map<String, EsrsBean> getEsrsData(Map<String, Object> filterParams) {
		String deviceId = filterParams.getOrDefault("deviceId", 0).toString();
		List<EsrsBean> esrsBeanList = installBaseMapper.getEsrsData(deviceId);
		Map<String, EsrsBean> esrsBeanMap = new HashMap<>();
		if (null != esrsBeanList && esrsBeanList.size() > 0) {
			esrsBeanList.forEach(esrsBean -> esrsBeanMap.put(esrsBean.getId(), esrsBean));
		}		
		return esrsBeanMap;
	}
	
	@Override
	public Map<Long, Integer> getMilestonesTimelineRangeEventCount(Map<String, Object> filterParams) {
		ProductBean product = getProductDetail(filterParams);
		Long millisencodsUTCOffset = Long.parseLong(filterParams.getOrDefault("timeZoneOffsetInSencods", "0").toString())*1000;
		Map<Long, Integer> eventCount = new HashMap<>();
		if (product != null) {
			String filterBy = filterParams.getOrDefault("filterBy", "All").toString();
			
			boolean isTimeRangeExist = false;
            if (filterParams.containsKey("tlvTimeRangeBefore") && filterParams.containsKey("tlvTimeRangeAfter")) {
                isTimeRangeExist = true;
            }

            LocalDate tlvTimeRangeBeforeDate = null;
            LocalDate tlvTimeRangeAfterDate = null;
            if (isTimeRangeExist) {
                Long tlvTimeRangeBefore = Long.parseLong(filterParams.get("tlvTimeRangeBefore").toString());
                Long tlvTimeRangeAfter = Long.parseLong(filterParams.get("tlvTimeRangeAfter").toString());
                tlvTimeRangeBeforeDate = Instant.ofEpochMilli(tlvTimeRangeBefore).atZone(ZoneId.systemDefault()).toLocalDate();
                tlvTimeRangeAfterDate = Instant.ofEpochMilli(tlvTimeRangeAfter).atZone(ZoneId.systemDefault()).toLocalDate();
            }
			
			if ((CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getEosl(),isTimeRangeExist))
					&& (filterBy.equals("All") || filterBy.contains("eossDate"))) {
				Long eossDateInMilli = CommonUtils.getOnlyDateMilli(product.getEops() + millisencodsUTCOffset);
				eventCount.put(eossDateInMilli, 1);
			}
			if ((CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getContractEndDate(),isTimeRangeExist))
					&& (filterBy.equals("All") || filterBy.contains("contractEndDate"))) {
				Long contractEndDateInMilli = CommonUtils.getOnlyDateMilli(product.getContractEndDate() + millisencodsUTCOffset);
				eventCount = addIfExist(eventCount, contractEndDateInMilli);
			}

			if ((CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getInstallDateLong(),isTimeRangeExist) )
					&& (filterBy.equals("All") || filterBy.contains("installDate"))) {
				Long installDateLongInMilli = CommonUtils.getOnlyDateMilli(product.getInstallDateLong() + millisencodsUTCOffset);
				eventCount = addIfExist(eventCount, installDateLongInMilli);

			}
			if ((CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getShipDate(),isTimeRangeExist))
					&& (filterBy.equals("All") || filterBy.contains("shipDate"))) {
				Long shipDateLongInMilli = CommonUtils.getOnlyDateMilli(product.getShipDate() + millisencodsUTCOffset);
				eventCount = addIfExist(eventCount, shipDateLongInMilli);
			}
			if ((CommonUtils.isDateInBetween(tlvTimeRangeBeforeDate, tlvTimeRangeAfterDate, product.getPurchaseDate(),isTimeRangeExist))
					&& (filterBy.equals("All") || filterBy.contains("purchaseDate"))) {
				Long purchaseDateLongInMilli = CommonUtils.getOnlyDateMilli(product.getPurchaseDate() + millisencodsUTCOffset);
				eventCount = addIfExist(eventCount, purchaseDateLongInMilli);
			}

		}
		return eventCount;
	}
	
	@Override
	public Map<Long, Integer> getChangesAndSubmissionTimelineRangeEventCount(Map<String, Object> filterParams) {
		String filterBy = filterParams.getOrDefault("filterBy", "All").toString();
		filterParams.put("filterBy", filterBy);
			return installBaseMapper.getChangesAndSubmissionTimelineRangeEventCount(filterParams).stream().collect(
	                Collectors.toMap(event->Double.valueOf(event.get("date").toString()).longValue()
	                    	,event->Integer.parseInt(event.get("count").toString())));
	}

	
	/**
	 * This method will take map as input and checkes if count is already exist for given key . It will increment by 1
	 * @param eventCount
	 * @param dateLonginMillisecondsKey
	 * @return
	 */
	private Map<Long, Integer> addIfExist(Map<Long, Integer> eventCount,Long dateLonginMillisecondsKey){
		if(eventCount.get(dateLonginMillisecondsKey) == null) {
			eventCount.put(dateLonginMillisecondsKey, 1);
			}
			else {
				eventCount.put(dateLonginMillisecondsKey, eventCount.get(dateLonginMillisecondsKey)+1);
			}
		
		return eventCount;
	}
	
	/**
	 * This method returns the connectivity change events such as nickname change for a particular cluster/gateway
	 * For a particular cluster, it also returns the change events for all the gateways within that cluster
	 */
	@Override
	public List<Map<String, Object>> getEsrsChangeEvent(Map<String, Object> filterParams) {
		List<Map<String, Object>> result = new ArrayList<>();
		String deviceId = filterParams.getOrDefault("deviceId", 0).toString();
		
		//If the gatewayDeviceIds field is present in the request params,
		//we will need to return change events for  all the gateway ids for that particular cluster
		if (filterParams.containsKey("gatewayDeviceIds")) {
			deviceId = deviceId.concat("|").concat(filterParams.get("gatewayDeviceIds").toString());
		}
		filterParams.put("deviceId", deviceId);
		ObjectMapper mapper = new ObjectMapper();
		List<EsrsChangeEventBean> esrsChangeEventBean = installBaseMapper.getEsrsChangeEvent(filterParams);
		esrsChangeEventBean.stream().forEach(data -> {
			try {
				result.add(mapper.readValue(data.getData(), new TypeReference<Map<String, Object>>() {}));
			} catch (IOException e) {
				log.error("Error parsing esrs change event object for deviceIds: {} \n {}", data.getId(), e.getMessage());
				throw new RuntimeException(e.getMessage());
			}
		});
		log.debug("Returning esrs change event data for deviceId: ", deviceId);
		return result;
	}

	@Override
	public Long getEsrsAliasChangeCount(Map<String, Object> filterParams) {
		log.info("Returning the alias change count for device id: {}", filterParams.get("deviceId").toString());
		String deviceId = filterParams.getOrDefault("deviceId", 0).toString();
		//If the gatewayDeviceIds field is present in the request params,
		//we will need to return alias change events count for  all the gateway ids for that particular cluster
		if (filterParams.containsKey("gatewayDeviceIds")) {
			deviceId = deviceId.concat("|").concat(filterParams.get("gatewayDeviceIds").toString());
		}
		filterParams.put("deviceId", deviceId);
		return installBaseMapper.getEsrsAliasChangeCount(filterParams);
	}
	
	@Override
	public void getEsrsChangeEvent(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		Map<String,String> columns = new LinkedHashMap<String,String>();
		String  timezone = Objects.toString(filterParams.get("timeZone"),"UTC");
		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));	
		StreamResultHandler resultHandler = new StreamResultHandler(out,columns,true,timezone);		
		filterParams.remove("size");
		
		String deviceId = filterParams.getOrDefault("deviceId", 0).toString();
		log.info("Returning the alias change time range stats for device id: {}", deviceId);
		//If the gatewayDeviceIds field is present in the request params,
		//we will need to return alias change events count for  all the gateway ids for that particular cluster
		if (filterParams.containsKey("gatewayDeviceIds")) {
			deviceId = deviceId.concat("|").concat(filterParams.get("gatewayDeviceIds").toString());
		}
		filterParams.put("deviceId", deviceId);
		installBaseMapper.getEsrsChangeEventForExport(resultHandler, filterParams);
	}

	@Override
	public Map<Long, Integer> getServiceEventsTimeRangeAliasChangeCount(Map<String, Object> filterParams) {
		String deviceId = filterParams.getOrDefault("deviceId", 0).toString();
		log.info("Returning the alias change time range stats for device id: {}", deviceId);
		//If the gatewayDeviceIds field is present in the request params,
		//we will need to return alias change events count for  all the gateway ids for that particular cluster
		if (filterParams.containsKey("gatewayDeviceIds")) {
			deviceId = deviceId.concat("|").concat(filterParams.get("gatewayDeviceIds").toString());
		}
		filterParams.put("deviceId", deviceId);
		return installBaseMapper.getServiceEventsTimeRangeAliasChangeCount(filterParams).stream()
				.collect(Collectors.toMap(e -> Double.valueOf(e.get("date").toString()).longValue(), e -> Integer.parseInt(e.get("count").toString())));
	}
	
	/**
	 * Get Site details for a UCID or | separated list of UCIDs
	 * Added for integration with Dell systems that rely on UCID
	 * S360 SiteNumber is not the same as UCID for older sites
	 */
	@Override
	public List<SiteBean> getSiteDetails(Map<String, Object> filterParams) {
		return installBaseMapper.getSiteDetails(filterParams);
	}
	
	/**
	 * Get the connect home status duration against the ProductFamily from stored records.
	 * <p>
	 * Check for existing entry, if not found create new with default values and send email notification.
	 * 
	 * @param productFamily
	 * @return
	 */
	public Long getConnectHomeStatusDuration(String productFamily){
		Long statusDaysLimit = null;
		ConnectHomeDurationBean connectHomeDuration = installBaseMapper.getConnectHomeDuration(productFamily);
		if (null == connectHomeDuration) {
			connectHomeDuration = new ConnectHomeDurationBean(productFamily, defaultConnectHomeStatusDuration, null, true);
			statusDaysLimit = defaultConnectHomeStatusDuration;
			sendConnectHomeDurationMail(productFamily);
			installBaseMapper.insertConnectHomeDuration(connectHomeDuration);
		} else {
			statusDaysLimit = connectHomeDuration.getDuration();
			Long currentMilliSec = System.currentTimeMillis();
			Long lastEmailSentMilliSec = connectHomeDuration.getLastEmailSent().getTime();
			if (connectHomeDuration.getSendEmail() && (currentMilliSec - lastEmailSentMilliSec) > sendEmailDuration) {
				sendConnectHomeDurationMail(productFamily);
				installBaseMapper.updateLastEmailSentDuration(productFamily);
			}
		}
		return statusDaysLimit;
	}
	
	private void sendConnectHomeDurationMail(String productFamily) {
		Map<String, Object> mailParams = new HashMap<>();
		mailParams.put("productFamily", productFamily);
		mailParams.put("environment", activeProfile);
		
		mailService.sendConnectHomeDurationMail(mailParams);
	}

	@Override
	public List<Map<String, Object>> getTridentConnectedDevices(Map<String, Object> filterParams) {
		return installBaseMapper.getTridentConnectedDevices(filterParams);
	}

	@Override
	public List<Map<String, Object>> getTridentConnectHomeEvents(Map<String, Object> filterParams) {
		return installBaseMapper.getTridentConnectHomeEvents(filterParams);
	}
	
	/**
	 * This method returns aggregate response for a particular gateway serial number or a cluster id for trident products
	 */
	@Override
	public EsrsDeviceGatewaysBean getTridentAggregateResponse(Map<String, Object> filterParams) {
		EsrsDeviceGatewaysBean response = installBaseMapper.getTridentAggregateResponse(filterParams);
		List<EsrsBean> esrsBeanList = installBaseMapper.getEsrsData(filterParams.get("deviceId").toString());
		if(!esrsBeanList.isEmpty()) {
			response.setAlias(esrsBeanList.get(0).getAlias());
		}
		if("true".equalsIgnoreCase(filterParams.getOrDefault("isClusterConnection", "false").toString())) {
			List<GatewayBean> gatewayDetails = installBaseMapper.getTridentGatewayDetails(filterParams);
			response.setGatewayDetails(gatewayDetails);
		}
		return response;
	}

	/**
	 * This method returns all the gateway serial numbers present within a particular cluster id
	 */
	@Override
	public String getGatewayIdsWithinACluster(Map<String, Object> filterParams) {
		return installBaseMapper.getGatewayIdsWithinACluster(filterParams);
	}

	/**
	 * This method returns the connectivity response for a particular install base serial number
	 */
	@Override
	public Map<String, Object> getTridentInstallBaseResponse(Map<String, Object> filterParams) {
		filterParams.put("connectHomeStatusDuration", tridentConnectHomeStatusDuration);
		List<Map<String, Object>> result = installBaseMapper.getTridentInstallBaseResponse(filterParams);
		Map<String, Object> esrsApiData = getGatewayData(filterParams);
		if (!result.isEmpty()) {
			return validateTridentIbConnectivityData(esrsApiData, result.get(0));
		}
		throw new ResourceNotFoundException();
	}

	private Map<String, Object> validateTridentIbConnectivityData(Map<String, Object> esrsApiData, Map<String, Object> tridentIbConnectivity
			) {
		if (null != esrsApiData && !esrsApiData.isEmpty()) {
			tridentIbConnectivity.putAll(esrsApiData);
		}
		return tridentIbConnectivity;
	}
	
	@SuppressWarnings("unchecked")
	private Map<String, Object> getGatewayData(Map<String, Object> filterParams) {
		log.info("GET: Gateway/Cluster data for trident product: {}", filterParams.get("serialNumberIsIn"));
		Map<String, Object> response = new HashMap<>();

		String serialNumber = (String) filterParams.get("serialNumberIsIn");
		String productType = "POWERSTORE";

		Map<String, Object> deviceData = esrsService.getDeviceDetails(serialNumber, productType, apiKey);
		response.put("deviceStatus", deviceData.get("remoteAccessStatus"));
		String lastContact = "";
		List<Map<String, Object>> gatewayDetailsList = (List<Map<String, Object>>) deviceData.get("gatewayDetailsList");
		Set<String> gatewayStatusList = new HashSet<>();

		for (Map<String, Object> map : gatewayDetailsList) {
			String gatewaySerialNumber = map.get("gatewaySerialNumber").toString();
			String gatewayModel = map.get("gatewayModel").toString();
			Map<String, Object> gatewayData = esrsService.getGatewayDetails(gatewaySerialNumber, gatewayModel, apiKey);
			
			// When there are more than one gatewaySerialNumbers the lastContact date is
			// checked and the latest record
			// is considered in populating gateway details.
			if (null != lastContact && !lastContact.isEmpty()) {
				ZonedDateTime dateTime1 = ZonedDateTime.parse(lastContact, lastContactFormat);
				ZonedDateTime dateTime2 = ZonedDateTime.parse(gatewayData.get("lastContact").toString(),
						lastContactFormat);
				if (dateTime2.isAfter(dateTime1)) {
					lastContact = gatewayData.get("lastContact").toString();
					response.put("serialNumber", serialNumber);
					response.put("lastConnectedGatewaySerial", gatewaySerialNumber);
					response.put("gatewayModelName", gatewayModel);
					response.put("esrsVersion", gatewayData.get("gatewayVersionNumber"));
					response.put(CLUSTER_ID, gatewayData.get("clusterGroupId"));
					response.put("lastContactDate", gatewayData.get("lastContact").toString());
					gatewayStatusList.add(gatewayData.get("gatewayStatus").toString());
					
				}
			} else {
				lastContact = gatewayData.get("lastContact").toString();
				response.put("serialNumber", serialNumber);
				response.put("lastConnectedGatewaySerial", gatewaySerialNumber);
				response.put("gatewayModelName", gatewayModel);
				response.put("esrsVersion", gatewayData.get("gatewayVersionNumber"));
				response.put(CLUSTER_ID, gatewayData.get("clusterGroupId"));
				response.put("lastContactDate", gatewayData.get("lastContact").toString());
			    gatewayStatusList.add(gatewayData.get("gatewayStatus").toString());
			}
		}
		//If the device has more than one gateway and these gateways have more than one status – 
		//then the gatewayDeviceStatusList 
		//can still have more than one value. example statuses Missing|Offline|Online
		
		response.put("gatewayDeviceStatusList",String.join("|", gatewayStatusList));
		
		if (response.get(CLUSTER_ID) != null) {
			Map<String, Object> clusterData = esrsService.getClusterDetails(response.get(CLUSTER_ID).toString(),
					apiKey);
			response.put("clusterGroupName", clusterData.get("clusterName").toString());
		}
		return response;
	}

	/**
	 * This method returns the connectivity response for multiple install base serial numbers
	 */
	@Override
	public List<Map<String, Object>> getTridentInstallBaseResponseMulti(Map<String, Object> filterParams) {
		filterParams.put("connectHomeStatusDuration", tridentConnectHomeStatusDuration);
		return installBaseMapper.getTridentInstallBaseResponse(filterParams);
	}
	
	@Override
	public WarrantyResponse getWarranties(String serialNumber) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		List<Entitlement> result = installBaseMapper.getWarranties(serialNumber);
		WarrantyResponse response = new WarrantyResponse();
		response.setProductId(serialNumber);
		for (Entitlement ent: result) {
			if (ent.getType() != null) {
				getServiceDescription(ent, ent.getType(), ent.getServiceDescription());
			}
			
			if ((ent.getContractId() == null || ent.getContractId().isEmpty()) && ent.getContractStartDate() == new Date(Long.MIN_VALUE)  &&  (ent.getType() == null | ent.getType().isEmpty())) {
				ent.setContractId(null);
			}
			
			if (ent.getStatus() != null) {
				setContractStatus(ent);
			}
			if (ent.getContractStartDate() != null) {
				ent.setStartDate(dateFormat.format(ent.getContractStartDate()));
			}
			if (ent.getContractEndDate() != null) {
				ent.setEndDate(dateFormat.format(ent.getContractEndDate()));
			}
		}
		
		if (result != null && !result.isEmpty()) {
			response.setEntitlementPresent(true);
		}
		response.setEntitlements(result);
		
		return response;
	}
	
	private void getServiceDescription(Entitlement ib, String servicePlanLevel, String servicePlanDescription) {
		List<String> proSupportPlusMissionCriticalList = Arrays.asList(proSupportPlusMissionCritical.split("\\|"));
		if (proSupportPlusMissionCriticalList.contains(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport Plus 4HR/Mission Critical");
		}else if ("B".equals(servicePlanLevel)) {
			ib.setServiceDescription("Basic Support");		
		}else if ("HSN".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L1 L2 L3  MON B/F PART-DEL RTF NBD");
		}else if ("HSI".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON PART-DEL RTF");
		}else if ("HSF".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON RTF");
		}else if ("HSD".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 PART-DEL RT");
		}else if ("HSS".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3");
		}else if ("HSH".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON PART-DEL RTF");
		}else if ("HSE".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON RTF");
		}else if ("HSC".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 PART-DEL RTF");
		}else if ("HSA".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 RTF");
		}else if ("HSO".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 B/F PART-DEL RTF 4HR");
		}else if ("HSP".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON B/F PART-DEL RTF 4HR");
		}else if ("PSM".equals(servicePlanLevel)) {
			ib.setServiceDescription("Post Std Support 4HR/Mission Critical");
		}else if ("PSN".equals(servicePlanLevel)) {
			ib.setServiceDescription("Post Std Support NBD");
		}else if ("L".equals(servicePlanLevel)) {
			ib.setServiceDescription("Limited Warranty");
		}else if ("NA".equals(servicePlanLevel)) {
			ib.setServiceDescription("Not Applicable");
		}else if ("999".equals(servicePlanLevel)) {
			ib.setServiceDescription("NPR");
		}else if ("RET".equals(servicePlanLevel)) {
			ib.setServiceDescription("Parts Retention");
		}else if ("P".equals(servicePlanLevel) || "EP".equals(servicePlanLevel) || "BP".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport 4HR/Mission Critical");
		}else if ("E".equals(servicePlanLevel) || "BE".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport NBD");
		}else if ("PS1".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport One");
		}else if ("PPN".equals(servicePlanLevel) || "BPN".equals(servicePlanLevel) || "EPN".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport Plus NBD");
		}else if ("SSC".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L1 L2  L3 SPPT");
		}else if ("SSF".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L1 L2 L3 SPPT RR");
		}else if ("SSB".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L2 L3 SPPT");
		}else if ("SSA".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L3 SPPT");
		}else if ("SSD".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L3 SPPT RR SLO");
		}else if ("HSR".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L1 L2 L3 MON B/F PART-DEL RTF 4HR");
		}else if ("HSB".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 RTF");
		}
		else if ("X".equals(servicePlanLevel)) {
			ib.setServiceDescription("Extended Support");
		}
		else if ("HSJ".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L1 L2 L3 MON PART-DEL RTF");
		}
		else if ("HSG".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L1 L2 L3 MON RTF");
		}
		else if ("HSQ".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON B/F PART-DEL RTF 4HR");
		}
		else if ("HSM".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON B/F PART-DEL RTF NBD");
		}
		else if ("HSV".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON PART-DEL RTF PSS");
		}
		else if ("HSW".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L2 L3 MON RTF PSS");
		}
		else if ("HSL".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON B/F PART-DEL RTF NBD");
		}
		else if ("HSX".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON PART-DEL RTF PSS");
		}
		else if ("HSY".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 MON RTF PSS");
		}
		else if ("HSZ".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 PART-DEL RTF PSS");
		}
		else if ("HTA".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3 RTF PSS");
		}
		else if ("HSK".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3, B/F PART-DEL RTF NBD");
		}
		else if ("HTB".equals(servicePlanLevel)) {
			ib.setServiceDescription("HW L3-PSS");
		}
		else if ("O1M".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L1, L2, L3, RTF, Monitoring");
		}
		else if ("O1A".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L1, L2, L3, RTF, Part Suppt, Mon");
		}
		else if ("O2R".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L2, L3, RTF");
		}
		else if ("O2M".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L2, L3, RTF, Monitoring");
		}
		else if ("O2P".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L2, L3, RTF, Part Suppt");
		}
		else if ("O2A".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L2, L3, RTF, Part Suppt, Mon");
		}
		else if ("O3R".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L3, RTF");
		}
		else if ("O3M".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L3, RTF, Monitoring");
		}
		else if ("O3P".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L3, RTF, Part Suppt");
		}
		else if ("O3A".equals(servicePlanLevel)) {
			ib.setServiceDescription("Onsite L3, RTF, Part Suppt, Monitoring");
		}
		else if ("HST".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote Connection L3 NBD Parts Support");
		}
		else if ("HSU".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote Connection L3 RTF");
		}
		else if ("R1".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote L1, L2, L3");
		}
		else if ("R2".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote L2, L3");
		}
		else if ("R3".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote L3");
		}
		else if ("R3M".equals(servicePlanLevel)) {
			ib.setServiceDescription("Remote L3, partner monitored");
		}
		else if ("SSE".equals(servicePlanLevel)) {
			ib.setServiceDescription("SW L2 L3 SPPT RR SLO");
		}
		else if ("ENH".equals(servicePlanLevel)) {
			ib.setServiceDescription("Enhanced");
		}
		else if ("KHD".equals(servicePlanLevel)) {
			ib.setServiceDescription("Keep Your Hard Drive");
		}
		else if ("KYC".equals(servicePlanLevel)) {
			ib.setServiceDescription("Keep Your Component");
		}
		else if ("P1N".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport One NBD");
		}
		else if ("U0".equals(servicePlanLevel)) {
			ib.setServiceDescription("VxFlex Ready Node");
		}
		else if ("VD".equals(servicePlanLevel)) {
			ib.setServiceDescription("Advanced Distributers Support");
		}
		else if("C8".equals(servicePlanLevel) || "P8".equals(servicePlanLevel) || "T2".equals(servicePlanLevel) || "T4".equals(servicePlanLevel)) {
			ib.setServiceDescription("ProSupport");
		}
		else {
			ib.setServiceDescription(servicePlanDescription);
		}
	}
	
	public void setContractStatus(Entitlement ent) {
		if(null == ent.getStatus()) {
			//product.setContractStatus("Entered");
		}
		else if("PENDING".equals(ent.getStatus().toUpperCase())) {
			ent.setStatus("Entered");
		}
		//Different DBs have different spellings for CANCELLED status
		else if("CANCELED".equals(ent.getStatus().toUpperCase()) || "CANCELLED".equals(ent.getStatus().toUpperCase())) {
			ent.setStatus(null);
		}
		else if("ACTIVE".equals(ent.getStatus().toUpperCase())
				&& null != ent.getContractTerminationDate()
				&& new Date().after(ent.getContractTerminationDate())){
			ent.setStatus("Terminated");
		}
		else if("ACTIVE".equals(ent.getStatus().toUpperCase())
				&& null != ent.getContractStartDate()
				&& new Date().after(ent.getContractStartDate())
				&& null != ent.getContractEndDate()
				&& new Date().after(ent.getContractEndDate())) {
					ent.setStatus("Expired");
		}
		else if("ACTIVE".equals(ent.getStatus().toUpperCase())
				&& null != ent.getContractStartDate()
				&& ent.getContractStartDate().after(new Date())) {
			ent.setStatus("Signed");
		}
		else {
			ent.setStatus("Active");
		}
	}

	@Override
	public void saveSingleSerializedAsset(List<Object> ssData){
		// String  cIBtable = this.getCurrentIBtable();
		// int cp = Integer.parseInt(cIBtable.substring(cIBtable.length() - 1));
		int cIbtable = getCurrentPartitionId();
		String currentIbtable = "dvs.ib_p"+ cIbtable;
		 this.insertOrUpdateBulkSData(currentIbtable, cIbtable, ssData);
		 this.insertOrUpdateBulkSData("dvs.asset_ss", cIbtable, ssData);
	}

	public void insertOrUpdateBulkSData(String tableName, int cPartition, List<Object> ssDatas) {
	    for (Object ssData : ssDatas) {
	        String jsonString = "";
	        int validInstanceNumber = 0;
	        try {
	            jsonString = objectMapper.writeValueAsString(ssData);
	            validInstanceNumber = instanceNumber(jsonString);
	        } catch (JsonProcessingException e) {
	            throw new RuntimeException(e);
	        }
	        // Check if the id exists in the table
	        boolean idExists = doesIdExist(tableName, validInstanceNumber);

	        if (idExists) {
	            // If the id exists, perform an UPDATE
				   jdbcTemplate.update(updateSql.replace("{tableName}", tableName), jsonString,validInstanceNumber);
	          
	        } else {
	            // If the id does not exist, perform an INSERT
				String finalJsonString = jsonString;
				int finalValidInstanceNumber = validInstanceNumber;
				jdbcTemplate.update(insertSql.replace("{tableName}",tableName),validInstanceNumber, cPartition, jsonString);
			}
	    }
	}
	 

	private boolean doesIdExist(String tableName, int id) {
		
		List<String> results = jdbcTemplate.query(idExistsSql.replace("{tableName}", tableName).replace("{id}", Integer.toString(id)),
				(resultSet, rowNum) -> resultSet.getString(1));

		if (!results.isEmpty()) {
			log.info("Id : "+results+" already exists ");
		    return true;
		} else {
			log.info("Id : "+results+" already does not exist ");
			return false;
		}
		
		
		}

	public int instanceNumber(String data) throws JsonProcessingException {
		try {
			JsonNode jsonNode = objectMapper.readTree(data);
			return jsonNode.get("instanceNumber").intValue();
		}catch (JsonProcessingException e){
			throw e;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void insertConnectHomeData(Map<String, Object> params) {
		installBaseMapper.insertConnectHomeData(params);		
	}

	@Override
	public void updateConnectHomeData(Map<String, Object> params) {
		installBaseMapper.updateConnectHomeData(params);		
	}

	@Override
	public void updateGatewayData(List<Map<String, Object>> params) {
		if(!params.isEmpty()) {
			int rows = installBaseMapper.deleteDeviceData(params.get(0));
			if (rows >= 0) {
				installBaseMapper.insertDeviceData(params);
			}
		}
	}

	@Override
	public void upsertEsrsDeviceStatus(Map<String, Object> deviceStatusDetails) {
		installBaseMapper.updateEsrsDeviceStatus(deviceStatusDetails);
	}

}
