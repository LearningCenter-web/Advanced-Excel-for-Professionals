package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class KpiBean {
	int pendingCount;
	int newCount;
	int reviewedCount;
	int workInProgressCount;
	int completeCount;	
	int remediatedCount;
	int notApplicableCount;
	int workAroundAppliedCount;
	
	
	
	
	
}
