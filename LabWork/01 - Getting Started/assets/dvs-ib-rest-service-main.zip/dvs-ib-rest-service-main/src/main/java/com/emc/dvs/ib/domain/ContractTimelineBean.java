package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class ContractTimelineBean {
	
	private String serialNumber;
	private String contractStatus;
	private String contractExpiresCategory;
	private Long contractStartDate;
	private Long contractEndDate;
	private String ibStatus;
	private boolean serialNumberProductPage;

}
