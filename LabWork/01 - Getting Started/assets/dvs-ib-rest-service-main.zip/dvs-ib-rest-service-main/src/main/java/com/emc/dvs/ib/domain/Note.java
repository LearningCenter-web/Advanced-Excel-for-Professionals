package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class Note {

	String userName;
	String email;
	String ntId;
	String advisoryNote;
	String role;
	String resolution;
	String articleId;
	String instanceId;
	String flag;
	String companyName;
	String productName;
	String productId;
	@ExportDate(value = "d MMM yyyy, hh:mm a")
	private Long timestamp;
}
