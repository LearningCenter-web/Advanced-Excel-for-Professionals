package com.emc.dvs.ib.fallback;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.emc.dvs.ib.service.HttpStreamService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class HttpStreamServiceFallbackImpl implements HttpStreamService {

	private Throwable cause;

	public HttpStreamServiceFallbackImpl(Throwable cause) {
		this.cause = cause;
	}

	@Override
	public void updateProductAlias(Map<String, Object> body) {
		log.info("HttpStreamService.updateProductAlias failed: {}", cause.getMessage());
		log.error("Error updating product alias in mongo for serial number: {} ", body.get("serialNumber"));
	}

	@Override
	public void siteChangeEvent(Map<String, Object> body) {
		log.info("HttpStreamService.siteChangeEvent failed: {}", cause.getMessage());
		log.error("Error updating site change event in mongo for serial number: {} ", body.get("serialNumber"));
	}

	@Override
	public void productChangeEvent(Map<String, Object> body) {
		log.info("HttpStreamService.productChangeEvent failed: {}", cause.getMessage());
		log.error("Error updating product change event in mongo for serial number: {} ", body.get("serialNumber"));
	}

	@Override
	public void renewContract(Map<String, Object> body) {
		log.info("HttpStreamService.renewContract failed: {}", cause.getMessage());
		log.error("Error updating contract renewal fields in mongo for serial number: {} ", body.get("serialNumber"));
	}

}
