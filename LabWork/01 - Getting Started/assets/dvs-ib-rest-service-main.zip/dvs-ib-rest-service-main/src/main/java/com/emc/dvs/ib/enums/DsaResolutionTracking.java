package com.emc.dvs.ib.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum DsaResolutionTracking {
	NOT_SCHEDULED("Not Scheduled"),
	SCHEDULED_FOR_ACTION("Scheduled For Action"),
	RESOLUTION_COMPLETED("Resolution Completed"),
	NOT_APPLICABLE("Not Applicable");
	
	private String resolution;
	
	 DsaResolutionTracking(String resolution){
		  this.resolution = resolution;
	}
	 
	public String getResoution() {
		return resolution;
	}
	
	  private static final Map<String, DsaResolutionTracking> lookup = new HashMap<>();
	  static {
	    for (DsaResolutionTracking resln : EnumSet.allOf(DsaResolutionTracking.class))
	      lookup.put(resln.getResoution(), resln);
	  }
	  
	  public static String get(String resolution) {
		    return lookup.get(resolution).toString();
		  }
	  
}
