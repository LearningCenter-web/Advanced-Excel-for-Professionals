package com.emc.dvs.ib.domain;

import lombok.Data;

/* 
 * "page" : { 
    "size" : 5,
    "totalElements" : 50,
    "totalPages" : 10,
    "number" : 0
  }
*/

@Data
public class Page {
	private int size;
	private int totalElements;
	private int totalPages;
	private int number;
	public Page(){}
	public Page(int size, int totalElements, int totalPages, int number){
		this.size = size;
		this.totalElements = totalElements;
		this.totalPages = totalPages;
		this.number = number;
	}
	
}

