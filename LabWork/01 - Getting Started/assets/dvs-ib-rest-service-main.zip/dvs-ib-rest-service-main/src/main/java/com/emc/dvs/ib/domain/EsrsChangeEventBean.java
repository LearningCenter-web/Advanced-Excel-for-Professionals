package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class EsrsChangeEventBean {
	private String id;
	private String data;
}
