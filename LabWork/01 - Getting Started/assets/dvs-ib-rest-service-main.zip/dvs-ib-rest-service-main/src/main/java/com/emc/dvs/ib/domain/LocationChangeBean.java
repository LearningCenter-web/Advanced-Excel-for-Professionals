package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class LocationChangeBean {
	@ExportDate(value="MMM d, yyyy HH:mm:ss")
	private Long requestDate;
	private String userName;
	private String updatedAddress;
	private String updatedSiteDisplayName;
	private String originalAddress;
	private String originalSiteDisplayName;

}
