package com.emc.dvs.ib.web;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emc.dvs.export.domain.ColumnWrapper;
import com.emc.dvs.ib.exception.BadRequestException;
import com.emc.dvs.ib.service.DvsAuditService;
import com.emc.dvs.ib.service.HttpStreamService;
import com.emc.dvs.ib.service.InstallBaseService;
import com.emc.dvs.ib.service.MailService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ProductChangeController {
	
	private InstallBaseService installBaseService;
	private MailService mailService;
	private HttpStreamService httpStreamService;
	private DvsAuditService dvsAuditService;
	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	@Qualifier(value = "sfdcRestTemplate")
	@Setter
	private OAuth2RestOperations sfdcRestTemplate;

	@Value("${serviceCloud.editProductAliasUrl}")
	@Setter
	private String editProductAliasUrl;
	
	@Autowired
	public ProductChangeController(InstallBaseService installBaseService, MailService emailClient, HttpStreamService httpStreamService, DvsAuditService dvsAuditService) {
		this.installBaseService = installBaseService;
		this.mailService = emailClient;
		this.httpStreamService = httpStreamService;
		this.dvsAuditService = dvsAuditService;
	}
	
	/**
	 * This API returns all the product change events such as contract renewal and site location change for a particular instance number
	 * @param request
	 * @param instanceNumber
	 * @return
	 */
	@RequestMapping(value = "/productchangeevent/{instanceNumber}", method = RequestMethod.GET)
	public Map<String, Object> getProductChangeEvent(HttpServletRequest request, @PathVariable("instanceNumber") Long instanceNumber) {
		log.debug("GET: Product change event data for instance number: ", instanceNumber);
		return installBaseService.getProductChangeEvent(instanceNumber);
	}
	
	/**
	 * This method sends the contract renewal mail and tracks the contract
	 * renewal submission data
	 * 
	 * @param contractBean
	 * @param request
	 * @throws UnsupportedOperationException
	 */
	@RequestMapping(value = "/renewcontract", method = RequestMethod.POST)
	public void insertContractRenewalRecord(@RequestBody Map<String, Object> contractDetails, HttpServletRequest request) {
		
		UserBean userBean = (UserBean) request.getAttribute("USER_BEAN");
		if(userBean == null) {
			if(!(contractDetails.containsKey("identityType") && contractDetails.containsKey("uid") && contractDetails.containsKey("flname")))
			{
				log.error("Throwing bad request exception due to UserBean details are not set in the request body ContractDetails");
				throw new BadRequestException("UserBean details are not set in the request body ContractDetails");
			}
			userBean = new UserBean();
			userBean.setIdentityType((String)contractDetails.get("identityType"));
			userBean.setUid((String)contractDetails.get("uid"));
			userBean.setFlname((String) contractDetails.get("flname"));
			contractDetails.remove("identityType");
			contractDetails.remove("uid");
			contractDetails.remove("flname");
		}
		
		String identity = userBean.getIdentityType();
		if (identity.matches("E|V|T")) {
			throw new UnsupportedOperationException(
					"Error while submitting the contact sales form as this operation is not supported for Employee user types");
		}
		
		mailService.sendContractRenewalMail(contractDetails);
		log.info("Saving contract renewal details for product serial number: {} for uid: {} ", contractDetails.get("serialNumber"), userBean.getUid());
		Map<String, Object> response = installBaseService.insertContractRenewalRecord(contractDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		response.put("serialNumber", contractDetails.get("serialNumber"));
		
		//Update the mongo asset collection
		httpStreamService.renewContract(response);
		
		dvsAuditService.insertAuditRecord(contractDetails);
		log.info("Inserted audit record for co for serial number: {}", contractDetails.get("serialNumber"));
	}
	
	/**
	 * This method updates the product alias. It calls the SFDC SOQL API which
	 * updates product alias field
	 * 
	 * @param productAlias
	 * @param serialNumber
	 * @param assetId
	 * @return
	 */
	@SneakyThrows
	@RequestMapping(value = "/productalias/{serialNumber}", method = RequestMethod.POST)
	public void editProductAlias(HttpServletRequest request, @RequestBody Map<String, Object> requestMap, @PathVariable String serialNumber) {
		log.info("updating product alias {} for serial number {}", requestMap, serialNumber);
		
		String newAliasName = (String) requestMap.get("Product_Alias__C");
		if(requestMap.containsKey("convergedInfrastructure") && !(Boolean) requestMap.get("convergedInfrastructure")) {
			UserBean userBean = (UserBean) request.getAttribute("USER_BEAN");
		
			//Update the alias in SFDC
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
			Map<String, String> sfdcBody = new HashMap<>();
			sfdcBody.put("Product_Alias__C", newAliasName);
			HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(sfdcBody, headers);
			String baseUrl = (String) sfdcRestTemplate
					.getAccessToken()
					.getAdditionalInformation().get("instance_url");
			sfdcRestTemplate.exchange(baseUrl.concat(editProductAliasUrl), HttpMethod.PATCH, requestEntity, Object.class, requestMap.get("assetId"));
			
			//Insert/ Update records in product_change_event table after saving the alias
			installBaseService.insertAliasChangeEvent(requestMap, userBean.getUid(), userBean.getFlname(), newAliasName, userBean.getIdentityType());

			// Notify dvs-stream of the change to update the DVS Schema
			Map<String, Object> requestBody = new HashMap<>();
			requestBody.put("productAlias", newAliasName);
			requestBody.put("instanceNumber", requestMap.get("instanceNumber"));
			requestBody.put("instanceId", requestMap.get("instanceId"));
			requestBody.put("serialNumber", serialNumber); 
			httpStreamService.updateProductAlias(requestBody);
		}
	}
	
	
	/**
	 * This method sends an email for updating the site/ location address
	 * @param locationAttr
	 * @param request
	 */
	@RequestMapping(value = "/sitelocation", method = RequestMethod.POST, consumes = "application/json")
	public void updateSiteLocation(HttpServletRequest request, @RequestBody Map<String, Object> siteDetails) {

		if(siteDetails.get("siteAddressChanged").toString().equals("false") && siteDetails.get("productLocationChanged").toString().equals("false")) {
			log.error("Throwing bad request exception due to original and updated fields being the same");
			throw new BadRequestException("Error updating site location due to incorrect request parameters");
		}
		UserBean userBean = (UserBean) request.getAttribute("USER_BEAN");
		if(userBean == null) {
			if(!(siteDetails.containsKey("identityType") && siteDetails.containsKey("uid") && siteDetails.containsKey("flname")))
			{
				log.error("Throwing bad request exception due to UserBean details are not set in the request body siteDetails");
				throw new BadRequestException("UserBean details are not set in the request body siteDetails");
			}
			userBean = new UserBean();
			userBean.setIdentityType((String)siteDetails.get("identityType"));
			userBean.setUid((String)siteDetails.get("uid"));
			userBean.setFlname((String) siteDetails.get("flname"));
			userBean.setPhoneNumber((String) siteDetails.get("phoneNumber"));
			userBean.setEmail((String) siteDetails.get("email"));
			siteDetails.remove("identityType");
			siteDetails.remove("uid");
			siteDetails.remove("flname");
			siteDetails.remove("phoneNumber");
			siteDetails.remove("email");
		}
		
		//Adding user details in siteDetails map for auditing
		siteDetails.put("name", userBean.getFlname());
		siteDetails.put("designation", getUserIdentityTypeValue(userBean.getIdentityType()));
		siteDetails.put("phone", userBean.getPhoneNumber());
		siteDetails.put("email",userBean.getEmail());

		mailService.sendUpdateSiteLocationMail(siteDetails);
		log.info("Sent an email for updating site name/ location for serial number: {}", siteDetails.get("serialNumber"));
		
		if(siteDetails.get("siteAddressChanged").toString().equals("true")) {
			installBaseService.insertSiteChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
			log.info("Inserted records in site change event table for serial number {}: ", siteDetails.get("serialNumber"));
			Map<String,Object> body = new HashMap<>();
			body.put("siteId", siteDetails.get("originalSiteNumber"));
			body.put("userName", userBean.getFlname());
			httpStreamService.siteChangeEvent(body);
			log.info("Updated locationUpdatedOn and locationUpdatedBy data for all the products with site number: {}", siteDetails.get("originalSiteNumber"));
		}
		
		if(siteDetails.get("productLocationChanged").toString().equals("true")) {
			installBaseService.insertProductChangeEvent(siteDetails, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
			Map<String,Object> body = new HashMap<>();
			body.put("serialNumber", siteDetails.get("serialNumber"));
			body.put("userName", userBean.getFlname());
			httpStreamService.productChangeEvent(body);
			log.info("Inserted records in product change event table for serial number {}: ", siteDetails.get("serialNumber"));
		}
		
		dvsAuditService.insertAuditRecord(siteDetails);
		log.info("Inserted audit record for Site Name/ Location update for serial number: {}", siteDetails.get("serialNumber"));
	}
	
	/**
	 * Export as CSV for contract renewal data
	 * @param instanceNumber
	 * @param filterParams
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/contractrenewal/{instanceNumber}" }, method = { RequestMethod.GET,RequestMethod.POST }, produces = "text/csv")
	public void downloadContractRenewal(@PathVariable("instanceNumber") Long instanceNumber,@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);
		
		response.addHeader("Content-disposition", "attachment;filename=ContractRenewal_Export.csv");
		response.setContentType("txt/csv");
		filterParams.put("instanceNumber", instanceNumber);
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getContractRenewal(out, filterParams, colWrapper.getColumns());
		}
	}
	
	/**
	 * Export as CSV for Product Alias Change data
	 * @param instanceNumber
	 * @param filterParams
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/aliaschange/{instanceNumber}" }, method = { RequestMethod.GET,RequestMethod.POST }, produces = "text/csv")
	public void downloadAliasChangeData(@PathVariable("instanceNumber") Long instanceNumber,@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);
		
		response.addHeader("Content-disposition", "attachment;filename=AliasChange_Export.csv");
		response.setContentType("txt/csv");
		filterParams.put("instanceNumber", instanceNumber);
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getAliasChanges(out, filterParams, colWrapper.getColumns());
		}
	}
	
	/**
	 * Export CVS as Location Change Data
	 * @param instanceNumber
	 * @param filterParams
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/locationchange/{instanceNumber}" }, method = { RequestMethod.GET,RequestMethod.POST }, produces = "text/csv")
	public void downloadLocationChangeData(@PathVariable("instanceNumber") Long instanceNumber,@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);
		
		response.addHeader("Content-disposition", "attachment;filename=LocationChange_Export.csv");
		response.setContentType("txt/csv");
		filterParams.put("instanceNumber", instanceNumber);
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getLocationChanges(out, filterParams, colWrapper.getColumns());
		}
	}
	
	/**
	 * This method returns the count of changes&Submission filters count
	 * 
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = "/changesandsubmissionsstats", method = {RequestMethod.GET, RequestMethod.POST})
	public Map<String, Object> getChangesAndSubmissionsStats(@RequestParam Map<String, Object> filterParams) {
		return installBaseService.getChangesAndSubmissionsStats(filterParams);
	}
	/**
	 * This api will return date wise count of events
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value={"/changesAndSubmission/timeline/timerange"}, method=RequestMethod.POST)
	public Map<Long, Integer> getChangesAndSubmissionTimelineRangeEventCount(@RequestParam Map<String, Object> filterParams) {
		return installBaseService.getChangesAndSubmissionTimelineRangeEventCount(filterParams);
	}
	
	private String getUserIdentityTypeValue(String identityType) {
		String identityTypeValue = null;
		switch (identityType) {
		case "E":
			identityTypeValue = "Employee";
			break;
		case "C":
			identityTypeValue = "Customer";
			break;
		case "P":
			identityTypeValue = "Partner";
			break;
		case "P,C":
			identityTypeValue = "Partner,Customer";
			break;
		case "C,P":
			identityTypeValue = "Customer,Partner";
			break;
		case "V":
			identityTypeValue = "Vendor";
			break;	
		case "T":
			identityTypeValue = "Temp";
			break;	
		}
		return identityTypeValue;
	}

}
