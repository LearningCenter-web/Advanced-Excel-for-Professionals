package com.emc.dvs.ib.service;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestTemplate;

import com.emc.dvs.export.StreamResultHandler;
import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.InstanceSiteMap;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.KpiBean;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.SerializedAdvisoryEvent;
import com.emc.dvs.ib.domain.SerializedProductBean;
import com.emc.dvs.ib.domain.SerializedResponseBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.enums.DsaResolutionTracking;
import com.emc.dvs.ib.enums.EtaResolutionTracking;
import com.emc.dvs.ib.persistance.AdvisoriesMapper;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

/**
 * DSA = ESA (DELL Security advisory = EMC Security Advisory
 * 
 * @author riords1
 *
 */
@Slf4j
@Service("AdvisoriesService")
@CacheConfig(cacheNames = { "adv" })
@EnableAsync
public class AdvisoriesServiceImpl implements AdvisoriesService {
	private static final String CORP_CS_THEATER = "Corp CS Theater";
	private static final String APJK_CS_THEATER = "APJK CS Theater";
	private static final String EMEA_CS_THEATER = "EMEA CS Theater";
	private static final String AMERICAS_CS_THEATER = "Americas CS Theater";
	private static final String REVIEWED = "Reviewed";
	private static final String NOT_APPLICABLE = "Not Applicable";
	private static final String REMEDIATED = "Remediated";
	private static final String NEW = "New";
	private static final String WORK_IN_PROGRESS = "Work In Progress";
	private static final String WORK_AROUND_APPLIED = "Workaround Applied";
	private static final String MARK_AS_REVIEWED = "MARK_AS_REVIEWED";
	private static final String NOT_APPLICABLE_EVENT = "NOT_APPLICABLE";
	private static final String TIMEZONE = "timeZone";
	private static final String UTC = "UTC";
	
	private static final String FILTER_NEW = "new";
	private static final String FILTER_WORK_IN_PROGRESS = "workInProgress";
	private static final String FILTER_WORKAROUND_APPLIED = "workaroundApplied";
	private static final String FILTER_REVIEWED = "reviewed";
	private static final String FILTER_NOT_APPLICABLE = "notApplicable";
	private static final String FILTER_REMEDIATED = "remediated";
	
	private static final String CRITICAL = "Critical";
	private static final String HIGH = "High";
	private static final String MEDIUM = "Medium";
	private static final String LOW = "Low";
	
	private final AdvisoriesMapper advisoriesMapper;
	private final JdbcTemplate jdbcTemplate;
	
	private final ObjectMapper objectMapper;
	
	
	@Value("${advisories.subscription.url}")
	private String subscriptionUrl;
	
	@Value("${advisories.audit.dsa.sql}")
	private String esaSql;

	@Value("${advisories.audit.dta.sql}")
	private String etaSql;
	
	@Value("${advisories.audit.dsa.refreshViewSql}")
	private String refreshDsaViewSql;
	
	@Value("${advisories.audit.dta.refreshViewSql}")
	private String refreshDtaViewSql;

	@Value("${advisories.notes.dsa.sql}")
	private String esaNoteSql;

	@Value("${advisories.notes.dta.sql}")
	private String etaNoteSql;
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired JdbcTemplate template1;
	
	@Autowired
	private SubscriptionDetailsService subscriptionDetailsService;
	

	@Autowired
	public AdvisoriesServiceImpl(AdvisoriesMapper advisoriesMapper, JdbcTemplate jdbcTemplate,
			ObjectMapper objectMapper, SubscriptionDetailsService subscriptionDetailsService) {
		this.advisoriesMapper = advisoriesMapper;
		this.jdbcTemplate = jdbcTemplate;
		this.objectMapper = objectMapper;
		this.subscriptionDetailsService = subscriptionDetailsService;
	}

	@Override
	@Async
	public Future<List<AdvisoryBean>> getEsaAggregate(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEsaAggregate(filterParams));
	}

	@Override
	public void markDsaAsReviewed(Map<String, Object> filterParams, UserBean user) {

		final List<Map<String, Object>> esaInstanceMaps = advisoriesMapper.getEsaInstanceMap(filterParams);
		insertAuditRecord(esaInstanceMaps, user, MARK_AS_REVIEWED);

	}
	
	@Async
	public void refreshView(String view) {
		log.info("------------------------In refreshView-----------------------{}");
		jdbcTemplate.execute(view);
		log.info("------------------------refreshView done-----------------------{}");
	} 
	
	@Override
	@Async
	public Future<Integer> getEsaEventsCount(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEsaEventsCount(filterParams));
	}
	
	@Override
	@Async
	public Future<Integer> getEtaEventsCount(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEtaEventsCount(filterParams));
	}

	@Override
	@Async
	public Future<Integer> getEsaTotalRecord(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEsaAggregateTotalRecord(filterParams));
	}

	@Override
	public void markDsaAsDisregarded(Map<String, Object> filterParams, UserBean user) {

		final List<Map<String, Object>> esaInstanceMaps = advisoriesMapper.getEsaInstanceMap(filterParams);
		insertAuditRecord(esaInstanceMaps, user, MARK_AS_REVIEWED);
		insertAuditRecord(esaInstanceMaps, user, NOT_APPLICABLE_EVENT);

	}

	protected void insertAuditRecord(List<Map<String, Object>> esaInstanceMaps, UserBean user, String event) {

		jdbcTemplate.batchUpdate(esaSql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				esaInstanceMaps.get(i).put("event", event);
				esaInstanceMaps.get(i).put("timestamp", System.currentTimeMillis());
				esaInstanceMaps.get(i).put("uid", user.getUid());
				esaInstanceMaps.get(i).put("userName", user.getFlname());
				esaInstanceMaps.get(i).put("email", user.getEmail());
				esaInstanceMaps.get(i).put("identityType", user.getIdentityType());
				try {
					ps.setObject(1, objectMapper.writeValueAsString(esaInstanceMaps.get(i)));
				} catch (final Exception e) {
					log.error("Error while add notes for userEmail : "+user.getEmail()+" event : "+event+"\n"+e.getMessage());
				}
			}

			@Override
			public int getBatchSize() {
				log.info("No of entries into esa_event : "+esaInstanceMaps.size());
				return esaInstanceMaps.size();
			}
		});

	}

	@Override
	public void getEsaAggregate(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		final Map<String, String> columns = new LinkedHashMap<>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));
		final StreamResultHandler resultHandler = new StreamResultHandler(out, columns, true,
				Objects.toString(filterParams.get(TIMEZONE), UTC));
		this.advisoriesMapper.getEsaAggregate(resultHandler, filterParams);

	}

	@Override
	@Async
	public Future<List<AffectedProductsBean>> getAffectedProducts(Map<String, Object> filterParams, String advisoryType) {
		List<AffectedProductsBean> affectedProducts = new ArrayList<>();
		
		if (advisoryType.equalsIgnoreCase("ESA")) {
			affectedProducts = advisoriesMapper.getAffectedProducts(filterParams);
		} else if (advisoryType.equalsIgnoreCase("ETA")) {
			affectedProducts = advisoriesMapper.getEtaAffectedProducts(filterParams);
		}
		return new AsyncResult<List<AffectedProductsBean>>(affectedProducts);
	}

	@Override
	public void updateResolutionTracking(Map<String, Object> filterParams, UserBean user, String resolution) {
		final List<Map<String, Object>> esaInstanceMaps = advisoriesMapper.getEsaInstanceMap(filterParams);
		log.info("esaInstanceMaps size : "+esaInstanceMaps.size());		
		if ("true".equalsIgnoreCase((String) filterParams.get("isSerialized"))) {
			try {
				final ObjectMapper mapper = new ObjectMapper();
				final List<InstanceSiteMap> instanceSiteRoleMap = mapper.readValue((String) filterParams.get("instanceSiteMap"),
						new TypeReference<List<InstanceSiteMap>>() {
						});
				final String role = instanceSiteRoleMap.stream().map(InstanceSiteMap::getRole)
						.collect(Collectors.joining(","));
				user.setEmail((String) filterParams.get("email"));
				user.setFlname((String) filterParams.get("userName"));
				if ("PARTNER".equalsIgnoreCase(role)) {
					user.setIdentityType("P");
				} else if ("EMPLOYEE".equalsIgnoreCase(role)) {
					user.setIdentityType("E");
				} else {
					user.setIdentityType(role);
				}
				int esaMarkAsReviewdCount = advisoriesMapper.getEsaMarkAsReviewedCount(filterParams);
				if (esaMarkAsReviewdCount == 0) {
					markDsaAsReviewed(filterParams, user);
				}
			} catch (Exception e) {
				log.error("Error while add notes for userEmail : "+user.getEmail()+"\n"+e.getMessage());
			}
		}
		insertAuditRecord(esaInstanceMaps, user, DsaResolutionTracking.get(resolution));

	}

	@Override
	public void getAffectedProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		final Map<String, String> columns = new LinkedHashMap<>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));
		final StreamResultHandler resultHandler = new StreamResultHandler(out, columns, true,
				Objects.toString(filterParams.get(TIMEZONE), UTC));
		this.advisoriesMapper.getAffectedProducts(resultHandler, filterParams);

	}

	@Override
	public KpiBean getRemediationStatus(Map<String, Object> filterParams) {
		final List<AdvisoryBean> aggList = advisoriesMapper.getEsaAggregate(filterParams);
		return getKpiCount(aggList);
	}

	@Override
	public List<AffectedProductsKpi> getAffectedProductsForKpi(Map<String, Object> filterParams) {
		final List<AdvisoryBean> aggList = advisoriesMapper.getArticles(filterParams);
		filterParams.put("articleNumbers",
				aggList.stream().map(AdvisoryBean::getArticleNumber).collect(Collectors.joining("|")));
		return advisoriesMapper.getAffectedProductsForKpi(filterParams);
	}

	@Override
	public Future<List<AdvisoryBean>> getEtaAggregate(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEtaAggregate(filterParams));
	}

	@Override
	@Async
	public Future<Integer> getEtaTotalRecord(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getEtaAggregateTotalRecord(filterParams));
	}

	@Override
	public void markDtaAsReviewed(Map<String, Object> filterParams, UserBean user) {
		final List<Map<String, Object>> etaInstanceMaps = advisoriesMapper.getEtaInstanceMap(filterParams);
		insertDtaAuditRecord(etaInstanceMaps, user, MARK_AS_REVIEWED);
		//refreshView(refreshDtaViewSql);
	}

	@Override
	public void markDtaAsNotApplicable(Map<String, Object> filterParams, UserBean user) {
		final List<Map<String, Object>> etaInstanceMaps = advisoriesMapper.getEtaInstanceMap(filterParams);
		insertDtaAuditRecord(etaInstanceMaps, user, MARK_AS_REVIEWED);
		insertDtaAuditRecord(etaInstanceMaps, user, NOT_APPLICABLE_EVENT);
		//refreshView(refreshDtaViewSql);

	}

	protected void insertDtaAuditRecord(List<Map<String, Object>> etaInstanceMaps, UserBean user, String event) {

		jdbcTemplate.batchUpdate(etaSql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				etaInstanceMaps.get(i).put("event", event);
				etaInstanceMaps.get(i).put("timestamp", System.currentTimeMillis());
				etaInstanceMaps.get(i).put("uid", user.getUid());
				etaInstanceMaps.get(i).put("userName", user.getFlname());
				etaInstanceMaps.get(i).put("email", user.getEmail());
				etaInstanceMaps.get(i).put("identityType", user.getIdentityType());
				try {
					ps.setObject(1, objectMapper.writeValueAsString(etaInstanceMaps.get(i)));
				} catch (final Exception e) {
					log.error("Error while add notes for userEmail : "+user.getEmail()+"\n"+e.getMessage());
				}
			}

			@Override
			public int getBatchSize() {
				log.info("No of entries into eta_event : "+etaInstanceMaps.size());	
				return etaInstanceMaps.size();
			}
		});
	}

	@Override
	public void getEtaAggregate(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		final Map<String, String> columns = new LinkedHashMap<>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));
		final StreamResultHandler resultHandler = new StreamResultHandler(out, columns, true,
				Objects.toString(filterParams.get(TIMEZONE), UTC));
		this.advisoriesMapper.getEtaAggregate(resultHandler, filterParams);

	}

	@Override
	@Async
	public Future<List<AffectedProductsBean>> getEtaAffectedProducts(Map<String, Object> filterParams) {
		final List<AffectedProductsBean> affectedProducts = advisoriesMapper.getEtaAffectedProducts(filterParams);
		return new AsyncResult<List<AffectedProductsBean>>(affectedProducts);	
	}

	@Override
	public void getEtaAffectedProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols) {
		final Map<String, String> columns = new LinkedHashMap<>();

		cols.forEach(col -> columns.put(col.getTitle(), col.getField()));
		final StreamResultHandler resultHandler = new StreamResultHandler(out, columns, true,
				Objects.toString(filterParams.get(TIMEZONE), UTC));
		this.advisoriesMapper.getEtaAffectedProducts(resultHandler, filterParams);

	}

	@Override
	public void updateEtaResolutionTracking(Map<String, Object> filterParams, UserBean user, String resolution) {
		final List<Map<String, Object>> etaInstanceMaps = advisoriesMapper.getEtaInstanceMap(filterParams);
		log.info("esaInstanceMaps size : "+etaInstanceMaps.size());	
		if ("true".equalsIgnoreCase((String) filterParams.get("isSerialized"))) {
			try {
				final ObjectMapper mapper = new ObjectMapper();
				final List<InstanceSiteMap> instanceSiteRoleMap = mapper.readValue((String) filterParams.get("instanceSiteMap"),
						new TypeReference<List<InstanceSiteMap>>() {
						});
				final String role = instanceSiteRoleMap.stream().map(InstanceSiteMap::getRole)
						.collect(Collectors.joining(","));
				user.setEmail((String) filterParams.get("email"));
				user.setFlname((String) filterParams.get("userName"));
				if ("PARTNER".equalsIgnoreCase(role)) {
					user.setIdentityType("P");
				} else if ("EMPLOYEE".equalsIgnoreCase(role)) {
					user.setIdentityType("E");
				} else {
					user.setIdentityType(role);
				}
				int etaMarkAsReviewdCount = advisoriesMapper.getEtaMarkAsReviewedCount(filterParams);
				if (etaMarkAsReviewdCount == 0) {
					markDtaAsReviewed(filterParams, user);
				}
			} catch (Exception e) {
				log.error("Error while add notes for userEmail : "+user.getEmail()+"\n"+e.getMessage());
			}
		}
		insertDtaAuditRecord(etaInstanceMaps, user, EtaResolutionTracking.get(resolution));
		//refreshView(refreshDtaViewSql);

	}
	
	@Override
	public List<TimelineEntity> getEsaTimelineData(Map<String, Object> filterParams) {
		List<TimelineEntity> timelineEntities = new ArrayList<>();	
		Map<String, Object> productBeanMap = advisoriesMapper.getIbInstanceMap(filterParams);
		filterParams.put("tagId", (String)productBeanMap.get("t3id"));
		filterParams.put("instanceNumber", (String)productBeanMap.get("instancenumber"));
		List<AdvisoryBean> esaAggregate = advisoriesMapper.getEsaTimeline(filterParams);
		ObjectMapper mapper = new ObjectMapper();
		if (null != esaAggregate) {
			esaAggregate.stream().forEach(esa -> {
				TimelineEntity esaEntity = new TimelineEntity();
				esaEntity.setEntityType("ESA");
				esaEntity.setTimeStamp(esa.getLastUpdatedDate());
				esaEntity.setEntity(mapper.convertValue(esa, Map.class));
				timelineEntities.add(esaEntity);
			});
		}
		return timelineEntities;
	}
	
	@Override
	public List<TimelineEntity> getEtaTimelineData(Map<String, Object> filterParams) {
		List<TimelineEntity> timelineEntities = new ArrayList<>();		
		Map<String, Object> productBeanMap = advisoriesMapper.getIbInstanceMap(filterParams);
		filterParams.put("tagId", (String)productBeanMap.get("t3id"));
		filterParams.put("instanceNumber", (String)productBeanMap.get("instancenumber"));
		List<AdvisoryBean> etaAggregate = advisoriesMapper.getEtaTimeline(filterParams);
		ObjectMapper mapper = new ObjectMapper();
		if (null != etaAggregate) {
			etaAggregate.stream().forEach(eta -> {
				TimelineEntity etaEntity = new TimelineEntity();
				etaEntity.setEntityType("ETA");
				etaEntity.setTimeStamp(eta.getLastUpdatedDate());
				etaEntity.setEntity(mapper.convertValue(eta, Map.class));
				timelineEntities.add(etaEntity);
			});
		}
		return timelineEntities;
	}

	@Override
	public KpiBean getEtaRemediationStatusCount(Map<String, Object> filterParams) {
		final List<AdvisoryBean> aggList = advisoriesMapper.getEtaAggregate(filterParams);
		return getKpiCount(aggList);
	}

	private KpiBean getKpiCount(List<AdvisoryBean> aggList) {
		final KpiBean kpiBean = new KpiBean();
		int pendingCount = 0;
		int workInProgressCount = 0;
		int newCount = 0;
		int reviewedCount = 0;
		int notApplicableCount = 0;
		int remediatedCount = 0;
		int completeCount = 0;
		for (final AdvisoryBean adv : aggList) {
			if (adv.isUpdated()) {
				newCount++;
			} else {
				switch (adv.getStatus()) {
				case WORK_IN_PROGRESS:
					workInProgressCount++;
					break;
				case NEW:
					newCount++;
					break;
				case REMEDIATED:
					remediatedCount++;
					break;
				case NOT_APPLICABLE:
					notApplicableCount++;
					break;
				case REVIEWED:
					reviewedCount++;
					break;
				default:
					throw new IllegalArgumentException();

				}
			}

		}
		completeCount = remediatedCount + notApplicableCount;
		pendingCount = newCount + reviewedCount + workInProgressCount;
		kpiBean.setCompleteCount(completeCount);
		kpiBean.setNewCount(newCount);
		kpiBean.setNotApplicableCount(notApplicableCount);
		kpiBean.setPendingCount(pendingCount);
		kpiBean.setRemediatedCount(remediatedCount);
		kpiBean.setReviewedCount(reviewedCount);
		kpiBean.setWorkInProgressCount(workInProgressCount);
		return kpiBean;
	}

	@Override
	public List<AffectedProductsKpi> getEtaAffectedProductsForKpi(Map<String, Object> filterParams) {
		
		final List<AdvisoryBean> aggList = advisoriesMapper.getEtaArticles(filterParams);
		filterParams.put("articleNumbers",
				aggList.stream().map(AdvisoryBean::getArticleNumber).collect(Collectors.joining("|")));
		return advisoriesMapper.getEtaAffectedProductsForKpi(filterParams);
	
	}
	
	@Override
	public AdvisoryBean getAdvisoryDetail(Map<String, Object> filterParams) {
		final String advisoryType = (String) filterParams.get("advisoryType");
		if (advisoryType.equalsIgnoreCase("ESA") || advisoryType.equalsIgnoreCase("DSA")) {
			return advisoriesMapper.getSecAdvisoryDetail(filterParams);
		} else if (advisoryType.equalsIgnoreCase("ETA") || advisoryType.equalsIgnoreCase("DTA")) {
			return advisoriesMapper.getTechAdvisoryDetail(filterParams);
		} else {
			return new AdvisoryBean();
		}
	}

	@Override
	public void addNotes(Map<String, Object> filterParams, UserBean user) throws IOException {
		if ("true".equalsIgnoreCase((String) filterParams.get("isSerialized"))) {
			final ObjectMapper mapper = new ObjectMapper();
			final List<InstanceSiteMap> instanceSiteRoleMap = mapper.readValue((String) filterParams.get("instanceSiteMap"),
					new TypeReference<List<InstanceSiteMap>>() {
					});
			final String role = instanceSiteRoleMap.stream().map(InstanceSiteMap::getRole)
					.collect(Collectors.joining(","));
			user.setEmail((String) filterParams.get("email"));
			user.setFlname((String) filterParams.get("userName"));
			if ("PARTNER".equalsIgnoreCase(role)) {
				user.setIdentityType("P");
			} else if ("EMPLOYEE".equalsIgnoreCase(role)) {
				user.setIdentityType("E");
			} else {
				user.setIdentityType(role);
			}
		}
		insertNotes(filterParams, user);
	}

	private void insertNotes(Map<String, Object> filterParams, UserBean user) throws IOException {
		String sql = "";
		final String advisoryType = (String) filterParams.get("advisoryType");
		if (advisoryType.equalsIgnoreCase("ESA")) {
			sql = esaNoteSql;
		} else if (advisoryType.equalsIgnoreCase("ETA")) {
			sql = etaNoteSql;
		}
		final ObjectMapper mapper = new ObjectMapper();
		final List<InstanceSiteMap> instanceIdMap = mapper.readValue((String) filterParams.get("instanceSiteMap"),
				new TypeReference<List<InstanceSiteMap>>() {
				});
		final String instanceIdIsIn = instanceIdMap.stream().map(InstanceSiteMap::getInstanceId)
				.collect(Collectors.joining("|"));
		filterParams.put("instanceIdIsIn", instanceIdIsIn);
		
		if ("true".equalsIgnoreCase((String) filterParams.get("isSerialized"))) {
			filterParams.put("instanceNumberIsIn", instanceIdIsIn);
		}

		final List<Map<String, Object>> writeList = getInsertList(filterParams);
		final String note = (String) filterParams.get("notes");
		final String resol = (String) filterParams.get("resolution");
		final String articleId = (String) filterParams.get("articleIdIsIn");
		final String company = (String) filterParams.get("companyName");
		jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				writeList.get(i).put("note", note);
				writeList.get(i).put("articleId", articleId);
				writeList.get(i).put("identityType", user.getIdentityType());
				writeList.get(i).put("email", user.getEmail());
				writeList.get(i).put("userName", user.getFlname());
				writeList.get(i).put("uid", user.getUid());
				writeList.get(i).put("companyName", company);
				writeList.get(i).put("timestamp", System.currentTimeMillis());
				writeList.get(i).put("showNote", true);
				log.info("add notes for userEmail : "+user.getEmail()
									+" articleNumber : "+writeList.get(i).get("articleNumber")
									+" serialNumber : "+writeList.get(i).get("serialNumber"));
				final Optional<InstanceSiteMap> matchingObject = instanceIdMap.stream()
						.filter(instance -> instance.getInstanceId().equals(writeList.get(i).get("instanceNumber")))
						.findAny();
				if (matchingObject.isPresent()) {
					writeList.get(i).put("role", matchingObject.get().getRole());
				}

				if (resol != null && !resol.isEmpty()) {
					if (advisoryType.equalsIgnoreCase("ESA")) {
						writeList.get(i).put("resolution", DsaResolutionTracking.get(resol));
					} else if (advisoryType.equalsIgnoreCase("ETA")) {
						writeList.get(i).put("resolution", EtaResolutionTracking.get(resol));
					}
				} else {
					writeList.get(i).put("resolution", resol);
				}

				try {
					ps.setObject(1, objectMapper.writeValueAsString(writeList.get(i)));
					} catch (final Exception e) {					
					log.error("Error while add notes for userEmail : "+user.getEmail()+" articleNumber : "+writeList.get(i).get("articleNumber")
								+" serialNumber : "+writeList.get(i).get("serialNumber"));
				}
			}

			@Override
			public int getBatchSize() {
				log.info("Write List Size :"+writeList.size());
				return writeList.size();
			}
		});
	}

	private List<Map<String, Object>> getInsertList(Map<String, Object> filterParams) {
		List<Map<String, Object>> writeList = new ArrayList<>();
		final String advisoryType = (String) filterParams.get("advisoryType");
		if (advisoryType.equalsIgnoreCase("ESA")) {
			writeList = advisoriesMapper.getEsaInstanceMap(filterParams);
		} else if (advisoryType.equalsIgnoreCase("ETA")) {
			writeList = advisoriesMapper.getEtaInstanceMap(filterParams);
		}
		return writeList;
	}

	@Override
	@Async
	public Future<List<Note>> getNotes(Map<String, Object> filterParams, String advisoryType) {
		List<Note> notes = new ArrayList<>();
		if (advisoryType.equalsIgnoreCase("ESA")) {
			notes = advisoriesMapper.getEsaNotes(filterParams);
		} else if (advisoryType.equalsIgnoreCase("ETA")) {
			notes = advisoriesMapper.getEtaNotes(filterParams);
		}
		return new AsyncResult<List<Note>>(notes);
	}

	@Override
	@Async
	public Future<List<IpsNote>> getNotesForSerializedProduct(Map<String, Object> filterParams,String advisoryType) {
		List<IpsNote> notesList = new ArrayList();
		if(advisoryType.equalsIgnoreCase("ESA")) {
			notesList =  advisoriesMapper.getEsaNotesSerialized(filterParams);
		} else if (advisoryType.equalsIgnoreCase("ETA")) {
			notesList = advisoriesMapper.getEtaNotesSerialized(filterParams);
		}
		
		// validate events and remove then for existing corresponding notes.
		if (notesList.size() > 0) {
			List<IpsNote> advNotesList = notesList.stream()
					.filter(advNote -> advNote.getRecordType().equalsIgnoreCase("note"))
					.collect(Collectors.toList());
			List<IpsNote> advEventsList = notesList.stream()
					.filter(advNote -> advNote.getRecordType().equalsIgnoreCase("event"))
					.collect(Collectors.toList());
			List<IpsNote> updatedEventsList = new ArrayList();
			for (IpsNote event : advEventsList) {
				boolean isDuplicate = false;
				for (IpsNote note : advNotesList) {
					if (event.isEquals(note)) {
						isDuplicate = true;
					}
				}
				if (!isDuplicate) {
					updatedEventsList.add(event);
				}
			}
			
			notesList = Stream.of(advNotesList,updatedEventsList)
					.flatMap(Collection::stream)
					.sorted(Comparator.comparingLong(IpsNote::getTimestamp).reversed())
					.collect(Collectors.toList());
		}
		
		return new AsyncResult<List<IpsNote>>(notesList);
	}
	
	@Override
	@Async
	public Future<List<AdvisoriesHud>> getDsaHud(Map<String, Object> filterParams) {
		
		List<AdvisoriesHud> data = new ArrayList<>();
		data = advisoriesMapper.getDsaHud(filterParams);
		return new AsyncResult<List<AdvisoriesHud>>(data);
	}
	
	@Override
	@Async
	public Future<List<AdvisoriesHud>> getDtaHud(Map<String, Object> filterParams) {
		
		List<AdvisoriesHud> data = new ArrayList<>();
		data = advisoriesMapper.getDtaHud(filterParams);
		return new AsyncResult<List<AdvisoriesHud>>(data);
	}
	
	
	
	@Override
	@Async
	public Future<Integer> getESASerializedTotalRecord(Map<String, Object> filterParams) {
		String articleStatusIsIn = (String)filterParams.get("articleStatusIsIn");
		if (articleStatusIsIn != null) { 
			filterParams.put("articleStatusIsIn", updateSerializedArticleStatus(articleStatusIsIn));
		}
		String severityFilterIsIn = (String)filterParams.get("severityFilterIsIn");
		if (severityFilterIsIn != null) { 
			if (severityFilterIsIn.indexOf("Low") != -1) {
				filterParams.put("severityFilterIsIn", severityFilterIsIn + "|None");
			}
		}
		return new AsyncResult<>(advisoriesMapper.getESASerializedTotalRecord(filterParams));
	}

	@Override
	@Async
	public Future<Integer> getETASerializedTotalRecord(Map<String, Object> filterParams) {
		String articleStatusIsIn = (String)filterParams.get("articleStatusIsIn");
		if (articleStatusIsIn != null) { 
			filterParams.put("articleStatusIsIn", updateSerializedArticleStatus(articleStatusIsIn));
		}
		String severityFilterIsIn = (String)filterParams.get("severityFilterIsIn");
		if (severityFilterIsIn != null) { 
			if (severityFilterIsIn.indexOf("Low") != -1) {
				filterParams.put("severityFilterIsIn", severityFilterIsIn + "|None");
			}
		}
		return new AsyncResult<>(advisoriesMapper.getETASerializedTotalRecord(filterParams));
	}
	
	private List<SerializedProductBean> filterBySelectedFilters(List<SerializedProductBean> serializedProductBeans, 
			Map<String, Object> filterParams) {
		String severityFilterIsIn = (String)filterParams.get("severityFilterIsIn");
		String articleStatusIsIn = (String)filterParams.get("articleStatusIsIn");
		String dateBefore = null;
		String dateAfter = null;
		if ("ESA".equalsIgnoreCase((String)filterParams.get("advisoryType"))) {
			dateBefore = (String)filterParams.get("esaDateBefore");
			dateAfter = (String)filterParams.get("esaDateAfter");
		} else if ("ETA".equalsIgnoreCase((String)filterParams.get("advisoryType"))){
			dateBefore = (String)filterParams.get("etaDateBefore");
			dateAfter = (String)filterParams.get("etaDateAfter");
		}
		if (null != severityFilterIsIn && !"".equalsIgnoreCase(severityFilterIsIn)) {
			serializedProductBeans = serializedProductBeans.stream()
					.filter(article -> severityFilterIsIn.contains(article.getSeverity()))
					.collect(Collectors.toList());
		}
		if (null != articleStatusIsIn && !"".equalsIgnoreCase(articleStatusIsIn)) {
			serializedProductBeans = serializedProductBeans.stream()
					.filter(article -> articleStatusIsIn.contains(article.getStatus()))
					.collect(Collectors.toList());
		}
		if (null != dateAfter && null != dateBefore) {
			String after = dateAfter;
			String before = dateBefore;
			serializedProductBeans = serializedProductBeans.stream()
					.filter(article -> 
						(article.isWithin(after, before))) 
					.collect(Collectors.toList());
		}
		
		return serializedProductBeans;
	}
	
	private List<SerializedProductBean> filterBySearchString(List<SerializedProductBean> serializedProductBeans, 
			String searchString) {
		if (null != searchString && !"".equalsIgnoreCase(searchString)) {
			serializedProductBeans = serializedProductBeans.stream()
					.filter(article -> (null != article.getArticleId() && article.getArticleId().contains(searchString)) 
							|| (null != article.getAdvisoryId() && article.getAdvisoryId().contains(searchString)) 
							|| (null != article.getAge() && article.getAge().contains(searchString)) 
							|| (null != article.getTitle() && article.getTitle().contains(searchString))
							|| (null != article.getSeverity() && article.getSeverity().contains(searchString)) 
							|| (null != article.getSummary() && article.getSummary().contains(searchString))
							|| (null != article.getResolution() && article.getResolution().contains(searchString))
							|| (null != article.getStatus() && article.getStatus().contains(searchString))
							|| (null != article.getLastUpdatedBy() && article.getLastUpdatedBy().contains(searchString))
							|| (null != article.getFirstPublishedDate() && 
								new SimpleDateFormat("dd MMM yyyy").format(new Date(Long.parseLong(article.getFirstPublishedDate()))).toString().toUpperCase().contains(searchString))
							|| (null != article.getLastPublishedDate() && 
								new SimpleDateFormat("dd MMM yyyy").format(new Date(Long.parseLong(article.getLastPublishedDate()))).toString().toUpperCase().contains(searchString))
						)
					.collect(Collectors.toList());
		}
		return serializedProductBeans;
	}
	
	private String updateSerializedArticleStatus(String articleStatusIsIn) {
		if (articleStatusIsIn.indexOf("Work in Progress") != -1) {
			articleStatusIsIn = articleStatusIsIn + "|Work In Progress";
		} 
		else if (articleStatusIsIn.indexOf("Work In Progress") != -1) {
			articleStatusIsIn = articleStatusIsIn + "|Work in Progress";
		} 
		if (articleStatusIsIn.indexOf(REVIEWED) != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_REVIEWED;
		}
		if (articleStatusIsIn.indexOf(NEW) != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_NEW;
		}
		if (articleStatusIsIn.indexOf(WORK_IN_PROGRESS) != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_WORK_IN_PROGRESS;
		}
		if (articleStatusIsIn.indexOf("Workaround Applied") != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_WORKAROUND_APPLIED;
		}
		if (articleStatusIsIn.indexOf(NOT_APPLICABLE) != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_NOT_APPLICABLE;
		}
		if (articleStatusIsIn.indexOf(REMEDIATED) != -1) {
			articleStatusIsIn = articleStatusIsIn + "|" + FILTER_REMEDIATED;
		}
		return articleStatusIsIn;
	}
	
	@Override
	public SerializedResponseBean getAdvisoryForProduct(Map<String, Object> filterParams, String advisoryType) {
		String articleStatusIsIn = (String)filterParams.get("articleStatusIsIn");
		if (articleStatusIsIn != null) { 
			filterParams.put("articleStatusIsIn", updateSerializedArticleStatus(articleStatusIsIn));
		}
		String severityFilterIsIn = (String)filterParams.get("severityFilterIsIn");
		if (severityFilterIsIn != null) { 
			if (severityFilterIsIn.indexOf("Low") != -1) {
				filterParams.put("severityFilterIsIn", severityFilterIsIn + "|None");
			}
		}
		SerializedResponseBean responseBean = new SerializedResponseBean();
		Map<String, Integer> advisoryCountsMap = new HashMap<String, Integer>();
		Map<String, Integer> severityCountsMap = new HashMap<String, Integer>();
		
		List<SerializedProductBean> serializedProductBeans = null;
		if (advisoryType.equals("ETA")) {
			serializedProductBeans = advisoriesMapper.getEtaForProduct(filterParams);
		} else {
			serializedProductBeans = advisoriesMapper.getEsaForProduct(filterParams);
		}
		
		responseBean.setTotalElementsCount(serializedProductBeans.size());	
		
		severityCountsMap.put(CRITICAL, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(CRITICAL))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(HIGH, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(HIGH))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(MEDIUM, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(MEDIUM))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(LOW, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(LOW))
			        .collect(Collectors.toList()).size());
		
		int size = (Integer) filterParams.get("size");
		int number = (Integer) filterParams.get("number");
		if ((size + number * size) < responseBean.getTotalElementsCount()) {
			serializedProductBeans = serializedProductBeans.subList(number * size, size);
		}
		
		responseBean.setSerializedProductBean(serializedProductBeans);
		responseBean.setSeverityCountsMap(severityCountsMap);
		
		return responseBean;
	}
	
	@Override
	public SerializedResponseBean getAdvisorySerialized(Map<String, Object> filterParams, String advisoryType) {
		String articleStatusIsIn = (String)filterParams.get("articleStatusIsIn");
		if (articleStatusIsIn != null) { 
			filterParams.put("articleStatusIsIn", updateSerializedArticleStatus(articleStatusIsIn));
		}
		String severityFilterIsIn = (String)filterParams.get("severityFilterIsIn");
		if (severityFilterIsIn != null) { 
			if (severityFilterIsIn.indexOf("Low") != -1) {
				filterParams.put("severityFilterIsIn", severityFilterIsIn + "|None");
			}
		}
		SerializedResponseBean responseBean = new SerializedResponseBean();
		Map<String, Integer> advisoryCountsMap = new HashMap<String, Integer>();
		Map<String, Integer> severityCountsMap = new HashMap<String, Integer>();
		if (filterParams.get("articleStatusIsIn") != null && filterParams.get("articleStatusIsIn").equals("Pending")) {
			filterParams.put("articleStatusIsIn", "New|Reviewed|Work In Progress");
		} else if (filterParams.get("articleStatusIsIn") != null
				&& filterParams.get("articleStatusIsIn").equals("Completed")) {
			filterParams.put("articleStatusIsIn", "Remediated|Not Applicable");
		} else if (filterParams.get("articleStatusIsIn") != null
				&& (filterParams.get("articleStatusIsIn").equals("Pending|Completed")
						|| filterParams.get("articleStatusIsIn").equals("Completed|Pending"))) {
			filterParams.put("articleStatusIsIn", "Remediated|Not Applicable|New|Reviewed|Work In Progress");
		}
		List<SerializedProductBean> serializedProductBeans = null;
		if (advisoryType.equals("ETA")) {
			serializedProductBeans = advisoriesMapper.getEtaSerialized(filterParams);
		} else {
			serializedProductBeans = advisoriesMapper.getEsaSerialized(filterParams);
		}
		if (0 < serializedProductBeans.size()) {
			String articleNumberIsIn = serializedProductBeans.stream().map(serializedProductBean -> serializedProductBean.getArticleNumber()).collect(Collectors.joining("|"));
			if (null != articleNumberIsIn && !"".equalsIgnoreCase(articleNumberIsIn)) {
				filterParams.put("articleNumberIsIn", articleNumberIsIn);
				List<SerializedAdvisoryEvent> events = null; 
				if (advisoryType.equals("ETA")) {
					events = advisoriesMapper.getEtaEventsSerialized(filterParams);
				} else {
					events = advisoriesMapper.getEsaEventsSerialized(filterParams);
				}
				
				Map<String, SerializedAdvisoryEvent> eventDetailsMap = new HashMap<String, SerializedAdvisoryEvent>();
				events.forEach(event -> {
					if (null == eventDetailsMap.get(event.getArticleNumber() + event.getInstanceNumber())) {
						eventDetailsMap.put(event.getArticleNumber() + event.getInstanceNumber(), event);
					};
				});
				
				serializedProductBeans = serializedProductBeans.stream()
						  .map(serializedProductBean -> {
						  	SerializedAdvisoryEvent esaEvent = eventDetailsMap.get(serializedProductBean.getArticleNumber() + serializedProductBean.getInstanceNumber());
						  	if (null != esaEvent) {
							  	serializedProductBean.setStatus(esaEvent.getStatus());
							  	serializedProductBean.setLastUpdatedBy(esaEvent.getLastUpdatedBy());
							  	serializedProductBean.setLastUpdatedDate(esaEvent.getLastUpdatedDate());
						  	}
		                    return serializedProductBean;
		                   })
						  .collect(Collectors.toList());
			}	
		}
		
		// filter by search string
		serializedProductBeans = filterBySearchString(serializedProductBeans, (String)filterParams.get("searchSerializedIsLike"));
		
		// filter by selected filters
		serializedProductBeans = filterBySelectedFilters(serializedProductBeans, filterParams);
		
		responseBean.setTotalElementsCount(serializedProductBeans.size());	
		
		advisoryCountsMap.put(FILTER_NEW, serializedProductBeans.stream()
			      .filter(article -> article.getStatus().equalsIgnoreCase(NEW))
			        .collect(Collectors.toList()).size());
		advisoryCountsMap.put(FILTER_WORK_IN_PROGRESS, serializedProductBeans.stream()
			      .filter(article -> article.getStatus().equalsIgnoreCase(WORK_IN_PROGRESS))
			        .collect(Collectors.toList()).size());
		if (advisoryType.equals("ETA")) { 
			advisoryCountsMap.put(FILTER_WORKAROUND_APPLIED, serializedProductBeans.stream()
					.filter(article -> article.getStatus().equalsIgnoreCase(WORK_AROUND_APPLIED))
			        .collect(Collectors.toList()).size());
		}
		advisoryCountsMap.put(FILTER_REVIEWED, serializedProductBeans.stream()
			      .filter(article -> article.getStatus().equalsIgnoreCase(REVIEWED))
			        .collect(Collectors.toList()).size());
		advisoryCountsMap.put(FILTER_NOT_APPLICABLE, serializedProductBeans.stream()
			      .filter(article -> article.getStatus().equalsIgnoreCase(NOT_APPLICABLE))
			        .collect(Collectors.toList()).size());
		advisoryCountsMap.put(FILTER_REMEDIATED, serializedProductBeans.stream()
			      .filter(article -> article.getStatus().equalsIgnoreCase(REMEDIATED))
			        .collect(Collectors.toList()).size());
		
		severityCountsMap.put(CRITICAL, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(CRITICAL))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(HIGH, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(HIGH))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(MEDIUM, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(MEDIUM))
			        .collect(Collectors.toList()).size());
		severityCountsMap.put(LOW, serializedProductBeans.stream()
			      .filter(article -> article.getSeverity().equalsIgnoreCase(LOW))
			        .collect(Collectors.toList()).size());
		
		// sorts records based on status or lastUpdatedBy
		String sortBy = (String)filterParams.get("sortBy");
		String sortDir = (String)filterParams.get("sortDir");
		if ("status".equalsIgnoreCase(sortBy)) {
			if ("desc".equalsIgnoreCase(sortDir)) {
				serializedProductBeans.sort(Comparator.comparingInt(SerializedProductBean::getStatusValue).reversed());
			} else {
				serializedProductBeans.sort(Comparator.comparingInt(SerializedProductBean::getStatusValue));
			}
		}		
		if ("lastUpdatedBy".equalsIgnoreCase(sortBy)) {
			if ("desc".equalsIgnoreCase(sortDir)) {
				serializedProductBeans.sort(Comparator.comparing(SerializedProductBean::getLastUpdatedBy).reversed());
			} else {
				serializedProductBeans.sort(Comparator.comparing(SerializedProductBean::getLastUpdatedBy));
			}
		}				
		
		int size = (Integer) filterParams.get("size");
		int number = (Integer) filterParams.get("number");
		if ((size + number * size) < responseBean.getTotalElementsCount()) {
			serializedProductBeans = serializedProductBeans.subList(number * size, size);
		}
		
		responseBean.setSerializedProductBean(serializedProductBeans);
		responseBean.setAdvisoryCountsMap(advisoryCountsMap);
		responseBean.setSeverityCountsMap(severityCountsMap);
		
		responseBean.setSubscriptionAlertEnabled(false);		
		String uid = (String)filterParams.get("uid");
		String tagId = (String)filterParams.getOrDefault("tagId", "0");
		
		
		if (!"0".equalsIgnoreCase(tagId)) {
			
			String profileId=request.getHeader("profileId");			
			Map<String,Object> subscriptionDetails = subscriptionDetailsService.getSubscriptionDetails(profileId);
			Object subscriptionsObject = subscriptionDetails.get("subscriptions");

			String result = advisoriesMapper.getProductNames(filterParams);

			if (result != null) {
			    List<Map<String, Object>> subscriptionsMap = objectMapper.convertValue(subscriptionsObject,
			            new TypeReference<List<Map<String, Object>>>() {
			            });

			    for (Map<String, Object> subscription : subscriptionsMap) {
			        List<Map<String, Object>> subDetails = objectMapper.convertValue(
			                subscription.get("subDetails"), new TypeReference<List<Map<String, Object>>>() {
			                });

			        if (result.equals(subDetails.get(0).get("productName"))) {
			            boolean enableAlert = false;
			            if (advisoryType.equals("ESA")) {
			                enableAlert = (boolean) subDetails.get(0).get("dsa");
			            } else if (advisoryType.equals("ETA")) {
			                enableAlert = (boolean) subDetails.get(0).get("dta");
			            }
			            responseBean.setSubscriptionAlertEnabled(enableAlert);
			            break; 
			        }
			    }
			}
		}
		return responseBean;
	}
	
	
	
	@Override
	@Async
	public Future<List<AdvisoriesSummary>> getEsaSummary(Map<String, Object> filterParams) {
		StopWatch sw = new StopWatch();
		sw.start();
		List<AdvisoriesSummary> result = advisoriesMapper.getEsaSummary(filterParams);
		sw.stop();
		long duration = sw.getLastTaskTimeMillis();
		if(duration > 4999) {
			log.info("Slow running getEsaSummary {}ms - groupBySite: {} - {}", sw.getLastTaskTimeMillis(), filterParams.containsKey("groupBySite"), filterParams);	
		}
		return new AsyncResult<>(result);
	}

	@Override
	@Async
	public Future<List<AdvisoriesSummary>> getEtaSummary(Map<String, Object> filterParams) {
		StopWatch sw = new StopWatch();
		sw.start();
		List<AdvisoriesSummary> result = advisoriesMapper.getEtaSummary(filterParams);
		sw.stop();
		long duration = sw.getLastTaskTimeMillis();
		if(duration > 4999) {
			log.info("Slow running getEtaSummary {}ms - groupBySite: {} - {}", sw.getLastTaskTimeMillis(), filterParams.containsKey("groupBySite"), filterParams);	
		}
		return new AsyncResult<>(result);
	}

	@Override
	@Async
	public Future<Integer> getDsaCount(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getDsaCount(filterParams));
	}
	
	@Override
	@Async
	public Future<Integer> getDtaCount(Map<String, Object> filterParams) {
		return new AsyncResult<>(advisoriesMapper.getDtaCount(filterParams));
	}
}
