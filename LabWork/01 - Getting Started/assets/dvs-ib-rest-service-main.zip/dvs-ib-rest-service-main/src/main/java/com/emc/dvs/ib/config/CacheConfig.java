package com.emc.dvs.ib.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import lombok.Getter;
import lombok.Setter;


@Configuration
@EnableCaching
public class CacheConfig  implements CachingConfigurer {

	@Getter
	@Setter
	@Value("${ib.currentPatition.redis.ttl}")
	private int ttl;
	
	@Bean
	public RedisTemplate<String,Object> redisCacheTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String,Object> template = new RedisTemplate<String,Object>();
		template.setConnectionFactory(redisConnectionFactory);
		return template;
	}
	
	// to explore again
//	@Bean
//	public CacheManager cacheManager(RedisTemplate<String,Object> redisCacheTemplate) {
//	    RedisCacheManager cacheManager = new RedisCacheManager();
//
//	    // Number of seconds before expiration. Defaults to unlimited (0)
//	    cacheManager.setDefaultExpiration(ttl);
//	    return cacheManager;
//	  }
	
	@Bean
	public CacheManager cacheManager(RedisConnectionFactory factory) {
		Duration expiration = Duration.ofSeconds(ttl);
		RedisCacheManager.RedisCacheManagerBuilder builder = RedisCacheManager
		    .builder(factory)
		    .cacheDefaults(RedisCacheConfiguration.defaultCacheConfig().entryTtl(expiration));
		return builder.build();
	}
}
