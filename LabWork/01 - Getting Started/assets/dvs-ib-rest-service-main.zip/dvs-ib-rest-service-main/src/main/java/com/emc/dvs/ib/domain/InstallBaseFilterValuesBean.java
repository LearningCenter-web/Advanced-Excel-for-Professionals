package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class InstallBaseFilterValuesBean {
	
	
	@JsonIgnore
	private String tlaFlagList;
	@JsonIgnore
	private String ibStatusList;
	@JsonIgnore
	private String productFamilyList;	
	@JsonIgnore
	private String siteDisplayNameList;
	@JsonIgnore
	private String contractStatusList;
	@JsonIgnore
	private String servicePlanLevelList;
	
	
	private List<String> tlaFlag;
	private List<String> ibStatus;
	private List<String> productFamily;
	private List<String> productName;
	private List<String> siteDisplayName;
	private List<String> contractStatus;
	private List<String> servicePlanLevel;
	
	
	public void setTlaFlagList(String tlaFlagList) {
		this.tlaFlagList = tlaFlagList;
		if(StringUtils.hasText(tlaFlagList)) {
			this.tlaFlag = Arrays.asList(tlaFlagList.split("\\|"));
		}
		else {
			this.tlaFlag = new ArrayList<String>();
		}
	}
	public void setIbStatusList(String ibStatusList) {
		this.ibStatusList = ibStatusList;
		if(StringUtils.hasText(ibStatusList)) {
			this.ibStatus = Arrays.asList(ibStatusList.split("\\|"));
		}
		else {
			this.ibStatus = new ArrayList<String>();
		}
	}
	public void setProductFamilyList(String productFamilyList) {
		this.productFamilyList = productFamilyList;
		if(StringUtils.hasText(productFamilyList)) {
			this.productFamily = Arrays.asList(productFamilyList.split("\\|"));
		}
		else {
			this.productFamily = new ArrayList<String>();
		}
	}	
	public void setSiteDisplayNameList(String siteDisplayNameList) {
		this.siteDisplayNameList = siteDisplayNameList;
		if(StringUtils.hasText(siteDisplayNameList)) {
			this.siteDisplayName = Arrays.asList(siteDisplayNameList.split("\\|"));
		}
		else {
			this.siteDisplayName = new ArrayList<String>();
		}
	}
	public void setContractStatusList(String contractStatusList) {
		this.contractStatusList = contractStatusList;
		if(StringUtils.hasText(contractStatusList)) {
			this.contractStatus = Arrays.asList(contractStatusList.split("\\|"));
		}
		else {
			this.contractStatus = new ArrayList<String>();
		}
	}
	
	public void setServicePlanLevelList(String servicePlanLevelList) {
		this.servicePlanLevelList = servicePlanLevelList;
		if(StringUtils.hasText(servicePlanLevelList)) {
			this.servicePlanLevel = Arrays.asList(servicePlanLevelList.split("\\|"));
		}
		else {
			this.servicePlanLevel = new ArrayList<String>();
		}
	}
	
	public List<String> getVce(){
		List<String> vce = new ArrayList<>();
		vce.add("Non-VCE");
		vce.add("VCE");
		return vce;
		
	}
}
