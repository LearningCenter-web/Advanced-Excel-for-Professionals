package com.emc.dvs.ib.service;
import java.util.List;
public interface AccountService {
	public List<Object> getSiteDetails(String siteNumber,String uid);
}
