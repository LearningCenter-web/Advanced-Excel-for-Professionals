package com.emc.dvs.ib.domain;

import java.io.Serializable;

import lombok.Data;

@Data
public class ComponentBean implements Serializable {
	
	private static final long serialVersionUID = 8692781547217866954L;
	
	public String owner;
	public String componentModelNumber;
	public String componentName;
	public String contractNumber;
	public String contractStatus;
	public Long openSrCount;
	public String productType;
	private String ciSolutionSerialNumber;
	private String componentSerialNumber;
	private Long instanceNumber;
	private boolean isInIB;

}
