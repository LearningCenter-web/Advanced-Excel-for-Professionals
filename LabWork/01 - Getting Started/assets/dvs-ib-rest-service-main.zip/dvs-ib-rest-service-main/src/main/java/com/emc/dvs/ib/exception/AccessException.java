package com.emc.dvs.ib.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(value=HttpStatus.FORBIDDEN, reason="access denied")
public class AccessException extends RuntimeException {

	private static final long serialVersionUID = -4150539728234964277L;

}