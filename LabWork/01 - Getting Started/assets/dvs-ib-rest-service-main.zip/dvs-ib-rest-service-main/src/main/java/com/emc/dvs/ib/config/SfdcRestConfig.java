package com.emc.dvs.ib.config;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.DefaultOAuth2RequestAuthenticator;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2AccessDeniedException;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.resource.UserRedirectRequiredException;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import lombok.Setter;

@EnableOAuth2Client
@Configuration
@ConfigurationProperties(prefix="security.oauth2.client")
public class SfdcRestConfig {

	@Setter private String accessTokenUri;
	@Setter private String clientId;
	@Setter private String clientSecret;
	@Setter private String username;
	@Setter private String password;
	
	@Value("${dvs.http.connectTimeout:2000}")
	private int connectTimeout;
	
	@Value("${dvs.http.readTimeout:18000}")
	private int readTimeout;
	
	@Bean
	ResourceOwnerPasswordResourceDetails resourceOwnerPasswordResourceDetails() {
		ResourceOwnerPasswordResourceDetails resourceDetails = new ResourceOwnerPasswordResourceDetails();
		resourceDetails.setUsername(username);
		resourceDetails.setPassword(password);
		resourceDetails.setAccessTokenUri(accessTokenUri);
		resourceDetails.setClientId(clientId);
		resourceDetails.setClientSecret(clientSecret);
		resourceDetails.setClientAuthenticationScheme(AuthenticationScheme.form);
		return resourceDetails;
	}
	
	@Bean
	public OAuth2RestOperations sfdcRestTemplate() {
	    AccessTokenRequest atr = new DefaultAccessTokenRequest();
	    OAuth2RestTemplate template = new OAuth2RestTemplate(resourceOwnerPasswordResourceDetails(), new DefaultOAuth2ClientContext(atr));
	    template.setAccessTokenProvider(new SfdcAccessTokenProvider());
	    template.setAuthenticator(new DefaultOAuth2RequestAuthenticator());
	    HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
	    httpRequestFactory.setConnectTimeout(connectTimeout);
	    httpRequestFactory.setReadTimeout(readTimeout);
	    template.setRequestFactory(httpRequestFactory);
	    return template;
	}
	
	/**
	 * Modification of {@link org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider}
	 * to include client_id and client_secret in the initial authentication request as SFDC requires both these fields.
	 *
	 */
	private class SfdcAccessTokenProvider extends ResourceOwnerPasswordAccessTokenProvider {
		
		@Override
		public OAuth2AccessToken obtainAccessToken(OAuth2ProtectedResourceDetails details, AccessTokenRequest request)
				throws UserRedirectRequiredException, AccessDeniedException, OAuth2AccessDeniedException {

			ResourceOwnerPasswordResourceDetails resource = (ResourceOwnerPasswordResourceDetails) details;
			return retrieveToken(request, resource, getParametersForAccessTokenRequest(resource, request), new HttpHeaders());

		}
		
		private MultiValueMap<String, String> getParametersForAccessTokenRequest(ResourceOwnerPasswordResourceDetails resource, AccessTokenRequest request) {
			MultiValueMap<String, String> form = new LinkedMultiValueMap<String, String>();
			form.set("grant_type", "password");

			form.set("username", resource.getUsername());
			form.set("password", resource.getPassword());
			//Add client id and secret
			form.set("client_id", resource.getClientId());
			form.set("client_secret", resource.getClientSecret());
			form.putAll(request);

			if (resource.isScoped()) {

				StringBuilder builder = new StringBuilder();
				List<String> scope = resource.getScope();

				if (scope != null) {
					Iterator<String> scopeIt = scope.iterator();
					while (scopeIt.hasNext()) {
						builder.append(scopeIt.next());
						if (scopeIt.hasNext()) {
							builder.append(' ');
						}
					}
				}

				form.set("scope", builder.toString());
			}

			return form;
		}
	}

}
