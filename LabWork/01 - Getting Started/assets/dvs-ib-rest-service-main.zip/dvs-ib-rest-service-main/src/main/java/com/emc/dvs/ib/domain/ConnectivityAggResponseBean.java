package com.emc.dvs.ib.domain;

import java.util.Map;

import lombok.Data;

@Data
public class ConnectivityAggResponseBean {
	private Map<String, Object> aggMap;
	private InstallBaseStatsBean stats;
	
}
