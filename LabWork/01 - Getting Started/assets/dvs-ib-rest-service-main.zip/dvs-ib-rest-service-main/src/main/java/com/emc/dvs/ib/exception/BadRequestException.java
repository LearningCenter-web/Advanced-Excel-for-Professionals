package com.emc.dvs.ib.exception;

public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = 5804581964210210889L;

	public BadRequestException(String message) {
		super(message);
	}

	public BadRequestException(String message, Throwable cause) {
		super(message, cause);
	}

}
