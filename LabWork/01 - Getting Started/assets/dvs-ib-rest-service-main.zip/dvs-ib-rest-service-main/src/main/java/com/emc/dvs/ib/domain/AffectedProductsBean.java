package com.emc.dvs.ib.domain;

import java.util.List;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class AffectedProductsBean {

	private String productName;
	private String productAlias;
	private String productId;
	private String instanceId;
	private String lemcInstanceNumber;
	private String siteId;
	private String productFamily;
	private String lastUpdatedBy;
	private boolean serialNumberProductPage;
	private String resolution;
	@ExportDate(value = "d MMM yyyy, hh:mm a")
	private Long dateUpdated;
	private String email;
	private List<Note> note;
	private Integer noteCount;
	private String productPageUrl;
	private String installedCode;
}
