package com.emc.dvs.ib.domain;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class CodeLevelsAggregateResponseBean {

	private int total;
	private Map<String,CodeLevelsCatAggBean> categories;
	
	public Map<String,CodeLevelsCatAggBean> getCategories(){
		if (categories == null){
			categories = new HashMap<String, CodeLevelsCatAggBean>();
		}
		return categories;
	}
	
}
