package com.emc.dvs.ib.domain;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true) 
public class SerializedProductBean {
	private String articleId;
	private String articleNumber;
	private String urlArticleNumber;
	private String severity;
	private String advisoryId;
	private String title;
	private String resolution;
	private String summary;
	private String firstPublishedDate;
	@JsonIgnore
	private Calendar cFirstPublished;
	@JsonIgnore
	private String published;
	@JsonIgnore
	private String instanceNumber;
	@SuppressWarnings("unused")
	private String lastPublishedDate;
	private String vulnerabilitySource;
	private String age;
	private List<String> cveIdList;
	@JsonIgnore
	private String cveIds;
	private String status;
	@JsonIgnore
	private int statusValue;
	private String lastUpdatedBy;
	private String lastUpdatedDate;
	private String lastReviewedBy;
	private String lastReviewTime;
	private String impact;
	private String severityDescription;
	private String urlName;
	
	public void setCveIds(String cveIds) {
		this.cveIds = cveIds;
		if (StringUtils.hasText(cveIds)) {
			this.cveIdList = Arrays.asList(cveIds.split(","));
		} else {
			this.cveIdList = new ArrayList<String>();
		}
	}
	
	public String getLastPublishedDate() {
		return this.published;
	}
	
	private String getPublishedDateFilterFormat(Date publishedDate) {
		Calendar cPublished = Calendar.getInstance();
		cPublished.setTime(publishedDate);
		int year = cPublished.get(Calendar.YEAR);
		int month = cPublished.get(Calendar.MONTH);
		int day = cPublished.get(Calendar.DAY_OF_MONTH);
		String filterFormatDay = day < 10 ? "-0" + day : "-" + day;
		String filterFormatMonth = month < 9 ? "-0" + (month + 1) : "-" + (month + 1);
		return year + filterFormatMonth + filterFormatDay;
	}
	
	public boolean isWithin(String dateAfter, String dateBefore) {
		boolean isWithin = false;
		Date publishedDate = new Date(Long.parseLong(this.firstPublishedDate));
		String filterFormatDate = getPublishedDateFilterFormat(publishedDate);
		if (dateAfter.equalsIgnoreCase(dateBefore)) {
			if (filterFormatDate.equalsIgnoreCase(dateBefore)) {
				isWithin = true; 
			}
		} else {
			int yearAfter = Integer.parseInt(dateAfter.substring(0, 4));
			int monthAfter = Integer.parseInt(dateAfter.substring(5, 7));
			int dayAfter = Integer.parseInt(dateAfter.substring(8, 10));
			
			int yearBefore = Integer.parseInt(dateBefore.substring(0, 4));
			int monthBefore = Integer.parseInt(dateBefore.substring(5, 7));
			int dayBefore = Integer.parseInt(dateBefore.substring(8, 10));
			
			int yearPublished = Integer.parseInt(filterFormatDate.substring(0, 4));
			int monthPublished = Integer.parseInt(filterFormatDate.substring(5, 7));
			int dayPublished = Integer.parseInt(filterFormatDate.substring(8, 10));
			
			boolean isAfter = false;
			boolean isBefore = false;
			if ((yearAfter == yearPublished && monthAfter == monthPublished && dayAfter <= dayPublished) || 
					(yearAfter == yearPublished && monthAfter < monthPublished) || 
						(yearAfter < yearPublished)) {
				isAfter = true;
			}
			if ((yearBefore == yearPublished && monthBefore == monthPublished && dayBefore >= dayPublished) || 
					(yearBefore == yearPublished && monthBefore > monthPublished) || 
						(yearBefore > yearPublished)) {
				isBefore = true;
			}
			
			if (isAfter && isBefore) {
				isWithin = true; 
			}
		}
		return isWithin;
	}
	
	public int getStatusValue() {
		if ("New".equalsIgnoreCase(this.status)) {
			return 100;
		} else if ("Not Applicable".equalsIgnoreCase(this.status)) {
			return 99;
		} else if ("Remediated".equalsIgnoreCase(this.status)) {
			return 98;
		} else if ("Reviewed".equalsIgnoreCase(this.status)) {
			return 97;
		} else if ("Work In Progress".equalsIgnoreCase(this.status)) {
			return 96;
		} else {
			return 0;
		}		
	}

}
