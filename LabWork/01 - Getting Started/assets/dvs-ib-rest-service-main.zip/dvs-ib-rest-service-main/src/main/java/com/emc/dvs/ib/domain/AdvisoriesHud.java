package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class AdvisoriesHud {

	private String severity;
	private String articles;
}
