package com.emc.dvs.ib.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class CodeLevelsProductBean {
	
	private String serialNumber;
	private String siteDisplayName;   
	private String targetCode;
	private String target1Code;
	private String productName;
	private String productFamily;    
	private String installedCode;
	private String codeLevelCategory;
	private String instanceNumber;
	@JsonIgnore
	private String ibStatus;
	private boolean serialNumberProductPage;
	private String productPageUrl;	
	private String lemcInstanceNumber;
}
