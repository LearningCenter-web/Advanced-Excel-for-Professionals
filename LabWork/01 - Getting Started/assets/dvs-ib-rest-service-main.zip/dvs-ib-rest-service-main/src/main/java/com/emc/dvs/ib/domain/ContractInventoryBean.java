package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class ContractInventoryBean {
	
	private String serialNumber;
	private String siteDisplayName;
	private String salesOrderNumber;
	private String contractNumber;
	private String productName;
	private String instanceNumber;
	private String lemcInstanceNumber;
	@JsonIgnore
	private String ibStatus;
	private boolean serialNumberProductPage;
	private String productPageUrl;
	@ExportDate(value="MMM d, yyyy")
	private Long contractEndDate;
	private String contractStatus;
	private String servicePlanLevel;

}

