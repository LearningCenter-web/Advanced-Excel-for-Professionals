package com.emc.dvs.ib.util;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;

public class CommonUtils {
	
	/**
	 * This method will take two localdate param and one long input date. Input long time converted in to date and compared with 
	 * passed dates.
	 * @param beforeDateConverted
	 * @param afterDateConverted
	 * @param inputDate
	 * @return
	 */
	public static boolean isDateInBetween(LocalDate beforeDateConverted,LocalDate afterDateConverted,Long inputDate,boolean isTimeRangeExist ) {
		if(inputDate == null) {
			return false;
		}
		// this condition will check timerange for timeline slider is not send and input date is not null then it will return true.
		if(!isTimeRangeExist) {
			return true;
		}
		LocalDate inputDateConverted = Instant.ofEpochMilli(inputDate).atZone(ZoneId.systemDefault()).toLocalDate();
		return (inputDateConverted.isAfter(afterDateConverted) && inputDateConverted.isBefore(beforeDateConverted)) || inputDateConverted.isEqual(afterDateConverted) || inputDateConverted.isEqual(beforeDateConverted)  ;
	}
	
	
	/**
	 * This method will convert milliseconds to only date and convert back to milliseconds
	 * @param epochMillisecond
	 * @return
	 */
	public static Long getOnlyDateMilli(Long epochMillisecond) {
		LocalDate inputDateConverted = Instant.ofEpochMilli(epochMillisecond).atZone(ZoneId.systemDefault()).toLocalDate();
		return inputDateConverted.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
	}
}
