package com.emc.dvs.ib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
//import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

import com.emc.ols.user.UserUtilConfig;

@SpringBootApplication
@EnableAsync
@Import({UserUtilConfig.class})
@EnableFeignClients
public class DvsIbRestServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DvsIbRestServiceApplication.class, args);
    }
    
    @Bean(name="restTemplate")
    public RestOperations restTemplate() {
    return new RestTemplate();
    }
    
}
