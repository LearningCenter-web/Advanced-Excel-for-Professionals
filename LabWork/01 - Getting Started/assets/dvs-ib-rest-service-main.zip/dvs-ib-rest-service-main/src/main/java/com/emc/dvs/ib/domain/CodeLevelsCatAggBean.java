package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CodeLevelsCatAggBean {
	
	private int totalSystems;
	private List<CodeLevelsProdFamilyAggBean> productFamilies;
	
	public List<CodeLevelsProdFamilyAggBean> getProductFamilies(){
		if (productFamilies == null){
			productFamilies = new ArrayList<CodeLevelsProdFamilyAggBean>();
		}
		return productFamilies;
	}
	
}
