package com.emc.dvs.ib.web;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.emc.dvs.export.domain.ColumnWrapper;
import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.service.InstallBaseService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ESRSController {
	
	private InstallBaseService installBaseService;
	
	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	public ESRSController(InstallBaseService installBaseService) {
		this.installBaseService = installBaseService;
	}
	
	/**
	 * This method updates the product alias for gateway and cluster. It stores the alias
	 * to aps db
	 * @param productAlias
	 * @param deviceId
	 * @param assetId
	 * @return
	 */
	@SneakyThrows
	@RequestMapping(value = "/esrsalias", method = RequestMethod.POST)
	public void editAliasForESRS(@RequestBody Map<String, Object> requestMap,
			HttpServletRequest request) {
			log.info("updating product alias {} for device id {}", requestMap);
		
			UserBean userBean = (UserBean) request.getAttribute("USER_BEAN");
			
			//Insert/ Update records in gateway/cluster_alias table after saving the alias
			installBaseService.insertAliasChangeForESRS(requestMap, userBean.getUid(), userBean.getFlname(), userBean.getIdentityType());
		}
	
	@RequestMapping(value = "/esrs", method = {RequestMethod.GET, RequestMethod.POST})
	public Map<String, EsrsBean> getEsrsData(@RequestParam Map<String, Object> filterParams) {
		return installBaseService.getEsrsData(filterParams);
	}
	
	/**
	 * This API returns all the connectivity change events such as nickname change for a particular cluster/gateway
	 * For a particular cluster, it also returns the change events for all the gateways within that cluster 
	 * @param request
	 * @param instanceNumber
	 * @return List<TimelineEntity>
	 */
	@RequestMapping(value = "/esrs/timeline", method = RequestMethod.GET)
	public List<TimelineEntity> getEsrsTimelineData(HttpServletRequest request, @RequestParam Map<String, Object> filterParams) {
		
		filterParams.put("size", Integer.parseInt(filterParams.getOrDefault("size", "50").toString()));

		log.debug("GET: Esrs change event data for deviceIds: ", filterParams.get("deviceId"));

		List<TimelineEntity> timelineEntities = new ArrayList<>();

		List<Map<String, Object>> changeEvents = installBaseService.getEsrsChangeEvent(filterParams);

		changeEvents.stream().forEach(changeEvent -> {
			if (changeEvent != null && changeEvent.containsKey("aliasChange")) {
				@SuppressWarnings("unchecked")
				List<Map<String, Object>> aliasChange = (List<Map<String, Object>>) changeEvent.get("aliasChange");
				aliasChange.stream().forEach(al -> {
					TimelineEntity alias = new TimelineEntity();
					alias.setEntityType("ALIAS_CHANGE");
					alias.setTimeStamp(Long.parseLong(al.get("updatedOn").toString()));
					alias.setEntity(al);
					timelineEntities.add(alias);
				});
			}
		});

		return timelineEntities;
	}
	
	/**
	 * This method returns the count of alias change events on the connectivity timeline
	 * @param request
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = "/esrsalias/count", method = RequestMethod.GET)
	public Long getEsrsAliasChange(HttpServletRequest request, @RequestParam Map<String, Object> filterParams) {
		return installBaseService.getEsrsAliasChangeCount(filterParams);
	}
	
	/**
	 * Returns txt/csv type of data for Export Dial Home services
	 * @param filterParams
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/downloadNicknameChangeData" }, method = { RequestMethod.GET, RequestMethod.POST }, produces = "text/csv")
	public void downloadNicknameChangeData(@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) throws Exception {

		filterParams.putIfAbsent("sortDir", "desc");		
		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);

		response.addHeader("Content-disposition", "attachment;filename=NicknameChanges_Export.csv");
		response.setContentType("txt/csv");
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getEsrsChangeEvent(out, filterParams, colWrapper.getColumns());
		}
	}
	
	/**
	 * This method returns the time range stats for ESRS alias change events
	 * @param filterParams
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/esrs/timeline/timerange", method = {RequestMethod.GET})
	public Map<Long, Integer> getEsrsTimeRangeStats(@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) {
		return installBaseService.getServiceEventsTimeRangeAliasChangeCount(filterParams);
	}
	
	/**
	 * This API returns a list of trident devices connected to a specific gateway/ cluster
	 * @param filterParams
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/trident/devices", method = {RequestMethod.GET})
	public List<Map<String, Object>> getTridentConnectedDevices(@RequestParam Map<String, Object> filterParams, HttpServletRequest request, HttpServletResponse response) {
		log.info("Returning a list of connected trident products for deviceId: {}", filterParams.get("deviceId"));
		return installBaseService.getTridentConnectedDevices(filterParams);
	}
	
	/**
	 * This API returns Trident connecthome event details
	 * @param filterParams
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/trident/connecthome", method = { RequestMethod.GET })
	public List<Map<String, Object>> getTridentConnectHomeEvents(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request, HttpServletResponse response) {
		return installBaseService.getTridentConnectHomeEvents(filterParams);
	}
	
	/**
	 * This method returns the aggregate response of gateway/cluster details
	 * where the trident devices are connected 
	 * @param filterParams
	 * @param request
	 * @param deviceId
	 * @return
	 */
	@RequestMapping(value = "/trident", method = {RequestMethod.GET})
	public EsrsDeviceGatewaysBean getTridentAggregateResponse(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		log.info("Returning aggregate response for deviceId: {}", filterParams.get("deviceId"));
		return installBaseService.getTridentAggregateResponse(filterParams);
	}
	
	/**
	 * This method returns all the gateway serial numbers present within a particular cluster id
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/trident/gatewayids", method = {RequestMethod.GET})
	public String getGatewayIdsWithinACluster(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		log.info("Returning gateway serial numbers connected to clusterId: {}", filterParams.get("deviceId"));
		return installBaseService.getGatewayIdsWithinACluster(filterParams);
	}
	
	/**
	 * This method returns the connectivity response for a particular install base serial number
	 * where the trident devices are connected 
	 * @param filterParams
	 * @param request
	 * @param deviceId
	 * @return
	 */
	@RequestMapping(value = "/trident/ib", method = {RequestMethod.GET})
	public Map<String, Object> getTridentInstallBaseResponse(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		if (!filterParams.containsKey("serialNumberIsIn")) {
			log.error("Throwing Bad Request exception as the request doesnt contain the serialNumberIsIn parameter");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "The request doesnt contain serialNumberIsIn parameter");
		}
		log.info("Returning connectivity response for IB serial number: {}", filterParams.get("serialNumberIsIn"));
		return installBaseService.getTridentInstallBaseResponse(filterParams);
	}
	
	/**
	 * This method returns the connectivity response for a multiple install base serial numbers
	 * where the trident devices are connected 
	 * @param filterParams
	 * @param request
	 * @param deviceId
	 * @return
	 */
	@RequestMapping(value = "/trident/ib/multi", method = {RequestMethod.GET})
	public List<Map<String, Object>> getTridentInstallBaseResponseMulti(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		if (!filterParams.containsKey("serialNumberIsIn")) {
			log.error("Throwing Bad Request exception as the request doesnt contain the serialNumberIsIn parameter");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "The request doesnt contain serialNumberIsIn parameter");
		}
		log.info("Returning connectivity response for IB serial number: {}", filterParams.get("serialNumberIsIn"));
		return installBaseService.getTridentInstallBaseResponseMulti(filterParams);
	}
	
	@RequestMapping(value = "/trident/esrs/insertconnecthome", method = {RequestMethod.POST})
	public ResponseEntity<String> insertConnectHomeData(@RequestBody Map<String, Object> filterParams, HttpServletRequest request) {
		if (CollectionUtils.isEmpty(filterParams)) {
			log.error("Throwing Bad Request exception as the request doesnt contain the any parameter");
			return ResponseEntity.badRequest().build();			
		}
		 installBaseService.insertConnectHomeData(filterParams);
		 return ResponseEntity.ok().build();	
	}
	
	@RequestMapping(value = "/trident/esrs/updateconnecthome", method = {RequestMethod.POST})
	public ResponseEntity<String> updateConnectHomeData(@RequestBody Map<String, Object> filterParams, HttpServletRequest request) {
		if (CollectionUtils.isEmpty(filterParams)) {
			log.error("Throwing Bad Request exception as the request doesnt contain the any parameter");
			return ResponseEntity.badRequest().build();			
		}
		 installBaseService.updateConnectHomeData(filterParams);
		 return ResponseEntity.ok().build();
	}
	
	@RequestMapping(value = "/esrs/updategatewaydata", method = {RequestMethod.POST})
	public ResponseEntity<String> updateDeviceOrGatewayData(@RequestBody List<Map<String, Object>> filterParams, HttpServletRequest request) {
		if (CollectionUtils.isEmpty(filterParams)) {
			log.error("Throwing Bad Request exception as the request doesnt contain the any parameter");
			return ResponseEntity.badRequest().build();			
		}
		 installBaseService.updateGatewayData(filterParams);
		 return ResponseEntity.ok().build();
	}
	
	@RequestMapping(value = "/esrs/updatedevicestatus", method = {RequestMethod.POST})
	public ResponseEntity<String> updateDeviceStatus(@RequestBody Map<String, Object> filterParams, HttpServletRequest request) {
		if (CollectionUtils.isEmpty(filterParams)) {
			log.error("Throwing Bad Request exception as the request doesnt contain the any parameter");
			return ResponseEntity.badRequest().build();			
		}
		 installBaseService.upsertEsrsDeviceStatus(filterParams);
		 return ResponseEntity.ok().build();
	}
}

