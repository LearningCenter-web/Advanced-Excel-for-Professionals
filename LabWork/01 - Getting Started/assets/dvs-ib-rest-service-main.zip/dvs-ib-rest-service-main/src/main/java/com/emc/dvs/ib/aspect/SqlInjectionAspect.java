package com.emc.dvs.ib.aspect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
public class SqlInjectionAspect {
	
	@Setter
	@Value("${sql.regex-db-operation}")
	private String regex;
	
	@Autowired
	@Setter
	private HttpServletRequest request;
	
	@Setter@Getter
	private List<String> dbparams = new ArrayList<>();
	@Before("(execution(* com.emc.dvs.ib.web.AdvisoriesController.getEsaAggregate(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.getRemediationStatus(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.downloadAffectedProducts(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.getEtaRemediationStatusForKpi(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.getEtaAffectedProductsForKpi(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.downloadEsaAggregate(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.getAffectedProductsForKpi(..))"
			+ "|| execution(* com.emc.dvs.ib.web.AdvisoriesController.getAffectedProducts(..)))")
	public Object validateSqlInjectionParams() {	
		log.info("Entered the run method in SQLINJECTIONASPECT");
		request.getParameterMap().entrySet()
			.stream()
			.filter(f -> dbparams.contains(f.getKey()))
			.forEach(f -> {
				List<String> params = Arrays.asList(f.getValue());
				params.forEach(s -> {
					Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
					Matcher m = p.matcher(s.toUpperCase());
					boolean matchesSqlCode= m.find();
					if(matchesSqlCode){
						log.error("Request rejected due to bad request parameters ");
						throw new HttpClientErrorException(HttpStatus.BAD_REQUEST); 
					}
				});
			});		
			
		return null;
	}
	
	
     
	
}
