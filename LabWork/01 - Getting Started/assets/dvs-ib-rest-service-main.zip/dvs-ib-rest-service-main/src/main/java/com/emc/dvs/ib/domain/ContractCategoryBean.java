package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class ContractCategoryBean {
	
	private String productFamily;
	private String contractExpiresCategory;
	
	
}
