package com.emc.dvs.ib.domain;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConnectHomeDurationBean {
	private String productFamily;
	private Long duration;
	private Date lastEmailSent;
	private boolean sendEmail;
	
	public boolean getSendEmail() {
		return this.sendEmail;
	}
}
