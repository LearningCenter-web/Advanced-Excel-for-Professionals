package com.emc.dvs.ib.persistance;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;

import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectHomeDurationBean;
import com.emc.dvs.ib.domain.ConnectivityAggBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractInventoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.Entitlement;
import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsChangeEventBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.domain.GatewayBean;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseProductBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.ProductSiteChangeBean;
import com.emc.dvs.ib.domain.SiteBean;

@Mapper
@CacheConfig(cacheNames = { "ib" })
@SuppressWarnings("rawtypes")
public interface InstallBaseMapper {

	@Cacheable(key = "'ib:currentPartition'")
	public Integer getCurrentPartitionId();
	
	@Cacheable(key = "'ib:currentPartitions'")
	public List<String> getCurrentPartitions();

	public InstallBaseFilterValuesBean getInstallBaseAllFilterValues(Map<String, Object> filterParams);

	public List<String> getInstallBaseSerialNumbers(Map<String, Object> filterParams);
	
	public List<String> getInstallBaseInstanceNumbers(Map<String, Object> filterParams);

	public List<String> getInstallBaseProductNames(Map<String, Object> filterParams);

	public List<String> getContractStatus(Map<String, Object> filterParams);

	public InstallBaseStatsBean getInstallBaseStats(Map<String, Object> filterParams);

	public List<InstallBaseGeoBean> getInstallBaseGeoDetails(Map<String, Object> filterParams);

	public List<ConnectivityAggBean> getConnectivityAggregate(Map<String, Object> filterParams);

	public Integer getConnectivityTotalRecord(Map<String, Object> filterParams);

	public List<ConnectivityProductBean> getConnectivityList(Map<String, Object> filterParams);
	
	public void getConnectivityList(ResultHandler handler, Map<String, Object> filterParams);

	public List<CodeLevelsAggBean> getCodeLevelsAggregate(Map<String, Object> filterParams);

	public Integer getCodeLevelsTotalRecord(Map<String, Object> filterParams);

	public List<CodeLevelsProductBean> getCodeLevelsProducts(Map<String, Object> filterParams);

	public void getCodeLevelsProducts(ResultHandler handler, Map<String, Object> filterParams);

	public List<ContractCategoryBean> getContractCategoryAggregate(Map<String, Object> filterParams);

	public Integer getContractTimelineTotal(Map<String, Object> filterParams);

	public List<ContractTimelineBean> getContractTimeline(Map<String, Object> filterParams);

	public Integer getContractInventoryTotal(Map<String, Object> filterParams);

	public List<ContractInventoryBean> getContractInventory(Map<String, Object> filterParams);

	public void getContractInventory(ResultHandler handler, Map<String, Object> filterParams);

	public List<ProductBean> getProductDetail(Map<String, Object> filterParams);
	
	public void insertContractRenewalRecord(@Param(value = "uid") String uid,
			@Param(value = "serialNumber") String serialNumber, @Param(value = "contractEndDate") Long contractEndDate);

	public InstallBaseProductBean getInstallBaseProduct(@Param(value = "partitionId") int partitionId,
			@Param(value = "instanceNumber") String instanceNumber);

	public void updateInstallBaseProduct(@Param("id") Long id, @Param(value = "partitionId") int partitionId,
			@Param(value = "data") String data);

	public Integer getProductsTotal(Map<String, Object> filterParams);

	public void getProductDetail(ResultHandler handler, Map<String, Object> filterParams);

	public ProductSiteChangeBean getSiteChangeEvent(@Param(value = "siteNumber") String siteNumber);

	public void updateSiteChangeEvent(@Param(value = "siteNumber") String siteNumber,	@Param(value = "data") String data);

	public void insertSiteChangeEvent(@Param(value = "siteNumber") String siteNumber, @Param(value = "data") String data);
	
	public ProductSiteChangeBean getProductChangeEvent(@Param(value = "instanceNumber") Long instanceNumber);
	
	public List<EsrsChangeEventBean> getEsrsChangeEvent(Map<String, Object> filterParams);
	
	public void updateProductChangeEvent(@Param(value = "instanceNumber") Long instanceNumber, @Param(value = "data") String data);
	
	public void insertProductChangeEvent(@Param(value = "instanceNumber") Long instanceNumber, @Param(value = "data") String data);
	
	public void updateEsrsChangeEvent(@Param(value = "deviceId") String deviceId, @Param(value = "data") String data);
	
	public void insertEsrsChangeEvent(@Param(value = "deviceId") String deviceId, @Param(value = "data") String data);
	
	public List<ComponentBean> getSolutionComponents(Map<String, Object> filterParams);
	
	public void getSolutionComponents(ResultHandler handler,Map<String, Object> filterParams);
	
	public void getContractRenewal(ResultHandler handler, Map<String,Object> filterParams);
	
	public void getAliasChanges(ResultHandler handler, Map<String,Object> filterParams);
	
	public void getLocationChanges(ResultHandler handler, Map<String,Object> filterParams);

	public List<Map<String, Object>> getChangesAndSubmissionsStats(Map<String, Object> filterParams);
	
	public List<EsrsBean> getEsrsData(@Param(value = "deviceId") String deviceId);
	
	public void insertEsrsdata(@Param(value = "id") String id, @Param(value = "data") String data);
	
	public void updateEsrsData(@Param(value = "id") String id, @Param(value = "data") String data);

	public List<Map<String, Object>> getChangesAndSubmissionTimelineRangeEventCount(Map<String, Object> filterParams);
	
	public Long getEsrsAliasChangeCount(Map<String, Object> filterParams);
	
	public void getEsrsChangeEventForExport(ResultHandler handler, Map<String,Object> filterParams);
	
	public List<Map<String, Object>> getServiceEventsTimeRangeAliasChangeCount(Map<String,Object> filterParams);
	
	public ConnectHomeDurationBean getConnectHomeDuration(@Param(value = "productFamily") String productFamily);
	
	public void insertConnectHomeDuration(@Param(value = "connectHomeDuration") ConnectHomeDurationBean connectHomeDuration);
	
	public void updateLastEmailSentDuration(@Param(value = "productFamily") String productFamily);
	
	public List<SiteBean> getSiteDetails(Map<String,Object> filterParams);
	
	public List<Map<String, Object>> getTridentConnectedDevices(Map<String, Object> filterParams);
	
	public List<Map<String, Object>> getTridentConnectHomeEvents(Map<String, Object> filterParams);

	public EsrsDeviceGatewaysBean getTridentAggregateResponse(Map<String, Object> filterParams);
	
	public List<GatewayBean> getTridentGatewayDetails(Map<String, Object> filterParams);
	
	public String getGatewayIdsWithinACluster(Map<String, Object> filterParams);
	
	public List<Map<String, Object>> getTridentInstallBaseResponse(Map<String, Object> filterParams);
	
	public List<Entitlement> getWarranties(@Param(value = "serialNumber") String serialNumber);
	
	public void insertConnectHomeData(Map<String, Object> params);
	
	public void updateConnectHomeData(Map<String, Object> params);
	
	public int deleteDeviceData(Map<String, Object> params);
	
	public void insertDeviceData(List<Map<String, Object>> params);
	
	public void updateEsrsDeviceStatus(Map<String, Object> params);
}
