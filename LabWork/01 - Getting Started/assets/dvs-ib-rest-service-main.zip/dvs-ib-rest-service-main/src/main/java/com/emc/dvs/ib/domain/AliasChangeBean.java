package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class AliasChangeBean {
	private String userName;
	private String newAlias;
	@ExportDate(value="MMM d, yyyy HH:mm:ss")
	private Long updateDate;
}
