package com.emc.dvs.ib.web;


import com.emc.dvs.ib.service.InstallBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("singleSerialization")
public class AssetMigrationController {

    @Autowired
    private InstallBaseService installBaseService;

    @PostMapping("assetMigration")
    public ResponseEntity moveSsdataToPgsql(@RequestBody List<Object> sdata) {
        long startTime = System.nanoTime();
        installBaseService.saveSingleSerializedAsset(sdata);
        long elapsedTime = System.nanoTime() - startTime;

        System.out.println("Total execution time to migrate assets to postgress in Java in millis: " + elapsedTime/1000000);
        return ResponseEntity.ok("Asset data move to pgsql (asset_ss and IB_)  tables transferred successfully.");
    }

}
