package com.emc.dvs.ib.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum EtaResolutionTracking {
	NOT_SCHEDULED("Not Scheduled"),
	SCHEDULED_FOR_ACTION("Scheduled For Action"),
	RESOLUTION_COMPLETED("Resolution Completed"),
	NOT_APPLICABLE("Not Applicable"),
	WORKAROUND_APPLIED("Work-around Applied");
	
	private String resolution;
	
	 EtaResolutionTracking(String resolution){
		  this.resolution = resolution;
	}
	 
	public String getResoution() {
		return resolution;
	}
	
	  private static final Map<String, EtaResolutionTracking> lookup = new HashMap<>();
	  static {
	    for (EtaResolutionTracking resln : EnumSet.allOf(EtaResolutionTracking.class))
	      lookup.put(resln.getResoution(), resln);
	  }
	  
	  public static String get(String resolution) {
		    return lookup.get(resolution).toString();
		  }
}
