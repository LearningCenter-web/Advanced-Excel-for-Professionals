package com.emc.dvs.ib.service;

import java.util.Map;

//import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.emc.dvs.ib.config.HttpStreamServiceFallbackFactory;

@FeignClient(name = "dvs-stream-source-http", value="dvs-stream-source-http", url="${dvs.services.httpStream}", fallbackFactory = HttpStreamServiceFallbackFactory.class)
public interface HttpStreamService {
	
	@RequestMapping(value="/productalias", method = RequestMethod.POST, consumes = { "application/json" })
	public void updateProductAlias(@RequestBody Map<String, Object> body);
	
	@RequestMapping(value="/sitechangeevent", method = RequestMethod.POST, consumes = { "application/json" })
	public void siteChangeEvent(@RequestBody Map<String, Object> body);
	
	@RequestMapping(value="/productchangeevent", method = RequestMethod.POST, consumes = { "application/json" })
	public void productChangeEvent(@RequestBody Map<String, Object> body);
	
	@RequestMapping(value = "/renewcontract", method = RequestMethod.POST, consumes = { "application/json"} )
	public void renewContract(@RequestBody Map<String, Object> body);

}
