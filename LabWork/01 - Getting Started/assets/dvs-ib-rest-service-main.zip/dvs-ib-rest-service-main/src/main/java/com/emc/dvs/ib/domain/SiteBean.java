package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class SiteBean {
	
	private String siteNumber;
	private String ucid;
	@SuppressWarnings("unused")
	private String siteDisplayName;
	private String siteName;
	private String globalDunsNumber;
	private String longitude;
	private String latitude;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipCode;
	private String country;
	private String countryCode;
	
	public String getSiteDisplayName() {
		return siteNumber + ", " + siteName;
	}
	

}
