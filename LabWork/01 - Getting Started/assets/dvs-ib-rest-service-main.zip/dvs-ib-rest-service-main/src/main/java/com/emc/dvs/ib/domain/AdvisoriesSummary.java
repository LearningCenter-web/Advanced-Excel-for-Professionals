package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class AdvisoriesSummary {

	private String products;
	private String title;
	private String documentId;
	private String age;
	private String severity;
	private String productFamily;
	private List<String> productFamilyList;
	@JsonIgnore
	private String productFamilyString;
	private String status;
	private String articleId;
	private long published;
	private long firstPublished;
	private boolean updated;
	private String siteNumber;
	private String latitude;
	private String longitude;
	private String siteName;
	private String city;
	
	public void setProductFamilyString(String productFamilyString) {
		this.productFamilyString = productFamilyString;
		if (StringUtils.hasText(productFamilyString)) {
			this.productFamilyList = Arrays.asList(productFamilyString.split("\\|"));
		} else {
			this.productFamilyList = new ArrayList<>();
		}
	}
}
