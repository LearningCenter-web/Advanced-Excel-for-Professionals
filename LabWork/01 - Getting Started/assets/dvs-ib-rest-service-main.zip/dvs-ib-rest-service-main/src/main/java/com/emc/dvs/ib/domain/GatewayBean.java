package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class GatewayBean {
	
	private String gatewayModelName;
	private String siteNumber;
	private String gatewayId;
	private String alias;
	private List<String> gatewayDeviceStatuses;
	private Long gatewayLastContactDate;
	private Long deviceLastConnectHomeDate;
	private List<String> esrsVersions;
	
	@JsonIgnore
	private String esrsVersion;
	
	@JsonIgnore
	private String gatewayDeviceStatus;
	
	public void setesrsVersion(String esrsVersion){
		this.esrsVersion=esrsVersion;
		if(StringUtils.hasText(esrsVersion)) {
			this.esrsVersions = Arrays.asList(esrsVersion.split("\\|"));
		}
		else {
			this.esrsVersions = new ArrayList<String>();
		}
	}
	
	public void setGatewayDeviceStatus(String gatewayDeviceStatus) {
		this.gatewayDeviceStatus = gatewayDeviceStatus;
		if(StringUtils.hasText(gatewayDeviceStatus)) {
			this.gatewayDeviceStatuses = Arrays.asList(gatewayDeviceStatus.split("\\|"));
		}
		else {
			this.gatewayDeviceStatuses = new ArrayList<String>();
		}
	}

}
