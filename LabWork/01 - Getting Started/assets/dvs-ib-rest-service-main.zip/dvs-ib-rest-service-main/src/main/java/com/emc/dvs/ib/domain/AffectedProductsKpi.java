package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class AffectedProductsKpi {

	private String region;
	private String critical;
	private String high;
	private String medium;
	private String low;
	private String productCount;
}
