package com.emc.dvs.ib.domain;

import lombok.Getter;
import lombok.Setter;

public class SiteSearch {

	@Setter@Getter
	private String loginID;
	@Setter@Getter
	private String searchText;
}
