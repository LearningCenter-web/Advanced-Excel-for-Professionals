package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class SerializedProductCountsBean {
	private String severity;
	private int severityCount;
	private String advisoryStatus;
}
