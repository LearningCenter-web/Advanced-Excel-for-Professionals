package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class SerializedAdvisoryEvent {
	private String status;
	private String lastUpdatedBy;
	private String lastUpdatedDate;
	private String articleId;
	private String articleNumber;
	private String instanceNumber;
}
