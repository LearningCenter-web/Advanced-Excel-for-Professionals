package com.emc.dvs.ib.persistance;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.cache.annotation.CacheConfig;

import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.SerializedAdvisoryEvent;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.SerializedProductBean;
import com.emc.dvs.ib.domain.SerializedProductCountsBean;

@Mapper
@CacheConfig(cacheNames = { "adv" })
@SuppressWarnings("rawtypes")
public interface AdvisoriesMapper {

	public List<AdvisoryBean> getEsaAggregate(Map<String, Object> filterParams);

	public List<Map<String, Object>> getEsaInstanceMap(Map<String, Object> filterParams);
	
	public Map<String, Object> getIbInstanceMap(Map<String, Object> filterParams);

	public Integer getEsaAggregateTotalRecord(Map<String, Object> filterParams);

	public void getEsaAggregate(ResultHandler handler, Map<String, Object> filterParams);

	public List<AffectedProductsBean> getAffectedProducts(Map<String, Object> filterParams);

	public void getAffectedProducts(ResultHandler resultHandler, Map<String, Object> filterParams);

	public List<AdvisoryBean> getArticles(Map<String, Object> filterParams);

	public List<AffectedProductsKpi> getAffectedProductsForKpi(Map<String, Object> filterParams);

	public List<AdvisoryBean> getEtaAggregate(Map<String, Object> filterParams);

	public Integer getEtaAggregateTotalRecord(Map<String, Object> filterParams);

	public List<Map<String, Object>> getEtaInstanceMap(Map<String, Object> filterParams);

	public void getEtaAggregate(ResultHandler handler, Map<String, Object> filterParams);

	public List<AffectedProductsBean> getEtaAffectedProducts(Map<String, Object> filterParams);

	public void getEtaAffectedProducts(ResultHandler resultHandler, Map<String, Object> filterParams);

	public List<AdvisoryBean> getEtaArticles(Map<String, Object> filterParams);

	public List<AffectedProductsKpi> getEtaAffectedProductsForKpi(Map<String, Object> filterParams);

	public AdvisoryBean getTechAdvisoryDetail(Map<String, Object> filterParams);

	public AdvisoryBean getSecAdvisoryDetail(Map<String, Object> filterParams);

	public List<Note> getEsaNotes(Map<String, Object> filterParams);

	public List<Note> getEtaNotes(Map<String, Object> filterParams);

	public List<IpsNote> getEsaNotesSerialized(Map<String, Object> filterParams);

	public List<IpsNote> getEtaNotesSerialized(Map<String, Object> filterParams);

	public List<AdvisoriesHud> getDsaHud(Map<String, Object> filterParams);
	
	public List<AdvisoriesHud> getDtaHud(Map<String, Object> filterParams);

	public List<SerializedProductBean> getEsaSerialized(Map<String, Object> filterParams);
	
	public List<SerializedProductBean> getEtaSerialized(Map<String, Object> filterParams);
	
	public List<SerializedProductBean> getEsaForProduct(Map<String, Object> filterParams);
	
	public List<SerializedProductBean> getEtaForProduct(Map<String, Object> filterParams);
	
	public Integer getESASerializedTotalRecord(Map<String, Object> filterParams);
	
	public Integer getETASerializedTotalRecord(Map<String, Object> filterParams);
	
	public List<SerializedProductCountsBean> getEsaSerializedCounts(Map<String, Object> filterParams);
	
	public List<SerializedProductCountsBean> getEtaSerializedCounts(Map<String, Object> filterParams);
	
	public List<AdvisoriesSummary> getEsaSummary(Map<String, Object> filterParams);
	
	public List<AdvisoriesSummary> getEtaSummary(Map<String, Object> filterParams);
	
	public List<AdvisoryBean> getEtaTimeline(Map<String, Object> filterParams);
	
	public List<AdvisoryBean> getEsaTimeline(Map<String, Object> filterParams);
	
	public Integer getEtaEventsCount(Map<String, Object> filterParams);
	
	public Integer getEsaEventsCount(Map<String, Object> filterParams);
	
	public Integer getEsaMarkAsReviewedCount(Map<String, Object> filterParams);
	
	public Integer getEtaMarkAsReviewedCount(Map<String, Object> filterParams);
	
	public List<SerializedAdvisoryEvent> getEsaEventsSerialized(Map<String, Object> filterParams);
	
	public List<SerializedAdvisoryEvent> getEtaEventsSerialized(Map<String, Object> filterParams);
	
	public Integer getDsaCount(Map<String, Object> filterParams);
	
	public Integer getDtaCount(Map<String, Object> filterParams);

	public String getProductNames(Map<String, Object> filterParams);

}
