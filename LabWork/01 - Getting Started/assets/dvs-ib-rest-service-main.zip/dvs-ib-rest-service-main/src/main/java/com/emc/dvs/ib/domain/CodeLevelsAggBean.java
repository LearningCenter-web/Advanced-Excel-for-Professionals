package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class CodeLevelsAggBean {
	
	private String category;
	private String productFamily;
	private int codeReleases;
	private int systems;
	
}
