package com.emc.dvs.ib.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.emc.dvs.ib.domain.SiteSearch;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RefreshScope
@ConfigurationProperties(prefix="dvs.services")
@Service
public class AccountServiceImpl implements AccountService {
	
	@Setter
	private String accountBaseUri;
	
	@Setter
	private String siteSearch;
	
	
	private RestTemplate restTemplate;
	
	@Autowired
	public AccountServiceImpl(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
			
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public  List<Object> getSiteDetails(String siteNumber,String uid) {
		String uri = accountBaseUri + siteSearch;
		HttpHeaders headers = new HttpHeaders();
		headers.add("x-api-version", "2.0");
		
		ResponseEntity<Map> webSupportResponse = null;
		Map<String, Object> response = new HashMap<>();
		
		SiteSearch siteLogin=new SiteSearch();
		siteLogin.setLoginID(uid);
		siteLogin.setSearchText(siteNumber);
		webSupportResponse = restTemplate.exchange(uri, HttpMethod.POST, new HttpEntity<>(siteLogin,headers),Map.class);		
		
		response = webSupportResponse.getBody();
		if (response!=null && (!response.containsKey("content") || null != response.get("content"))) {
		  Map<String,Object> content = (Map<String,Object>)response.get("content");
		  List<Object> sites =(List<Object>) content.get("SiteList");
		  return sites;
		}else {
			  log.error("Invalid Response from Customer Partner Site {}, {}", uri, uid);
			  return new ArrayList<Object>();
		}	
	}
	
}
