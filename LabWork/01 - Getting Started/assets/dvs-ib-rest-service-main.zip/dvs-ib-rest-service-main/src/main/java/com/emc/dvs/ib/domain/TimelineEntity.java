package com.emc.dvs.ib.domain;

import java.util.Map;

import lombok.Data;

@Data
public class TimelineEntity {
	private String entityType;
	private Long timeStamp;
	private Map<String,Object> entity;
}

