/*
 * package com.emc.dvs.ib.aspect;
 * 
 * import org.aspectj.lang.ProceedingJoinPoint; import
 * org.aspectj.lang.annotation.Around; import
 * org.aspectj.lang.annotation.Aspect; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.beans.factory.annotation.Qualifier; import
 * org.springframework.core.Ordered; import
 * org.springframework.core.annotation.Order; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.security.oauth2.client.OAuth2RestOperations; import
 * org.springframework.stereotype.Component; import
 * org.springframework.web.client.HttpClientErrorException;
 * 
 * import lombok.SneakyThrows; import lombok.extern.slf4j.Slf4j;
 * 
 * @Component
 * 
 * @Aspect
 * 
 * @Order(Ordered.HIGHEST_PRECEDENCE)
 * 
 * @Slf4j public class SfdcRestAuthAspect {
 * 
 * @Autowired
 * 
 * @Qualifier("sfdcRestTemplate") private OAuth2RestOperations restTemplate;
 * 
 *//**
	 * Aspect to refresh SFDC Auth token and attempt a refresh when Unauthorized is
	 * returned The username and password flow does not allow token refresh so this
	 * is needed as a workaround
	 * 
	 * The Aspect needs to be on RestOperations and not OAuth2RestOperations.
	 * 
	 * @param pjp
	 * @return
	 *//*
		 * @SneakyThrows
		 * 
		 * @Around("execution(* org.springframework.web.client.RestOperations+.*(String, ..))"
		 * ) public Object handleAuthExpiration(ProceedingJoinPoint pjp) { try { return
		 * pjp.proceed(); } catch (HttpClientErrorException ex) {
		 * if(HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
		 * log.info("OAuth token has expired - attempting a refresh"); //Spring thinks
		 * it has a valid token - set the token to null to force a refresh from the
		 * server restTemplate.getOAuth2ClientContext().setAccessToken(null);
		 * restTemplate.getAccessToken(); return pjp.proceed(); } else {
		 * log.error("SFDC error: {} : {}", ex.getStatusCode(),
		 * ex.getResponseBodyAsString()); throw ex; } } }
		 * 
		 * }
		 */