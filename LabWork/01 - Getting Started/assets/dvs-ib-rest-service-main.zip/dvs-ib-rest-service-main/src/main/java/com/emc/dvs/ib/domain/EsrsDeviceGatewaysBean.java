package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class EsrsDeviceGatewaysBean {
	
	private String clusterGroupName;
	private String gatewayModelName;
	private String customerName;
	private String alias;
	private String siteNumber;
	private String clusterId;
	private String gatewayId;
	private List<String> gatewayDeviceStatuses;
	private Long gatewayLastContactDate;
	private Long deviceLastConnectHomeDate;
	private List<GatewayBean> gatewayDetails;
	private List<String>  esrsVersions;
	private boolean validConfiguration = true;
	
	@JsonIgnore
	private String instanceNumbers;
	
	@JsonIgnore
	private String city;
	
	@JsonIgnore
	private String country;
	
	@JsonIgnore
	private String esrsVersion;
	
	@JsonIgnore
	private String gatewayDeviceStatus;
	
	public void setesrsVersion(String esrsVersion){
		this.esrsVersion=esrsVersion;
		if(StringUtils.hasText(esrsVersion)) {
			this.esrsVersions = Arrays.asList(esrsVersion.split("\\|"));
		}
		else {
			this.esrsVersions = new ArrayList<String>();
		}
	}
	
	public void setGatewayDeviceStatus(String gatewayDeviceStatus) {
		this.gatewayDeviceStatus = gatewayDeviceStatus;
		if(StringUtils.hasText(gatewayDeviceStatus)) {
			this.gatewayDeviceStatuses = Arrays.asList(gatewayDeviceStatus.split("\\|"));
		}
		else {
			this.gatewayDeviceStatuses = new ArrayList<String>();
		}
	}

}
