package com.emc.dvs.ib.util;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.emc.dvs.ib.exception.AccessException;
import com.emc.dvs.ib.service.AccountService;
import com.esotericsoftware.minlog.Log;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SiteRelationService {	
	
	private AccountService accountService;
	
	@Autowired
	public SiteRelationService(AccountService accountService) {		
		this.accountService = accountService;
	}

	public String getSiteRelationShip(String siteNumber, String deviceId, String uid, String loginName) {	
		List<Object> res=accountService.getSiteDetails(siteNumber, loginName);		
			Log.info("Sites-CustomerPartner"+res.get(0));
			if(res.size() == 0 || res.isEmpty()) {
				log.error("API access denied to device: {} for {}", deviceId, loginName);
				throw new AccessException();
			}
			Map<String,Object> sites=(Map<String,Object>) res.get(0);
			Boolean relCon=sites.containsKey("Relation");
			if(!relCon) {
				log.error("API access denied to device: {} for {}", deviceId, loginName);
				throw new AccessException();
			}
			return (String) sites.get("Relation");	
	}
		
}
