package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class InstallBaseStatsBean {
	
	private int total; //total is Serialized only	
	private int connected;
	private int notConnectedEligible;
	private int connectedPercent;
	private int expired;
	private int partsReplacement;

}
