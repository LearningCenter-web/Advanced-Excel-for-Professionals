package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class ProductBean {
	
	private String serialNumber;
	private String instanceNumber;
	private String instanceId;
	private String productName;
	private String productFamily;
	private String productType;
	private String ibStatus;
	private String siteNumber;
	private String siteDisplayName;
	private String siteName;
	private String longitude;
	private String latitude;
	private String address1;
	private String address2;
	private String city;
	private String country;
	private String countryCode;
	private String contractNumber;
	private String salesOrderNumber;
	@ExportDate(value="MMM d, yyyy", convertToLocal = false)
	private Long contractEndDate;
	private Long contractStartDate;
	private String contractExpiresCategory;
	private String contractStatus;
	private String connectionType;
	private String lastConnectHome;
	private String connectFlag;
	private String largeProductImageUrl;
	private String productAlias;
	private boolean convergedComponent;
	private boolean convergedInfrastructure;
	private String globalDunsNumber;
	private Long contractRenewalDate;
	private String installDateAge;
	@ExportDate(value="MMM d, yyyy", convertToLocal = false)
	private Long eops;
	@ExportDate(value="MMM d, yyyy", convertToLocal = false)
	private Long eosl;		
	private String productPageUrl;
	private boolean serialNumberProductPage;
	private String connectionAge;
	private String t3Id;
	private String assetId;
	private String zipCode;
	private String state;
	private String province;
	private String locationUpdatedBy;
	private Long locationUpdatedOn;
	private String theater;
	@ExportDate(value="MMM d, yyyy")
	private Long shipDate;
	@ExportDate(value="MMM d, yyyy")
	private Long purchaseDate;
	private String installDate;
	private String servicePlanLevel;
	private String serviceProvider;
	private String supportStrategy;
	private String ciSolutionSerialNumber;
	private Integer partsCount;
	private boolean federalAccount;
	private String esrsVersion;
	private String deviceStatus;
	private String gatewayDeviceStatusList;
	private boolean clusterConnection;
	private String lastContactDate;
	private String clusterGroupName;
	private Long clusterDeviceId;
	private String lastConnectedGatewaySerial;
	@ExportDate(value="MMM d, yyyy")
	private Long installDateLong;
	private String optimizedStorageContractNumber;
	private String optimizedStorageContractType;
	private Long optimizedStorageContractStartDate;
	private Long optimizedStorageContractEndDate;
	private String optimizedStorageFlag;
	private String optimizedStorageContractStatus;
	private String optimizedStorageContractExpiresCategory;
	private Long refreshEquipmentRenewalDate;
	private Long optimizedStorageRenewalDate;
	private String contractRenewalAction;
	private String refreshEquipmentRenewalAction;
	private String optimizedStorageRenewalAction;
	private String installedCode;
	private String targetCode;
	private String target1Code;
	private boolean cphc;
	private String contractSubmittedBy;
	private String optimizedStorageContractSubmittedBy;
	private String refreshEquipmentContractSubmittedBy;
	private String ciSolutionProductName;
	private String lemcInstanceNumber;
	private Long connectHomeStatusDuration; 
	public void setConnectionAge(String connectionAge) {
		this.connectionAge = formatDate(connectionAge);
	}
	
	public void setInstallDateAge(String installDateAge) {
		this.installDateAge = formatDate(installDateAge);
	}
	
	private String formatDate(String date){
		return date.replace(" 0 years,", "").replace(" 1 years,", " 1 year,").replace(" 0 months,", "").replace(" 1 months,", " 1 month,").replace(" 0 days", "").replace(" 1 days", " 1 day").trim().replaceAll(",$", "");
	}
}
