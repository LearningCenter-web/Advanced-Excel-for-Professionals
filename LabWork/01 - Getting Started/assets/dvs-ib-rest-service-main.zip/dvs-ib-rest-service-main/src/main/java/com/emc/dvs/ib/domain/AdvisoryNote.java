package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class AdvisoryNote {

	private String instanceId;
	private String updatedBy;
	private String resolution;
	@ExportDate(value = "d MMM yyyy, hh:mm a")
	private Long dateUpdated;
	private String email;
	private String note;
	private String role;
	private String company;
	private boolean showNote;

}
