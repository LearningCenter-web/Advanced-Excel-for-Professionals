package com.emc.dvs.ib.service;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractInventoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.EsrsBean;
import com.emc.dvs.ib.domain.EsrsDeviceGatewaysBean;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.MilestoneStatsBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.SiteBean;
import com.emc.dvs.ib.domain.WarrantyResponse;

public interface InstallBaseService {
	
	public Future<InstallBaseFilterValuesBean> getInstallBaseFilterValues(Map<String, Object> filterParams);
	public List<String> getSerialNumbers(Map<String, Object> filterParams);
	public Future<List<String>> getProductNames(Map<String, Object> filterParams);
	public Future<List<String>> getContractStatus(Map<String, Object> filterParams);
	public List<String> getInstanceIds(Map<String, Object> filterParams);
	
	public Future<InstallBaseStatsBean> getInstallBaseStats(Map<String, Object> filterParams);
	
	public Future<List<InstallBaseGeoBean>> getInstallBaseGeoDetails(Map<String, Object> filterParams);
	
	public Future<Map<String, Object>> getConnectivityAggregate(Map<String, Object> filterParams);
	public Future<Integer> getConnectivityTotalRecord(Map<String, Object> filterParams);
	public Future<List<ConnectivityProductBean>> getConnectivityList(Map<String, Object> filterParams);
	public void getConnectivityList(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
		
	public List<CodeLevelsAggBean> getCodeLevelsAggregate(Map<String, Object> filterParams);
	public Future<Integer> getCodeLevelsTotalRecord(Map<String, Object> filterParams);
	public Future<List<CodeLevelsProductBean>> getCodeLevelsProducts(Map<String, Object> filterParams);
	public void getCodeLevelsProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	
	public List<ContractCategoryBean> getContractCategoryAggregate(Map<String, Object> filterParams);
	public Future<Integer> getContractTimelineTotal(Map<String, Object> filterParams);
	public Future<List<ContractTimelineBean>> getContractTimeline(Map<String, Object> filterParams);
	public Future<Integer> getContractInventoryTotal(Map<String, Object> filterParams);
	public Future<List<ContractInventoryBean>> getContractInventory(Map<String, Object> filterParams);
	public void getContractInventory(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	public ProductBean getProductDetail(Map<String, Object> filterParams);
	public MilestoneStatsBean getMilestoneStats(Map<String, Object> filterParams);
	public int getCurrentPartitionId();
	
	public Map<String, Object> insertContractRenewalRecord(Map<String, Object> contractDetails, String uid, String userName, String userIdentityType);
	
	public void insertSiteChangeEvent(Map<String, Object> reuestMap, String uid, String userName, String userIdentityType);
	public void insertProductChangeEvent(Map<String, Object> siteDetails, String uid, String userName, String userIdentityType);
	public void insertAliasChangeEvent(Map<String, Object> aliasDetails, String uid, String userName, String newAliasName, String userIdentityType);
	
	public void insertAliasChangeForESRS(Map<String, Object> aliasDetails, String uid, String userName, String userIdentityType);
	
	public Future<Integer> getProductsTotal(Map<String, Object> filterParams);
	public Future<List<ProductBean>> getProducts(Map<String, Object> filterParams);
	public void getProducts(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	
	public Map<String, Object> getProductChangeEvent(Long instanceNumber);
	
	public List<Map<String, Object>> getEsrsChangeEvent(Map<String, Object> filterParams);
	
	public void getEsrsChangeEvent(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	
	public List<ComponentBean> getSolutionComponents(Map<String, Object> filterParams);
	
	public void getSolutionComponents(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	
	public void getContractRenewal(OutputStream out, Map<String, Object> filterParams, List<Column> cols);
	
	public void getAliasChanges(OutputStream out, Map<String, Object> filterParams,List<Column> columns);
	
	public void getLocationChanges(OutputStream out, Map<String, Object> filterParams,List<Column> columns);
	
	public Map<String, Object> getChangesAndSubmissionsStats(Map<String, Object> filterParams);
	
	public Map<String, EsrsBean> getEsrsData(Map<String, Object> filterParams);
	
	public Map<Long, Integer> getMilestonesTimelineRangeEventCount(Map<String, Object> filterParams);
	public Map<Long, Integer> getChangesAndSubmissionTimelineRangeEventCount(Map<String, Object> filterParams);
	
	public Long getEsrsAliasChangeCount(Map<String, Object> filterParams);
	
	public Map<Long, Integer> getServiceEventsTimeRangeAliasChangeCount(Map<String,Object> filterParams);
	
	public List<SiteBean> getSiteDetails(Map<String, Object> params);
	
	public List<Map<String, Object>> getTridentConnectedDevices(Map<String, Object> filterParams);
	
	public List<Map<String, Object>> getTridentConnectHomeEvents(Map<String, Object> filterParams);

	public EsrsDeviceGatewaysBean getTridentAggregateResponse(Map<String, Object> filterParams);
	
	public String getGatewayIdsWithinACluster(Map<String, Object> filterParams);
	
	public Map<String, Object> getTridentInstallBaseResponse(Map<String, Object> filterParams);
	
	public List<Map<String, Object>> getTridentInstallBaseResponseMulti(Map<String, Object> filterParams);
	
	public Long getConnectHomeStatusDuration(String productFamily);
	
	public WarrantyResponse getWarranties(String serialNumber);
	
	public void saveSingleSerializedAsset(List<Object> ssData);
	
	public void insertConnectHomeData(Map<String, Object> params);
	
	public void updateConnectHomeData(Map<String, Object> params);
	
	public void updateGatewayData(List<Map<String, Object>> params);
	
	public void upsertEsrsDeviceStatus(Map<String, Object> deviceStatusDetails);
}
