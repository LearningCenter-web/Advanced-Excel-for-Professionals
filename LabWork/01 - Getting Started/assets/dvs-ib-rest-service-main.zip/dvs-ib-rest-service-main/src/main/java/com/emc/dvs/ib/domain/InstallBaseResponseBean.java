package com.emc.dvs.ib.domain;

import java.util.List;

import lombok.Data;

@Data
public class InstallBaseResponseBean {
	
	private InstallBaseStatsBean stats;
	private List<InstallBaseGeoBean> geo;

}
