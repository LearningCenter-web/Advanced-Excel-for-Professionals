package com.emc.dvs.ib.domain;

import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class SerializedResponseBean {
	private List<SerializedProductBean> serializedProductBean;
	Map<String, Integer> severityCountsMap;
	Map<String,Integer> advisoryCountsMap;
	boolean subscriptionAlertEnabled;
	@JsonIgnore
	int totalElementsCount;
}
