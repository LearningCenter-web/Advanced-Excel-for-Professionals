package com.emc.dvs.ib.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Entitlement {
	private String serviceLevelCode;
	private String type;
	private String serviceDescription;
	private String status;
	private String contractId;
	private String salesOrderNumber;
	private String primaryFlag;
	private String startDate;
	private String endDate;
	@JsonIgnore
	private Date contractTerminationDate;
	@JsonIgnore
	private Date contractStartDate;
	@JsonIgnore
	private Date contractEndDate;
}
