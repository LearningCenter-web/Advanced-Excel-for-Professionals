package com.emc.dvs.ib.service;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.emc.dvs.ib.config.OAuthFeignConfig;

@FeignClient(
		  name = "subscription-details-service", 
		  url="${advisories.subscription.url}",
		  configuration = OAuthFeignConfig.class)
public interface SubscriptionDetailsService {
	
	@GetMapping("/v1/subscription/esupport/{profileId}/LEMC")
	Map<String,Object> getSubscriptionDetails(@PathVariable("profileId") String profileId);

}
