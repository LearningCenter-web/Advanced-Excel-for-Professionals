package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class InstallBaseProductBean {
	private Long id;
	private String data;
}
