package com.emc.dvs.ib.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class AdvisoryBean extends AdvisoriesSummary{

	private String summary;
	private String resolution;
	private List<String> productName;
	private String lastReviewedBy;
	private long lastReviewTime;
	private String lastUpdatedBy;
	private long lastUpdatedDate;
	private String articleNumber;
	private List<String> cveIdList;
	private String emcProprietaryCode;
	private String impact;
	private String severityDescription;
	private String email;
	private String urlName;
	private String newArticleNumber;
	private String accessLevel;
	private String lastPublishedDate;
	@JsonIgnore
	private String cveIds;

	@JsonIgnore
	private String productNameList;

	public void setProductNameList(String productNameList) {
		this.productNameList = productNameList;
		if (StringUtils.hasText(productNameList)) {
			this.productName = Arrays.asList(productNameList.split("\\|"));
		} else {
			this.productName = new ArrayList<String>();
		}
	}

	public void setCveIds(String cveIds) {
		this.cveIds = cveIds;
		if (StringUtils.hasText(cveIds)) {
			this.cveIdList = Arrays.asList(cveIds.split(","));
		} else {
			this.cveIdList = new ArrayList<String>();
		}
	}
}
