package com.emc.dvs.ib.aspect;

import java.util.List;
import java.util.Map;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.emc.dvs.ib.persistance.InstallBaseMapper;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Aspect
@Component
public class ParameterAspect {

	private InstallBaseMapper installBaseMapper;

	@Autowired
	public ParameterAspect(InstallBaseMapper installBaseMapper) {
		this.installBaseMapper = installBaseMapper;
	}

	/**
	 * Validate the presence of certain filters for all methods except the single product as this has the serial number in the URL
	 * @param filterParams
	 */
	@Before("(execution(* com.emc.dvs.ib.web.InstallBaseController.*(..)) || execution(* com.emc.dvs.ib.web.AdvisoriesController.*(..)) ) && args(filterParams,..) "
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getProductDetail(..))"
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getSolutionComponents(..))"
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getTimelineData(..))"
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getSiteDetails(..))"
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getEsrsData(..))"
			+ "&& !execution(* com.emc.dvs.ib.web.InstallBaseController.getConnectHomeStatusDuration(..))")
	public void validateRequiredParameters(Map<String, Object> filterParams) {
		if (!(filterParams.containsKey("serviceProviderIsIn") || filterParams.containsKey("customerVisibilityIsIn")
				|| filterParams.containsKey("instanceNumberIsIn") || filterParams.containsKey("siteNumberIsIn")
				|| filterParams.containsKey("orSerialNumber") || filterParams.containsKey("andSiteNumber") 
				|| filterParams.containsKey("serialNumberIsIn") || filterParams.containsKey("tagIdIsIn")|| filterParams.containsKey("locationIdIsIn") || filterParams.containsKey("preferredIdIsIn") )) {
			// invalid call
			log.error("Invalid call with params: {}", filterParams.keySet());
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST);
		}
	}
	
	@Before("(execution(* com.emc.dvs.ib.web.InstallBaseController.*(..)) || execution(* com.emc.dvs.ib.web.AdvisoriesController.*(..)) )  && args(filterParams,..)")
	public void addCurrentPartition(Map<String, Object> filterParams) {
		List<String> partitions = installBaseMapper.getCurrentPartitions();
		partitions.forEach(s->{
			if (s.startsWith("ib_p")){
				filterParams.put("ibCurrentPartition", s);
				filterParams.put("currentPartitionId", s.substring(4));
			} 
			if (s.startsWith("component_p")){
				filterParams.put("componentCurrentPartition", s);
			}
			if (s.startsWith("esa_p")){
				filterParams.put("esaPartition", s);
			}
			if (s.startsWith("eta_p")){
				filterParams.put("etaPartition", s);
			}
		} );
		
		if(log.isTraceEnabled()) {
			log.trace("Added currentIbPartitionId", filterParams.get("ibCurrentPartition"));
			log.trace("Added currentComponentPartitionId", filterParams.get("componentCurrentPartition"));
			log.trace("Added currentAdvisoriesPartitionId", filterParams.get("advisoriesPartition"));
		}
	}

}
