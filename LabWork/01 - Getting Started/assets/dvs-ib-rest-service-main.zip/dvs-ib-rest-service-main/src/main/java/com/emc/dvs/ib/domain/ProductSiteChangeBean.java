package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class ProductSiteChangeBean {
	private long id;
	private String data;
}
