package com.emc.dvs.ib.service;

import java.util.Map;

//import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value="dvs-mail-service", url="${dvs.services.mail}")
public interface MailService {
	@RequestMapping(value="/renewcontract", method=RequestMethod.POST, consumes = "application/json")
	public void sendContractRenewalMail(@RequestBody Map<String, Object> contractDetails);
	
	@RequestMapping(value="/sitelocation", method=RequestMethod.POST, consumes = "application/json")
	public void sendUpdateSiteLocationMail(@RequestBody Map<String, Object> siteDetails);
	
	@RequestMapping(value = "/connecthome", method = RequestMethod.POST, consumes = "application/json")
	public void sendConnectHomeDurationMail(@RequestBody Map<String, Object> param);
}
