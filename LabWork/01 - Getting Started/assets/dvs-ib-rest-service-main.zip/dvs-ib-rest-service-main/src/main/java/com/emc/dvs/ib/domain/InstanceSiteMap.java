package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class InstanceSiteMap {

	private String instanceId;
	private String siteId;
	private String role;
}
