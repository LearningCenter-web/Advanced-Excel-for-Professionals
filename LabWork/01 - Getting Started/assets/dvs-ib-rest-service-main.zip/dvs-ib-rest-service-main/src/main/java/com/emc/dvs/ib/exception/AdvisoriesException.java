package com.emc.dvs.ib.exception;

/**
 * Business Exception class to handle Advisories exceptions & errors
 *
 */
public class AdvisoriesException extends RuntimeException {

	private static final long serialVersionUID = -8765280300629484690L;

	/**
	 * @param message
	 */
	public AdvisoriesException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public AdvisoriesException(String message, Throwable cause) {
		super(message, cause);

	}

}
