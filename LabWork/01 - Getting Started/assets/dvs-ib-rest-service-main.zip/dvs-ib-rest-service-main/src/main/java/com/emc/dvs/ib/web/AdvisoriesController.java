package com.emc.dvs.ib.web;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.emc.dvs.export.domain.ColumnWrapper;
import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.InstanceSiteMap;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.KpiBean;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.Page;
import com.emc.dvs.ib.domain.PagedResponseBean;
import com.emc.dvs.ib.domain.SerializedResponseBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.exception.AdvisoriesException;
import com.emc.dvs.ib.service.AdvisoriesService;
import com.emc.dvs.ib.service.FilterParamsService;
import com.emc.ols.user.domain.UserBean;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * AdvisoriesController
 * 
 * <p>
 * POST method is preferred because the amount of filters that can be passed
 * will trigger a Request URI too long error
 *
 */
@Slf4j
@RestController
@RefreshScope
public class AdvisoriesController {
	private static final String RESOLUTION = "resolution";
	private static final String DESC = "desc";
	private static final String ASC = "asc";
	private static final String TXT_CSV = "txt/csv";
	private static final String SORT_DIR = "sortDir";
	private static final String SORT_BY = "sortBy";
	private static final String SEVERITY = "severity";
	private static final String ARTICLE_AGE = "age";
	private static final String NUMBER = "number";
	private static final String COLUMNS = "columns";
	private static final String USER_BEAN = "USER_BEAN";
	private static final String CONTENT_DISPOSITION = "Content-disposition";
	private final AdvisoriesService advisoriesService;
	private static final String ESA = "ESA";
	private static final String ETA = "ETA";
	private final ObjectMapper mapper = new ObjectMapper();
	private FilterParamsService filterParamsService;
	
	@Value("${advisories.audit.dsa.refreshViewSql}")
	private String refreshDsaViewSql;
	
	@Value("${advisories.audit.dta.refreshViewSql}")
	private String refreshDtaViewSql;

	public AdvisoriesController(AdvisoriesService advisoriesService, FilterParamsService filterParamsService) {
		this.advisoriesService = advisoriesService;
		this.filterParamsService =filterParamsService;
	}


	/**
	 * Export Security Advisories aggregated data
	 * 
	 * @param filterParams
	 * @param request
	 * @return List<EsaAggBean>
	 */
	@RequestMapping(value = { "/esaAggregate" }, method = { RequestMethod.POST }, produces = "text/csv")
	public void downloadEsaAggregate(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) {
		
		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		filterParams.putIfAbsent(SORT_BY, SEVERITY);
		filterParams.putIfAbsent(SORT_DIR, DESC);
		try {
			final String columns = (String) filterParams.get(COLUMNS);
			final ColumnWrapper colWrapper = mapper.readValue(columns, ColumnWrapper.class);

			response.addHeader(CONTENT_DISPOSITION, "attachment;filename=security_advisory_export.csv");
			response.setContentType(TXT_CSV);
			final OutputStream out = response.getOutputStream();
			advisoriesService.getEsaAggregate(out, filterParams, colWrapper.getColumns());
		} catch (final Exception e) {
			log.error("Exception while creating security_advisory_export.csv: " + e.getMessage());
			throw new AdvisoriesException("Exception while creating security_advisory_export.csv : ", e);
		}
	}

	/**
	 * Export affected products as csv file for both ESA and ETA
	 * 
	 * @param filterParams
	 * @param articleId
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/exportAffectedProducts" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, List> downloadAffectedProducts(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) throws InterruptedException {

		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		filterParams.putIfAbsent(SORT_BY, "productName");
		filterParams.putIfAbsent(SORT_BY, "instanceId");
		filterParams.putIfAbsent(SORT_DIR, DESC);
		filterParams.put("articleIdsIsIn", "articleId");
		String advisoryType = (String)filterParams.get("advisoryType");
		Map<String, List> exportResponse = new HashMap<>();
			if(advisoryType.equalsIgnoreCase(ETA)) {
				exportResponse = getExportData(filterParams,ETA);
			}
			if(advisoryType.equalsIgnoreCase(ESA)) {
				exportResponse = getExportData(filterParams,ESA);
			}
			return exportResponse;
	}

	private Map<String, List> getExportData(Map<String, Object> filterParams, String advisoryType) throws InterruptedException {
		Map<String, List> exportResponse = new HashMap<>();
		Future<List<AffectedProductsBean>> affectedProducts = advisoriesService.getAffectedProducts(filterParams, advisoryType);
		Future<List<Note>> notesFuture = advisoriesService.getNotes(filterParams, advisoryType);
		try {
			final List<Note> notesResponse = notesFuture.get();
			List<Note> notes = notesResponse.stream().filter(note -> note.getAdvisoryNote()!=null).collect(Collectors.toList());
			exportResponse.put("Products", affectedProducts.get());
			exportResponse.put("Notes", notes);
		} catch (final InterruptedException ex) {
			log.error("getAffectedProducts InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getAffectedProducts ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getAffectedProducts ExecutionException : ", ex);
		}
		return exportResponse;
	}

	/**
	 * Get the Advisories data for the Kendo UI grid
	 * 
	 * @param filterParams
	 * @param request
	 * @return List<EsaAggBean>
	 * @throws InterruptedException
	 */
	@RequestMapping(value = { "/esaAggregate" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<AdvisoryBean> getEsaAggregate(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException {
		log.info("getting ESA aggregate : advisoriesService.getEsaAggregate()");
		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			final PagedResponseBean<AdvisoryBean> response = new PagedResponseBean<>();
			List<AdvisoryBean> listValue = new ArrayList<>();
			final Page page = new Page(25, 0, 1, 0);
			response.setPage(page);
			response.setRows(listValue);
			return response;
		}
		setFilterParams(filterParams);
		return getAdvisories(filterParams, request, ESA);
	}

	@RequestMapping(value = { "/esa/timeline" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<TimelineEntity> getEsaTimelineData(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException {
		setFilterParams(filterParams);
		filterParamsService.combineSiteAndLocationIds(filterParams);
		return advisoriesService.getEsaTimelineData(filterParams);
	}

	@RequestMapping(value = { "/esa/timeline/stats" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, Object> getEsaTimelineStats(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws Exception {
		Map<String, Object> esaTimelineStats = new HashMap<>();
		filterParamsService.combineSiteAndLocationIds(filterParams);
		try {
			final Future<Integer> esaCount = advisoriesService.getEsaEventsCount(filterParams);
			esaTimelineStats.put("esaCount", esaCount.get());
		} catch (final InterruptedException | ExecutionException ex) {
			log.error("Exception while getting esa filters : " + ex.getMessage());
			throw ex;
		}		
		return esaTimelineStats;
	}
	
	@RequestMapping(value = { "/eta/timeline" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<TimelineEntity> getEtaTimelineData(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		setFilterParams(filterParams);
		return advisoriesService.getEtaTimelineData(filterParams);
	}
	
	@RequestMapping(value = { "/eta/timeline/stats" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, Object> getEtaTimelineStats(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws Exception {
		Map<String, Object> etaTimelineStats = new HashMap<>();
		filterParamsService.combineSiteAndLocationIds(filterParams);
		try {
			final Future<Integer> etaCount = advisoriesService.getEtaEventsCount(filterParams);
			etaTimelineStats.put("etaCount", etaCount.get());
		} catch (final InterruptedException | ExecutionException ex) {
			log.error("Exception while getting eta filters : " + ex.getMessage());
			throw ex;
		}	
		return etaTimelineStats;
	}

	private PagedResponseBean<AdvisoryBean> getAdvisories(Map<String, Object> filterParams, HttpServletRequest request,
			String advisoryType) throws InterruptedException {
		final PagedResponseBean<AdvisoryBean> response = new PagedResponseBean<>();
		List<AdvisoryBean> listValue = new ArrayList<>();
		int totalElementsValue = 0;
		
		try {
			if (advisoryType.equalsIgnoreCase(ESA)) {
				final Future<Integer> totalElements = advisoriesService.getEsaTotalRecord(filterParams);
				listValue = getEsas(filterParams, request);
				totalElementsValue = totalElements.get();

			} else if (advisoryType.equalsIgnoreCase(ETA)) {
				final Future<Integer> totalElements = advisoriesService.getEtaTotalRecord(filterParams);
				listValue = getEtas(filterParams, request);
				totalElementsValue = totalElements.get();
			}
		} catch (final InterruptedException ex) {
			log.error("getEtaAggregatelist InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getEsaAggregate ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getEsaAggregate ExecutionException : ", ex);
		}
		final int totalPages = totalElementsValue / (Integer) filterParams.get("size") + 1;
		final Page page = new Page((Integer) filterParams.get("size"), totalElementsValue, totalPages,
				(Integer) filterParams.get(NUMBER));

		response.setPage(page);
		response.setRows(listValue);
		return response;
	}

	private Map<String, Object> setFilterParams(Map<String, Object> filterParams) {

		int number = 0;
		int size = 25;
		if (filterParams.containsKey(NUMBER)) {
			number = Integer.parseInt((String) filterParams.get(NUMBER));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}

		filterParams.put(NUMBER, number);
		filterParams.put("size", size);

		filterParams.putIfAbsent(SORT_BY, SEVERITY);
		filterParams.putIfAbsent(SORT_DIR, DESC);
		return filterParams;
	}

	/**
	 * Get the Securties Advisories detail for a given particular articleId
	 * 
	 * @param filterParams
	 * @param articleId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/affectedProducts/{articleId}" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<AffectedProductsBean> getAffectedProducts(@RequestParam Map<String, Object> filterParams,
			@PathVariable String articleId, HttpServletRequest request) throws InterruptedException {

		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		filterParams.put("articleIdsIsIn", articleId);
		log.info("getting ESA affected products details: advisoriesService.getAffectedProducts()");
		List<AffectedProductsBean> response = new ArrayList<>();
		final Future<List<AffectedProductsBean>> affectedProducts = advisoriesService.getAffectedProducts(filterParams, ESA);
		final Future<List<Note>> notes = advisoriesService.getNotes(filterParams, ESA);
		try {
			while (!(affectedProducts.isDone() && notes.isDone())) {
				Thread.sleep(10);
			}
			response = affectedProducts.get();
			final List<Note> notesResponse = notes.get();
			response.forEach(product -> {
				product.setNote(
						notesResponse.stream().filter(note -> note.getInstanceId().equals(product.getInstanceId()) && note.getAdvisoryNote()!=null)
								.collect(Collectors.toList()));
			});
		} catch (final InterruptedException ex) {
			log.error("getAffectedProducts InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getAffectedProducts ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getAffectedProducts ExecutionException : ", ex);
		}
		return response;
	}

	/**
	 * Mark a list of articles as reviewed FilterParams should have a '|' delimited
	 * list of article ids (param name = articleIdIsIn) and also site/group/account
	 * id(s)
	 * 
	 * @param filterParams
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/markDsaAsReviewed" }, method = { RequestMethod.POST })
	public void markDsaAsReviewed(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		filterParamsService.combineSiteAndLocationIds(filterParams);
		advisoriesService.markDsaAsReviewed(filterParams, userBean);
		//advisoriesService.refreshView(refreshDsaViewSql);
	}

	/**
	 * Update the resolution tracking dropdown value
	 * 
	 * @param filterParams
	 * @param resolution
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/resolutionTracking" }, method = { RequestMethod.POST })
	public void updateResolutionTracking(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		advisoriesService.updateResolutionTracking(filterParams, userBean, filterParams.get(RESOLUTION).toString());
	}

	/**
	 * Mark a list of articles as disregarded FilterParams should have a '|'
	 * delimited list of article ids (param name = articleIdIsIn) and also
	 * site/group/account id(s)
	 * 
	 * @param filterParams
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/markDsaAsDisregarded" }, method = { RequestMethod.POST })
	public void markDsaAsDisregarded(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		advisoriesService.markDsaAsDisregarded(filterParams, userBean);
		//advisoriesService.refreshView(refreshDsaViewSql);
		
	}

	/**
	 * Get the counts for Advisory Remediation Status Kpi chart
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/remediationStatus" }, method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody Map<String, Object> getRemediationStatus(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) {
		final Map<String, Object> response = new HashMap<>();
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn"))) {
			Object kpi=new KpiBean();
			response.put("kpiCounts", kpi);
			return response;
		}
		log.info("getting remediationStatus: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		final KpiBean kpiBean = advisoriesService.getRemediationStatus(filterParams);
		response.put("kpiCounts", kpiBean);
		return response;
	}

	/**
	 * Get the counts for Affected Products Kpi chart
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/affectedProductsForKpi" }, method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody List<AffectedProductsKpi> getAffectedProductsForKpi(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		log.info("getting affectedProductsForKpi: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		filterParamsService.combineSiteAndLocationIds(filterParams);
		return advisoriesService.getAffectedProductsForKpi(filterParams);
	}

	/**
	 * This Api used in environmental deatils tab which only get DSA Advisories
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 * @throws InterruptedException
	 * 
	 */
	@RequestMapping(value = { "/esas" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<AdvisoryBean> getEsas(@RequestParam Map<String, Object> filterParams, HttpServletRequest request)
			throws InterruptedException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final Future<List<AdvisoryBean>> esaAggregatelist = advisoriesService.getEsaAggregate(filterParams);
		try {
			return esaAggregatelist.get();
		} catch (final ExecutionException e) {
			log.error("getEsas ExecutionException : " + e.getMessage());
			throw new AdvisoriesException("getEsas ExecutionException : ", e);
		}
	}

	/**
	 * This Api is used to get the DSA data based on the filter parameters that are
	 * passed in
	 * 
	 * @param filterParams
	 * @return EtaAggBean
	 * @throws InterruptedException
	 */
	@RequestMapping(value = { "/etaAggregate" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<AdvisoryBean> getEtaAggregate(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException {
		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			final PagedResponseBean<AdvisoryBean> response = new PagedResponseBean<>();
			List<AdvisoryBean> listValue = new ArrayList<>();
			final Page page = new Page(25, 0, 1, 0);
			response.setPage(page);
			response.setRows(listValue);
			return response;
		}
		log.info("getting ETA aggregate : advisoriesService.getEtaAggregate()");
		setFilterParams(filterParams);
		return getAdvisories(filterParams, request, ETA);
	}

	/**
	 * This Api used in environmental deatils tab which only get DTA Advisories
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@RequestMapping(value = { "/etas" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<AdvisoryBean> getEtas(@RequestParam Map<String, Object> filterParams, HttpServletRequest request)
			throws InterruptedException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final Future<List<AdvisoryBean>> etaAggregatelist = advisoriesService.getEtaAggregate(filterParams);
		try {
			return etaAggregatelist.get();
		} catch (final ExecutionException e) {
			log.error("getEtas ExecutionException : " + e.getMessage());
			throw new AdvisoriesException("getEtas ExecutionException : ", e);

		}
	}

	/**
	 * Mark a list of articles as reviewed for dtas FilterParams should have a '|'
	 * delimited list of article ids (param name = articleIdIsIn) and also
	 * site/group/account id(s)
	 * 
	 * @param filterParams
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/markDtaAsReviewed" }, method = { RequestMethod.POST })
	public void markDtaAsReviewed(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		advisoriesService.markDtaAsReviewed(filterParams, userBean);
		//advisoriesService.refreshView(refreshDtaViewSql);
	}

	/**
	 * Mark a list of articles as disregarded for dtas FilterParams should have a
	 * '|' delimited list of article ids (param name = articleIdIsIn) and also
	 * site/group/account id(s)
	 * 
	 * @param filterParams
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/markDtaAsNotApplicable" }, method = { RequestMethod.POST })
	public void markDtaAsNotApplicable(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		advisoriesService.markDtaAsNotApplicable(filterParams, userBean);
		//advisoriesService.refreshView(refreshDtaViewSql);
	}

	/**
	 * Export Technical Advisories aggregated data
	 * 
	 * @param filterParams
	 * @param request
	 * 
	 */
	@RequestMapping(value = { "/etaAggregate" }, method = { RequestMethod.POST }, produces = "text/csv")
	public void downloadEtaAggregate(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) {

		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		filterParams.putIfAbsent(SORT_BY, SEVERITY);
		filterParams.putIfAbsent(SORT_DIR, DESC);
		try {
			final String columns = (String) filterParams.get(COLUMNS);
			final ColumnWrapper colWrapper = mapper.readValue(columns, ColumnWrapper.class);

			response.addHeader(CONTENT_DISPOSITION, "attachment;filename=technical_advisory_export.csv");
			response.setContentType(TXT_CSV);
			final OutputStream out = response.getOutputStream();
			advisoriesService.getEtaAggregate(out, filterParams, colWrapper.getColumns());
		} catch (final Exception e) {
			log.error("downloadEtaAggregate Exception : " + e.getMessage());
			throw new AdvisoriesException("downloadEtaAggregate Exception : ", e);
		}
	}

	/**
	 * Get the Technical Advisories detail for a given articleId
	 * 
	 * @param filterParams
	 * @param articleId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/etaAffectedProducts/{articleId}" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<AffectedProductsBean> getEtaAffectedProducts(@RequestParam Map<String, Object> filterParams,
			@PathVariable String articleId, HttpServletRequest request) throws InterruptedException {

		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		filterParams.put("articleIdsIsIn", articleId);
		log.info("getting ETA aggregate details: advisoriesService.getEtaAffectedProducts()");
		List<AffectedProductsBean> response = new ArrayList<>();
		final Future<List<AffectedProductsBean>> affectedProducts = advisoriesService.getAffectedProducts(filterParams, ETA);
		final Future<List<Note>> notes = advisoriesService.getNotes(filterParams,ETA);
		try {
			while (!(affectedProducts.isDone() && notes.isDone())) {
				Thread.sleep(10);
			}
			response = affectedProducts.get();
			final List<Note> notesResponse = notes.get();
			response.forEach(product -> {
				product.setNote(
						notesResponse.stream().filter(note -> note.getInstanceId().equals(product.getInstanceId()) && note.getAdvisoryNote()!=null)
								.collect(Collectors.toList()));
			});
		} catch (final InterruptedException ex) {
			log.error("getEtaAffectedProducts InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getEtaAffectedProducts ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getEtaAffectedProducts ExecutionException : ", ex);
		}
		return response;
	}
	

	/**
	 * Update the resolution tracking dropdown value for ETAs
	 * 
	 * @param filterParams
	 * @param resolution
	 * @param request
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@RequestMapping(value = { "/etaResolutionTracking" }, method = { RequestMethod.POST })
	public void updateEtaResolutionTracking(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		advisoriesService.updateEtaResolutionTracking(filterParams, userBean,
				filterParams.get(RESOLUTION).toString());
	}

	/**
	 * Get the counts for Technical Advisory Remediation Status Kpi chart
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/etaRemediationStatusForKpi" }, method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody Map<String, Object> getEtaRemediationStatusForKpi(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		log.info("getting etaRemediationStatusForKpi: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final Map<String, Object> response = new HashMap<>();
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			Object kpi=new KpiBean();
			response.put("kpiCounts", kpi);
			return response;
		}
		final KpiBean kpiBean = advisoriesService.getEtaRemediationStatusCount(filterParams);
		response.put("kpiCounts", kpiBean);
		return response;
	}

	/**
	 * Get the counts for ETA Affected Products Kpi chart
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/etaAffectedProductsForKpi" }, method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody List<AffectedProductsKpi> getEtaAffectedProductsForKpi(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		log.info("getting etaAffectedProductsForKpi: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		return advisoriesService.getEtaAffectedProductsForKpi(filterParams);
	}

	/**
	 * This Api used in will fetch advisory detail of a particular advisory
	 * 
	 * @param filterParams
	 * @param request
	 * @return AdvisoryBean
	 */
	@RequestMapping(value = { "/getAdvisoryDetails" }, method = { RequestMethod.GET, RequestMethod.POST })
	public AdvisoryBean getAdvisoryDetail(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		return advisoriesService.getAdvisoryDetail(filterParams);
	}

	/**
	 * Add notes on affected product/products delimited list of instance id and also
	 * article id site/group/account id(s)
	 * 
	 * @param filterParams
	 * @param request
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@PostMapping(value = { "/addNotes" })
	public void addNotes(@RequestParam Map<String, Object> filterParams, HttpServletRequest request)
			throws IOException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		final String note = (String) filterParams.get("notes");
		if (null!=note && !note.isEmpty()) {
			advisoriesService.addNotes(filterParams, userBean);
		}
		boolean isResolutionUpdated = Boolean.parseBoolean(filterParams.get("isResolutionUpdated").toString());
		log.info("isResolutionUpdated :"+isResolutionUpdated);		
		if(isResolutionUpdated) {
			log.info("calling  processResolutionTracking():");
			processResolutionTracking(filterParams, userBean);
		}
		else {
			log.error("Skipped the event into Audit for the user : "+userBean.getEmail());
		}
		
	}

	/**
	 * Update the resolution tracking only if the isResolutionUpdated is set to TRUE
	 * @param filterParams
	 * @param userBean
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	private void processResolutionTracking(Map<String, Object> filterParams, final UserBean userBean) throws JsonParseException, JsonMappingException, IOException {
		final String advisoryType = (String) filterParams.get("advisoryType");	
		final ObjectMapper mapper = new ObjectMapper();
		final List<InstanceSiteMap> instanceIdMap = mapper.readValue((String) filterParams.get("instanceSiteMap"),
				new TypeReference<List<InstanceSiteMap>>() {
				});
		final String instanceIdIsIn = instanceIdMap.stream().map(InstanceSiteMap::getInstanceId)
				.collect(Collectors.joining("|"));
		filterParams.put("instanceIdIsIn", instanceIdIsIn);
		if ("true".equalsIgnoreCase((String) filterParams.get("isSerialized"))) {
			filterParams.put("instanceNumberIsIn", instanceIdIsIn);
		}
		log.info("advisoryType : "+advisoryType);
		if (advisoryType.equalsIgnoreCase(ESA)) {
			advisoriesService.updateResolutionTracking(filterParams, userBean, filterParams.get(RESOLUTION).toString());
			//advisoriesService.refreshView(refreshDsaViewSql);
		}else if (advisoryType.equalsIgnoreCase(ETA)) {
			advisoriesService.updateEtaResolutionTracking(filterParams, userBean,
					filterParams.get(RESOLUTION).toString());
			//advisoriesService.refreshView(refreshDtaViewSql);
		}else {
			log.error("advisoryType is missing : "+advisoryType);
		}

	}
	
	/**
	 * Api to get notes for a given serialNumber and articleId
	 * @param filterParams
	 * @param advisoryType
	 * @return
	 * @throws InterruptedException
	 */
	@RequestMapping(value = { "/notes" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<IpsNote> getNotesForSerializedProduct(@RequestParam Map<String, Object> filterParams, String advisoryType)
			throws InterruptedException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(StringUtils.isEmpty(advisoryType)) {
			throw new AdvisoriesException("advisoryType is required: ");
		}
		final Future<List<IpsNote>> notesList = advisoriesService.getNotesForSerializedProduct(filterParams,advisoryType);
		try {
			return notesList.get();
		} catch (final ExecutionException e) {
			log.error("getNotesForSerializedProduct ExecutionException : " + e.getMessage());
			throw new AdvisoriesException("getNotes ExecutionException : ", e);
		}
	}
	
	/**
	 * Get the Technical Advisories HUD details for a given account
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/hudData" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, List<AdvisoriesHud>> getHudDetails(@RequestParam Map<String, Object> filterParams, 
			HttpServletRequest request) throws InterruptedException {
		filterParamsService.combineSiteAndLocationIds(filterParams);
		log.info("getting hud details: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		Map<String, List<AdvisoriesHud>> response = new HashMap<>();
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			List<String> sevName = new ArrayList<>(Arrays.asList("Critical", "High", "Medium", "Low"));
			List<AdvisoriesHud> advisories=new ArrayList<>();
			AdvisoriesHud hud = null;
			for(String sev: sevName) {
				hud = new AdvisoriesHud();
				hud.setArticles(Integer.toString(0));
				hud.setSeverity(sev);
				advisories.add(hud);
			}
			response.put("technicalAdvisories", new ArrayList<AdvisoriesHud>(advisories));
			response.put("securityAdvisories", new ArrayList<AdvisoriesHud>(advisories));
			return response;
		}
		final Future<List<AdvisoriesHud>> dsa = advisoriesService.getDsaHud(filterParams);
		final Future<List<AdvisoriesHud>> dta = advisoriesService.getDtaHud(filterParams);
		try {
			while (!(dsa.isDone() && dta.isDone())) {
				Thread.sleep(10);
			}
			response.put("technicalAdvisories", processHudData(dta.get()));
			response.put("securityAdvisories", processHudData(dsa.get()));
		} catch (final InterruptedException ex) {
			log.error("getHudDetails InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getHudDetails ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getHudDetails ExecutionException : ", ex);
		}
		return response;
	}
	
	private List<AdvisoriesHud> processHudData(List<AdvisoriesHud> advisories) {
		List<String> sevName = new ArrayList<>(Arrays.asList("Critical", "High", "Medium", "Low"));
		for(AdvisoriesHud hud: advisories) {
			if(sevName.contains(hud.getSeverity())) {
				sevName.remove(hud.getSeverity());
			}
		}
		AdvisoriesHud hud = null;
		for(String sev: sevName) {
			hud = new AdvisoriesHud();
			hud.setArticles(Integer.toString(0));
			hud.setSeverity(sev);
			advisories.add(hud);
		}
		return advisories;
	}
	
	/**
	 * Return all the advisories for a serialized product
	 * @param filterParams
	 * @param advisoryType
	 * @return
	 * @throws InterruptedException
	 */
	@RequestMapping(value = { "/advisories" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<SerializedResponseBean> getAdvisoriesForSerializedProduct(@RequestParam Map<String, Object> filterParams,
			String advisoryType, HttpServletRequest request) throws InterruptedException {
		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		final UserBean userBean = (UserBean) request.getAttribute(USER_BEAN);
		filterParams.put("uid", userBean.getUid());
		if (log.isTraceEnabled()) {
			log.trace("getting serialized advisories : advisoriesService.getAdvisoriesForSerializedProduct()");
		}
		if(StringUtils.isEmpty(advisoryType)) {
			log.error("getAdvisoriesForSerializedProduct AdvisoriesException : advisoryType is required");
			throw new AdvisoriesException("advisoryType is required: ");
		}
		// default sort by age ascending
		filterParams.putIfAbsent(SORT_BY, ARTICLE_AGE);
		filterParams.putIfAbsent(SORT_DIR, ASC);
		setFilterParams(filterParams);
		
		String tagIdIsIn = (String) filterParams.get("tagIdIsIn");
		String tagId = (String)filterParams.getOrDefault("tagId", "0");
		if (null != tagIdIsIn && !tagIdIsIn.isEmpty()) {
			if (log.isTraceEnabled()) {
				log.trace("Inside tagIdIsIn condition, tagIdIsIn: "+tagIdIsIn+" ,tagId: "+tagId);
				}
			return getAdvisoriesForProduct(filterParams,advisoryType);
		} else {
			if (log.isTraceEnabled()) {
				log.trace("Inside tagId condition, tagIdIsIn: "+tagIdIsIn+" ,tagId: "+tagId);
				}
			return getAdvisoriesSerializedProduct(filterParams,advisoryType);
		}
	}
	
	private SerializedResponseBean getAdvisoryForProduct(@RequestParam Map<String, Object> filterParams, String advisoryType)
			throws InterruptedException {
		SerializedResponseBean advisoriesSerialized =  advisoriesService.getAdvisoryForProduct(filterParams, advisoryType);
		return advisoriesSerialized;
	}
	
	private SerializedResponseBean getAdvisorySerialized(@RequestParam Map<String, Object> filterParams, String advisoryType)
			throws InterruptedException {
		SerializedResponseBean advisoriesSerialized =  advisoriesService.getAdvisorySerialized(filterParams, advisoryType);
		return advisoriesSerialized;
	}
	
	private PagedResponseBean<SerializedResponseBean> getAdvisoriesForProduct(Map<String, Object> filterParams,
			String advisoryType) throws InterruptedException {
		final PagedResponseBean<SerializedResponseBean> response = new PagedResponseBean<>();
		SerializedResponseBean responseBean = new SerializedResponseBean();
		List<SerializedResponseBean> responseBeanList =new ArrayList<SerializedResponseBean>();
		
		int totalElementsValue = 0;
		try {
			responseBean = getAdvisoryForProduct(filterParams, advisoryType);
			totalElementsValue = responseBean.getTotalElementsCount();
			responseBeanList.add(responseBean);
		} catch (final InterruptedException ex) {
			log.error("getAdvisoriesSerializedProduct InterruptedException : " + ex.getMessage());
			throw ex;
		} 
		final int totalPages = totalElementsValue / (Integer) filterParams.get("size") + 1;
		final Page page = new Page((Integer) filterParams.get("size"), totalElementsValue, totalPages,
				(Integer) filterParams.get(NUMBER));

		response.setPage(page);
		response.setRows(responseBeanList);
		return response;
	}
	 
	private PagedResponseBean<SerializedResponseBean> getAdvisoriesSerializedProduct(Map<String, Object> filterParams,
			String advisoryType) throws InterruptedException {
		final PagedResponseBean<SerializedResponseBean> response = new PagedResponseBean<>();
		SerializedResponseBean responseBean = new SerializedResponseBean();
		List<SerializedResponseBean> responseBeanList =new ArrayList<SerializedResponseBean>();
		
		int totalElementsValue = 0;
		try {
			responseBean = getAdvisorySerialized(filterParams, advisoryType);
			totalElementsValue = responseBean.getTotalElementsCount();
			responseBeanList.add(responseBean);
		} catch (final InterruptedException ex) {
			log.error("getAdvisoriesSerializedProduct InterruptedException : " + ex.getMessage());
			throw ex;
		} 
		final int totalPages = totalElementsValue / (Integer) filterParams.get("size") + 1;
		final Page page = new Page((Integer) filterParams.get("size"), totalElementsValue, totalPages,
				(Integer) filterParams.get(NUMBER));

		response.setPage(page);
		response.setRows(responseBeanList);
		return response;
	}
	
	/**
	 * Get the Advisories summary details for a given account
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/advisoriesSummary" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, Object> getAdvisoriesSummary(@RequestParam Map<String, Object> filterParams, 
			HttpServletRequest request) throws InterruptedException {
		
		log.info("getting summary details: advisoriesService");
		Map<String, Object> response = new HashMap<>();
		List<String> emptyList = Collections.<String>emptyList();
		
		if (!validateFilterParams(filterParams)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid  request payload");
		}
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			response.put("technicalAdvisories", emptyList);
			response.put("securityAdvisories", emptyList);
			return response;
		}
		filterParams.put("severityFilterIsIn","Critical");
		filterParams.put("remdetiationStatusIn","New|Reviewed|Work In Progress");
		String after = (String) filterParams.get("dateAfter");
		String before = (String) filterParams.get("dateBefore");
		filterParams.put("etaDateAfter", after);
		filterParams.put("etaDateBefore", before);
		filterParams.put("esaDateAfter", after);
		filterParams.put("esaDateBefore", before);
		final Future<List<AdvisoriesSummary>> dsa = advisoriesService.getEsaSummary(filterParams);
		final Future<List<AdvisoriesSummary>> dta = advisoriesService.getEtaSummary(filterParams);
		try {
			while (!(dsa.isDone() && dta.isDone())) {
				Thread.sleep(10);
			}
			response.put("technicalAdvisories", dta.get());
			response.put("securityAdvisories", dsa.get());
		} catch (final InterruptedException ex) {
			log.error("advisoriesSummary InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("advisoriesSummary ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("advisoriesSummary ExecutionException : ", ex);
		}
		return response;
	}
	
	/**
	 * Get Non Entitled ESA count
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/nonEntitledEsa" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Integer getNonEntitledEsaDetails(@RequestParam Map<String, Object> filterParams, 
			HttpServletRequest request) throws InterruptedException {
		
		log.info("getting nonEntitledEsa {}", filterParams.get("orServicePlanLevelNotIn"));
		int nonEntitledAdvisories = 0;
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			return nonEntitledAdvisories;
		}
		final Future<List<AdvisoriesHud>> dsa = advisoriesService.getDsaHud(filterParams);
		try {
			List<AdvisoriesHud> advisories = dsa.get();
			if(!advisories.isEmpty() && advisories!=null)
			{
				for(AdvisoriesHud hud: advisories) {
					nonEntitledAdvisories = nonEntitledAdvisories+Integer.parseInt(hud.getArticles());
				}
			}
		} catch (final InterruptedException ex) {
			log.error("getNonEntitledEsaDetails InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getNonEntitledEsaDetails ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getNonEntitledEsaDetails ExecutionException : ", ex);
		}
		log.info("non entitled esa advisories {}: ",nonEntitledAdvisories);
		return nonEntitledAdvisories;
	}
	
	
	/**
	 * Get Non Entitled ETA count
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/nonEntitledEta" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Integer getNonEntitledEtaDetails(@RequestParam Map<String, Object> filterParams, 
			HttpServletRequest request) throws InterruptedException {
		
		log.info("getting nonEntitledEsa {}", filterParams.get("orServicePlanLevelNotIn"));
		int nonEntitledAdvisories = 0;
		filterParamsService.combineSiteAndLocationIds(filterParams);
		if(filterParams.containsKey("locationIdIsIn") && !(filterParams.containsKey("siteNumberIsIn")) ) {
			return nonEntitledAdvisories;
		}
		final Future<List<AdvisoriesHud>> dta = advisoriesService.getDtaHud(filterParams);
		try {
			List<AdvisoriesHud> advisories =  dta.get();
			if(!advisories.isEmpty() && advisories!=null)
			{
				for(AdvisoriesHud hud: advisories) {
					nonEntitledAdvisories = nonEntitledAdvisories+Integer.parseInt(hud.getArticles());
				}
			}
		} catch (final InterruptedException ex) {
			log.error("getHudDetails InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getHudDetails ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getHudDetails ExecutionException : ", ex);
		}
		
		log.info("non entitled esa advisories {}: ",nonEntitledAdvisories);
		return nonEntitledAdvisories;
	}
	
	/**
	 * Get the Advisories count for a given account
	 * This will be used to calculate service risk score
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/advisoriesCount" }, method = { RequestMethod.GET, RequestMethod.POST })
	public Map<String, Integer> getAdvisoriesCount(@RequestParam Map<String, Object> filterParams, 
			HttpServletRequest request) throws InterruptedException {
		
		log.info("getting advisories count: advisoriesService {}",filterParams.get("servicePlanLevelIsIn"));
		filterParamsService.combineSiteAndLocationIds(filterParams);
		String after = (String) filterParams.get("dateAfter");
		String before = (String) filterParams.get("dateBefore");
		filterParams.put("etaDateAfter", after);
		filterParams.put("etaDateBefore", before);
		filterParams.put("esaDateAfter", after);
		filterParams.put("esaDateBefore", before);
		filterParams.put("remdetiationStatusIn", "New|Reviewed|Work In Progress");
		filterParams.put("severityFilterIsIn", "Critical");
		Map<String, Integer> response = new HashMap<>();
		final Future<Integer> dsa = advisoriesService.getEsaTotalRecord(filterParams);
		final Future<Integer> dta = advisoriesService.getEtaTotalRecord(filterParams);
		try {
			while (!(dsa.isDone() && dta.isDone())) {
				Thread.sleep(10);
			}
			response.put("dta", dta.get());
			response.put("dsa", dsa.get());
		} catch (final InterruptedException ex) {
			log.error("getCount InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (final ExecutionException ex) {
			log.error("getCount ExecutionException : " + ex.getMessage());
			throw new AdvisoriesException("getCount ExecutionException : ", ex);
		}
		return response;
	}
	
	
	private boolean validateFilterParams(Map<String, Object> filterParams) {
		boolean isValid = true;
		if(filterParams.containsKey("sortBy")) {
	        String strPattern = "[a-zA-Z0-9,]+";
	        isValid= Pattern.matches(strPattern, filterParams.get("sortBy").toString());
		}
		if(filterParams.containsKey("sortDir")) {
	        if(!filterParams.get("sortDir").toString().toLowerCase().equals("asc") && !filterParams.get("sortDir").toString().toLowerCase().equals("desc")) {
	        	isValid = false;
	        }
		}
		return isValid;
	}
	
}
