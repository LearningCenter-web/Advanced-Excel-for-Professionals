package com.emc.dvs.ib.service;

import java.util.Map;

import org.springframework.cloud.context.config.annotation.RefreshScope;
//import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RefreshScope
@FeignClient(value="esrs-details-service", url="${bdl.esrs.baseUrl}")
public interface EsrsService {
	@RequestMapping(value = "/ms360/mqlistnr/ms360/v1/esrs/getDetails/device/{serialNumber}/{productType}")
	public Map<String, Object> getDeviceDetails(@PathVariable("serialNumber") String serialNumber, @PathVariable("productType") String productType, @RequestParam("apiKey") String apiKey);
	
	@RequestMapping(value = "/ms360/mqlistnr/ms360/v1/esrs/getDetails/gateway/{gatewaySerialNumber}/{gatewayModel}")
	public Map<String, Object> getGatewayDetails(@PathVariable("gatewaySerialNumber") String gatewaySerialNumber, @PathVariable("gatewayModel") String gatewayModel, @RequestParam("apiKey") String apiKey);
	
	@RequestMapping(value = "/ms360/mqlistnr/ms360/v1/esrs/getDetails/cluster/{clusterId}")
	public Map<String, Object> getClusterDetails(@PathVariable("clusterId") String clusterId, @RequestParam("apiKey") String apiKey);
}
