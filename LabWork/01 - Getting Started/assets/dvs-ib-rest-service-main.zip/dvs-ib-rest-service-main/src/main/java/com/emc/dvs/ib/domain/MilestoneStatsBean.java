package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class MilestoneStatsBean {
	private int eopsDateCount;
	private int contractEndDateCount;
	private int installDateCount;
	private int shipDateCount;
	private int purchaseDateCount;
}
