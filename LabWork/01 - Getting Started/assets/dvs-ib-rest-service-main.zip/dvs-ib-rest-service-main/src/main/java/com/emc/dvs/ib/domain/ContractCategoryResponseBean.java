package com.emc.dvs.ib.domain;

import java.util.Map;

import lombok.Data;

@Data
public class ContractCategoryResponseBean {
	private Map<String, Long> contractCategories;
	private Map<String, Map<String, Long>> contractProductFamilies;
}
