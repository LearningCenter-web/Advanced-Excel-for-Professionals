package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class CodeLevelsProdFamilyAggBean {

	private String familyName;
	private int totalSystems;
	private int codeReleases;
	
}
