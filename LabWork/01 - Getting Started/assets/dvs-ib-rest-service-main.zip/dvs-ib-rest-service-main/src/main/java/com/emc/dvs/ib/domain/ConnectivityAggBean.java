package com.emc.dvs.ib.domain;

import lombok.Data;

@Data
public class ConnectivityAggBean {

	private String connectionType;
	private String productFamily;
	private String connectFlag;
	private int connectionTypeCount;
	private int productFamilyCount;
	
}
