package com.emc.dvs.ib.service;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class FilterParamsService {

    public void combineSiteAndLocationIds(Map<String, Object> filterParams) {
        if (filterParams.containsKey("locationIdIsIn")) {
        String updatedSiteIds = filterParams.containsKey("siteNumberIsIn") ?filterParams.get("siteNumberIsIn").toString().concat("|") :""
                    .concat(filterParams.get("locationIdIsIn").toString()) ;
            filterParams.put("siteNumberIsIn", updatedSiteIds);
        }
    }

}
