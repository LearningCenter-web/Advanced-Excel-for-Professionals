package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class ProductChangeBean {
	private String userName;
	private String contractRenewalAction;
	@ExportDate(value="MMM d, yyyy HH:mm:ss")
	private Long contractSubmissionDate;
	private String contractRequestType;	
}
