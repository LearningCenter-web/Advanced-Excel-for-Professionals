package com.emc.dvs.ib.service;

import java.util.Map;

//import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value="dvs-audit-service", url="${dvs.services.audit}")
public interface DvsAuditService {
	
	@RequestMapping(method = RequestMethod.POST, value = "/", consumes = "application/json")
	public boolean insertAuditRecord(@RequestBody Map<String,Object> auditRecord);

}
