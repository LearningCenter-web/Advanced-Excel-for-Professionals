package com.emc.dvs.ib.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.emc.dvs.export.domain.Column;
import com.emc.dvs.ib.domain.AdvisoriesHud;
import com.emc.dvs.ib.domain.AdvisoriesSummary;
import com.emc.dvs.ib.domain.AdvisoryBean;
import com.emc.dvs.ib.domain.AffectedProductsBean;
import com.emc.dvs.ib.domain.AffectedProductsKpi;
import com.emc.dvs.ib.domain.KpiBean;
import com.emc.dvs.ib.domain.Note;
import com.emc.dvs.ib.domain.IpsNote;
import com.emc.dvs.ib.domain.SerializedResponseBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.ols.user.domain.UserBean;

public interface AdvisoriesService {
	public Future<List<AdvisoryBean>> getEsaAggregate(Map<String, Object> filterParams);

	public void markDsaAsReviewed(Map<String, Object> filterParams, UserBean user);

	public void markDsaAsDisregarded(Map<String, Object> filterParams, UserBean user);

	public Future<Integer> getEsaTotalRecord(Map<String, Object> filterParams);
	
	public List<TimelineEntity> getEsaTimelineData(Map<String, Object> filterParams);
	
	public List<TimelineEntity> getEtaTimelineData(Map<String, Object> filterParams);
	
	public Future<Integer> getEsaEventsCount(Map<String, Object> filterParams);
	
	public Future<Integer> getEtaEventsCount(Map<String, Object> filterParams);

	public void getEsaAggregate(OutputStream out, Map<String, Object> filterParams, List<Column> cols);

	public Future<List<AffectedProductsBean>> getAffectedProducts(Map<String, Object> filterParams, String advisoryType);

	public void updateResolutionTracking(Map<String, Object> filterParams, UserBean userBean, String resolution);

	public void getAffectedProducts(OutputStream out, Map<String, Object> filterParams, List<Column> columns);

	public KpiBean getRemediationStatus(Map<String, Object> filterParams);

	public List<AffectedProductsKpi> getAffectedProductsForKpi(Map<String, Object> filterParams);

	public Future<List<AdvisoryBean>> getEtaAggregate(Map<String, Object> filterParams);

	public Future<Integer> getEtaTotalRecord(Map<String, Object> filterParams);

	public void markDtaAsReviewed(Map<String, Object> filterParams, UserBean user);

	public void markDtaAsNotApplicable(Map<String, Object> filterParams, UserBean user);

	public void getEtaAggregate(OutputStream out, Map<String, Object> filterParams, List<Column> cols);

	public Future<List<AffectedProductsBean>> getEtaAffectedProducts(Map<String, Object> filterParams);

	public void getEtaAffectedProducts(OutputStream out, Map<String, Object> filterParams, List<Column> columns);

	public void updateEtaResolutionTracking(Map<String, Object> filterParams, UserBean userBean, String resolution);

	public KpiBean getEtaRemediationStatusCount(Map<String, Object> filterParams);

	public List<AffectedProductsKpi> getEtaAffectedProductsForKpi(Map<String, Object> filterParams);

	public AdvisoryBean getAdvisoryDetail(Map<String, Object> filterParams);

	public void addNotes(Map<String, Object> filterParams, UserBean user) throws IOException;

	public Future<List<Note>> getNotes(Map<String, Object> filterParams, String advisoryType);

	public Future<List<IpsNote>> getNotesForSerializedProduct(Map<String, Object> filterParams,String advisoryType);
	
	public Future<List<AdvisoriesHud>> getDsaHud(Map<String, Object> filterParams);
	
	public Future<List<AdvisoriesHud>> getDtaHud(Map<String, Object> filterParams);
	
	public Future<Integer> getESASerializedTotalRecord(Map<String, Object> filterParams);

	public Future<Integer> getETASerializedTotalRecord(Map<String, Object> filterParams);

	public SerializedResponseBean getAdvisorySerialized(Map<String, Object> filterParams, String advisoryType);
	
	public SerializedResponseBean getAdvisoryForProduct(Map<String, Object> filterParams, String advisoryType);
	
	public Future<List<AdvisoriesSummary>> getEsaSummary(Map<String, Object> filterParams);
	
	public Future<List<AdvisoriesSummary>> getEtaSummary(Map<String, Object> filterParams);

	public Future<Integer> getDsaCount(Map<String, Object> filterParams);

	public Future<Integer> getDtaCount(Map<String, Object> filterParams);
	
	public void refreshView(String view);
	
}
