package com.emc.dvs.ib.domain;

import com.emc.dvs.export.annotation.ExportDate;

import lombok.Data;

@Data
public class EsrsChangeEventBeanForExport {

	private String updatedBy;
	private String alias;
	@ExportDate(value="MMM d, yyyy HH:mm:ss")
	private Long updatedOn;
	
}

