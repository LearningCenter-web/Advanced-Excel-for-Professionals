package com.emc.dvs.ib.web;

import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emc.dvs.export.domain.ColumnWrapper;
import com.emc.dvs.ib.domain.CodeLevelsAggBean;
import com.emc.dvs.ib.domain.CodeLevelsAggregateResponseBean;
import com.emc.dvs.ib.domain.CodeLevelsCatAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProdFamilyAggBean;
import com.emc.dvs.ib.domain.CodeLevelsProductBean;
import com.emc.dvs.ib.domain.ComponentBean;
import com.emc.dvs.ib.domain.ConnectivityAggResponseBean;
import com.emc.dvs.ib.domain.ConnectivityProductBean;
import com.emc.dvs.ib.domain.ContractCategoryBean;
import com.emc.dvs.ib.domain.ContractCategoryResponseBean;
import com.emc.dvs.ib.domain.ContractInventoryBean;
import com.emc.dvs.ib.domain.ContractTimelineBean;
import com.emc.dvs.ib.domain.InstallBaseFilterValuesBean;
import com.emc.dvs.ib.domain.InstallBaseGeoBean;
import com.emc.dvs.ib.domain.InstallBaseResponseBean;
import com.emc.dvs.ib.domain.InstallBaseStatsBean;
import com.emc.dvs.ib.domain.MilestoneStatsBean;
import com.emc.dvs.ib.domain.Page;
import com.emc.dvs.ib.domain.PagedResponseBean;
import com.emc.dvs.ib.domain.ProductBean;
import com.emc.dvs.ib.domain.SiteBean;
import com.emc.dvs.ib.domain.TimelineEntity;
import com.emc.dvs.ib.domain.WarrantyResponse;
import com.emc.dvs.ib.exception.BadRequestException;
import com.emc.dvs.ib.exception.ResourceNotFoundException;
import com.emc.dvs.ib.service.InstallBaseService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * InstallBaseController
 * 
 * <p>
 * POST method is preferred because the amount of filters that can be passed
 * will trigger a Request URI too long error
 *
 */
@Slf4j
@RestController
@RefreshScope
public class InstallBaseController {
	
	private ObjectMapper mapper = new ObjectMapper();

	private InstallBaseService installBaseService;
	
	/**
	 * turn on/off CPSD filter
	 */
	@Setter
	@Value("${ib.cpsd-filter:true}")
	private boolean cpsdFilter;
	
	@Autowired
	public InstallBaseController(InstallBaseService installBaseService) {
		this.installBaseService = installBaseService;
	}

	/**
	 * Get filter values for a data set
	 * 
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/connectivity/filters" }, method = { RequestMethod.GET, RequestMethod.POST })
	public InstallBaseFilterValuesBean getConnectivtyFilters(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws ExecutionException, InterruptedException {
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		filterParams.putIfAbsent("connectivity", "true");
		return this.getSerialNumbersForSites(filterParams, request);
	}

	/**
	 * Get filter values for a data set
	 * 
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/filters" }, method = { RequestMethod.GET, RequestMethod.POST })
	public InstallBaseFilterValuesBean getSerialNumbersForSites(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException, ExecutionException {
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		Future<InstallBaseFilterValuesBean> filters = installBaseService
				.getInstallBaseFilterValues(new HashMap<String, Object>(filterParams));
		Future<List<String>> productNames = installBaseService
				.getProductNames(new HashMap<String, Object>(filterParams));
		Future<List<String>> contractStatus = installBaseService
				.getContractStatus(new HashMap<String, Object>(filterParams));
		InstallBaseFilterValuesBean filterValues = new InstallBaseFilterValuesBean();

		try {
			while (!(filters.isDone() && productNames.isDone() && contractStatus.isDone())) {
				Thread.sleep(10);
			}
			filterValues = filters.get();
			filterValues.setProductName(productNames.get());
			filterValues.setContractStatus(contractStatus.get());

		} catch (InterruptedException ex) {
			log.error("getFilterValues InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getFilterValues ExecutionException: " + ex.getMessage());
			throw ex;
		}
		return filterValues;
	}
	
	/**
	 * Get the serial numbers to be used in the filter typeahead from the right drawer
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/filters/serialnumber" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<String> getSerialFilterValues(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		return installBaseService.getSerialNumbers(filterParams);
	}
	
	/**
	 * Get the instance numbers to be used in the filter typeahead from the right drawer
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/filters/instancenumber" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<String> getInstanceFilterValues(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		return installBaseService.getInstanceIds(filterParams);
	}
	
	@RequestMapping(value = { "/connectivity/filters/serialnumber" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<String> getConnectivitySerialFilterValues(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParams.putIfAbsent("connectivity", "true");
		return getSerialFilterValues(filterParams, request);
	}
	
	@RequestMapping(value = { "/connectivity/filters/instancenumber" }, method = { RequestMethod.GET, RequestMethod.POST })
	public List<String> getConnectivityInstanceFilterValues(@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		filterParams.putIfAbsent("connectivity", "true");
		return getInstanceFilterValues(filterParams, request);
	}

	/**
	 * <p>
	 * InstallBase Overview
	 * 
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/" }, method = { RequestMethod.GET, RequestMethod.POST })
	public InstallBaseResponseBean getInstallBaseOverview(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException, ExecutionException {
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		InstallBaseResponseBean response = new InstallBaseResponseBean();
		Future<InstallBaseStatsBean> stats = installBaseService.getInstallBaseStats(filterParams);
		Future<List<InstallBaseGeoBean>> geos = installBaseService.getInstallBaseGeoDetails(filterParams);
		try {
			while (!(stats.isDone() && geos.isDone())) {
				Thread.sleep(10);
			}
			response.setStats(stats.get());
			response.setGeo(geos.get());
		} catch (InterruptedException ex) {
			log.error("getInstallBase Interupted Exception: " + ex.getMessage());
			throw ex;
		} catch (ExecutionException e) {
			log.error("getInstallBase Execution Exception: " + e.getMessage());
			throw e;
		}
		return response;
	}

	/**
	 * <p>
	 * Install Base Connectivity
	 * 
	 * @param sites
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/connectivity/aggregate" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ConnectivityAggResponseBean getConnectivityAggregate(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws ExecutionException, InterruptedException {

		ConnectivityAggResponseBean response = new ConnectivityAggResponseBean();
		filterParams.putIfAbsent("connectivity", "true");
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		Future<Map<String, Object>> aggMap = installBaseService.getConnectivityAggregate(filterParams);
		Future<InstallBaseStatsBean> stats = installBaseService.getInstallBaseStats(filterParams);
		

		try {
			while (!(stats.isDone() && aggMap.isDone())) {
				Thread.sleep(10);
			}
			response.setStats(stats.get());
			response.setAggMap(aggMap.get());

		} catch (InterruptedException ex) {
			log.error("getConnectivityAggregate Interupted Exception: " + ex.getMessage());
			throw ex;
		} catch (ExecutionException e) {
			log.error("getConnectivityAggregate Execution Exception: " + e.getMessage());
			throw e;
		}
		return response;
	}

	@RequestMapping(value = { "/connectivity" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<ConnectivityProductBean> getConnectivityList(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) throws InterruptedException, ExecutionException {

		int number = 0;
		int size = 200;
		if (filterParams.containsKey("number")) {
			number = Integer.parseInt((String) filterParams.get("number"));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}
		filterParams.put("number", number);
		filterParams.put("size", size);

		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.putIfAbsent("connectivity", "true");
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		PagedResponseBean<ConnectivityProductBean> response = new PagedResponseBean<ConnectivityProductBean>();
		Future<Integer> totalElements = installBaseService.getConnectivityTotalRecord(filterParams);
		Future<List<ConnectivityProductBean>> list = installBaseService.getConnectivityList(filterParams);

		List<ConnectivityProductBean> listValue = new ArrayList<ConnectivityProductBean>();
		int totalElementsValue;
		try {
			while (!(list.isDone()) && !(totalElements.isDone())) {
				Thread.sleep(10);
			}
			listValue = list.get();
			totalElementsValue = totalElements.get();
		} catch (InterruptedException ex) {
			log.error("getConnectivityProductList InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getConnectivityProductList ExecutionException: " + ex.getMessage());
			throw ex;
		}

		int totalPages = totalElementsValue / size + 1;
		Page page = new Page(size, totalElementsValue, totalPages, number);

		response.setPage(page);
		response.setRows(listValue);
		return response;

	}

	@RequestMapping(value = { "/connectivity" }, method = { RequestMethod.GET,
			RequestMethod.POST }, produces = "text/csv")
	public void downloadConnectivityList(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.putIfAbsent("connectivity", "true");
		filterParams.putIfAbsent("tzUTCOffset", 0);
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);

		response.addHeader("Content-disposition", "attachment;filename=Connectivity_Export.csv");
		response.setContentType("txt/csv");
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getConnectivityList(out, filterParams, colWrapper.getColumns());
		}

	}

	/**
	 * <p>
	 * Install Base Code Levels
	 * 
	 * @param sites
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/codelevels/aggregate" }, method = { RequestMethod.GET, RequestMethod.POST })
	public CodeLevelsAggregateResponseBean getCodeLevelsAggregateForSites(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) {
		CodeLevelsAggregateResponseBean response = new CodeLevelsAggregateResponseBean();
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		List<CodeLevelsAggBean> agg = installBaseService.getCodeLevelsAggregate(filterParams);
		int total = agg.stream().mapToInt(a -> a.getSystems()).sum();

		agg.stream().forEach(a -> {
			CodeLevelsCatAggBean catAggBean = response.getCategories().get(a.getCategory());

			if (catAggBean == null) {
				catAggBean = new CodeLevelsCatAggBean();
				response.getCategories().put(a.getCategory(), catAggBean);
			}

			catAggBean.setTotalSystems(catAggBean.getTotalSystems() + a.getSystems());
			CodeLevelsProdFamilyAggBean prdFamilyAgg = new CodeLevelsProdFamilyAggBean();
			prdFamilyAgg.setFamilyName(a.getProductFamily());
			prdFamilyAgg.setCodeReleases(a.getCodeReleases());
			prdFamilyAgg.setTotalSystems(a.getSystems());
			catAggBean.getProductFamilies().add(prdFamilyAgg);

		});

		response.setTotal(total);
		return response;
	}

	/**
	 * <p>
	 * Get Install Base Code Levels by sites
	 * 
	 * @param sites
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/codelevels" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<CodeLevelsProductBean> getCodeLevelProductsForSites(
			@RequestParam Map<String, Object> filterParams, HttpServletRequest request) throws InterruptedException, ExecutionException {

		int number = 0;
		int size = 5000;
		if (filterParams.containsKey("number")) {
			number = Integer.parseInt((String) filterParams.get("number"));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}
		filterParams.put("number", number);
		filterParams.put("size", size);

		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		PagedResponseBean<CodeLevelsProductBean> response = new PagedResponseBean<CodeLevelsProductBean>();
		Future<Integer> totalElements = installBaseService.getCodeLevelsTotalRecord(filterParams);
		Future<List<CodeLevelsProductBean>> table = installBaseService.getCodeLevelsProducts(filterParams);

		List<CodeLevelsProductBean> tableValue = new ArrayList<CodeLevelsProductBean>();
		int totalElementsValue;
		try {
			while (!(table.isDone()) && !(totalElements.isDone())) {
				Thread.sleep(10);
			}
			tableValue = table.get();
			totalElementsValue = totalElements.get();
		} catch (InterruptedException ex) {
			log.error("getCodeLevelsTable InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getCodeLevelsTable ExecutionException: " + ex.getMessage());
			throw ex;
		}

		int totalPages = totalElementsValue / size + 1;
		Page page = new Page(size, totalElementsValue, totalPages, number);

		response.setPage(page);
		response.setRows(tableValue);
		return response;

	}

	@RequestMapping(value = { "/codelevels" }, method = { RequestMethod.GET,
			RequestMethod.POST }, produces = "text/csv")
	public void downloadCodeLevelProducts(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.putIfAbsent("tzUTCOffset", 0);
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);

		response.addHeader("Content-disposition", "attachment;filename=CodeLevelProducts_Export.csv");
		response.setContentType("txt/csv");
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getCodeLevelsProducts(out, filterParams, colWrapper.getColumns());
		}

	}

	/**
	 * <p>
	 * Install Base Contract
	 * 
	 * @param sites
	 * @param filterParams
	 * @return
	 */
	@RequestMapping(value = { "/contract/categories" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ContractCategoryResponseBean getContractCategories(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) {
		ContractCategoryResponseBean response = new ContractCategoryResponseBean();
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}
		List<ContractCategoryBean> categories = installBaseService.getContractCategoryAggregate(filterParams);
		

		Map<String, Long> contractCategories = new HashMap<String, Long>();
		Map<String, Map<String, Long>> contractProductFamilies = new HashMap<String, Map<String, Long>>();
		categories.stream().forEach(c -> {
			getContractCategoryAggregate(c.getContractExpiresCategory(), contractCategories);

			String productFamily = c.getProductFamily();
			if (contractProductFamilies.get(productFamily) == null)
				contractProductFamilies.put(productFamily, new HashMap<String, Long>());
			getContractCategoryAggregate(c.getContractExpiresCategory(), contractProductFamilies.get(productFamily));
		});

		response.setContractCategories(contractCategories);
		response.setContractProductFamilies(contractProductFamilies);
		return response;
	}

	private void getContractCategoryAggregate(String contractExpiresCategory, Map<String, Long> contractCategories) {
		if (contractCategories.get(contractExpiresCategory) != null)
			contractCategories.put(contractExpiresCategory, contractCategories.get(contractExpiresCategory) + 1);
		else
			contractCategories.put(contractExpiresCategory, new Long(1));
	}

	/**
	 * 
	 */
	@RequestMapping(value = { "/contract/timeline" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<ContractTimelineBean> getContractTimeline(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException, ExecutionException {

		int number = 0;
		int size = 200;
		if (filterParams.containsKey("number")) {
			number = Integer.parseInt((String) filterParams.get("number"));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}
		filterParams.put("number", number);
		filterParams.put("size", size);
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		PagedResponseBean<ContractTimelineBean> response = new PagedResponseBean<ContractTimelineBean>();
		Future<Integer> totalElements = installBaseService.getContractTimelineTotal(filterParams);
		Future<List<ContractTimelineBean>> list = installBaseService.getContractTimeline(filterParams);

		List<ContractTimelineBean> listValue = new ArrayList<ContractTimelineBean>();
		int totalElementsValue;
		try {
			while (!(list.isDone()) && !(totalElements.isDone())) {
				Thread.sleep(10);
			}
			listValue = list.get();
			totalElementsValue = totalElements.get();
		} catch (InterruptedException ex) {
			log.error("getContractTimeline InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getContractTimeline ExecutionException: " + ex.getMessage());
			throw ex;
		}

		int totalPages = totalElementsValue / size + 1;
		Page page = new Page(size, totalElementsValue, totalPages, number);

		response.setPage(page);
		response.setRows(listValue);
		return response;

	}

	/**
	 * 
	 */
	@RequestMapping(value = { "/contract" }, method = { RequestMethod.GET, RequestMethod.POST })
	public PagedResponseBean<ContractInventoryBean> getContractInventory(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException, ExecutionException {

		int number = 0;
		int size = 200;
		if (filterParams.containsKey("number")) {
			number = Integer.parseInt((String) filterParams.get("number"));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}
		filterParams.put("number", number);
		filterParams.put("size", size);

		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		PagedResponseBean<ContractInventoryBean> response = new PagedResponseBean<ContractInventoryBean>();
		Future<Integer> totalElements = installBaseService.getContractInventoryTotal(filterParams);
		Future<List<ContractInventoryBean>> inventory = installBaseService.getContractInventory(filterParams);

		List<ContractInventoryBean> inventoryValue = new ArrayList<ContractInventoryBean>();
		int totalElementsValue;
		try {
			while (!(inventory.isDone()) && !(totalElements.isDone())) {
				Thread.sleep(10);
			}
			inventoryValue = inventory.get();
			totalElementsValue = totalElements.get();
		} catch (InterruptedException ex) {
			log.error("getContractInventory InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getContractInventory ExecutionException: " + ex.getMessage());
			throw ex;
		}

		int totalPages = totalElementsValue / size + 1;
		Page page = new Page(size, totalElementsValue, totalPages, number);

		response.setPage(page);
		response.setRows(inventoryValue);
		return response;

	}

	@RequestMapping(value = { "/contract" }, method = { RequestMethod.GET, RequestMethod.POST }, produces = "text/csv")
	public void downloadContractInventory(@RequestParam Map<String, Object> filterParams, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.putIfAbsent("tzUTCOffset", 0);
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);

		response.addHeader("Content-disposition", "attachment;filename=ContractInventory_Export.csv");
		response.setContentType("txt/csv");
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getContractInventory(out, filterParams, colWrapper.getColumns());
		}
	}

	@RequestMapping(value = "/product/{serialNumber}", method = RequestMethod.GET)
	public ProductBean getProductDetail(@RequestParam Map<String, Object> filterParams,
			@PathVariable String serialNumber, HttpServletRequest request) {
		log.debug("Get product data for serial number: {}", serialNumber);
		
		filterParams.put("serialNumberIsIn", serialNumber);
		//Sorting IB records by installDate to get the latest IB instance in case there are duplicate records for a single serial number 
		filterParams.put("sortBy", "installDate");
		filterParams.put("sortDir", "desc NULLS LAST");
		filterParams.put("multipleRecordsCheck", "true");
		ProductBean product = installBaseService.getProductDetail(filterParams);
		if (null == product) {
			throw new ResourceNotFoundException();
		}
		return product;
	}
	
	@RequestMapping(value = "/productfamily/{productFamily}", method = RequestMethod.GET)
	public Long getConnectHomeStatusDuration(@PathVariable String productFamily) {
		log.debug("Get product data for productFamily: {}", productFamily);
		
		Long duration = installBaseService.getConnectHomeStatusDuration(productFamily);
		
		return duration;
	}
	
	@RequestMapping(value="/product/{serialNumber}/components", method={RequestMethod.GET,RequestMethod.POST})
	public List<ComponentBean> getSolutionComponents(@RequestParam Map<String, Object> filterParams, 
			@PathVariable String serialNumber, HttpServletRequest request) {
		serialNumber = serialNumber.toUpperCase();
		log.debug("Get solution components for serial number: {}", serialNumber);
		String sortBy = filterParams.getOrDefault("sortBy", "").toString();
		if ("componentSerialNumber".equals(sortBy)){
			filterParams.put("sortBy","serialNumber");
		}
		if(filterParams.containsKey("searchIsLike")) {
			String searchIsLike = (String) filterParams.get("searchIsLike");
			filterParams.put("searchIsLike", searchIsLike.replaceAll("_", "\\\\_"));
		}
		filterParams.put("cpsdSerialNumber", serialNumber);
		return installBaseService.getSolutionComponents(filterParams);
		
	}
	
	
	@RequestMapping(value="/product/{serialNumber}/components", method={RequestMethod.GET,RequestMethod.POST} ,produces = "text/csv")
	public void getSolutionComponents(@RequestParam Map<String, Object> filterParams, 
			@PathVariable String serialNumber, HttpServletRequest request,HttpServletResponse response) throws Exception{
		serialNumber = serialNumber.toUpperCase();
		log.debug("Get solution components for serial number: {}", serialNumber);
		String sortBy = filterParams.getOrDefault("sortBy", "").toString();
		if ("componentSerialNumber".equals(sortBy)){
			filterParams.put("sortBy","serialNumber");
		}
		filterParams.put("cpsdSerialNumber", serialNumber);
		String columns = (String) filterParams.get("columns");
		response.addHeader("Content-disposition", "attachment;filename=Components_Export.csv");
		response.setContentType("txt/csv");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getSolutionComponents(out, filterParams, colWrapper.getColumns());
		}
	}
	
	/**
	 * This method returns the count of milestones filters count to be displayed in Timeline panel
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/milestonestats", method = RequestMethod.POST)
	public MilestoneStatsBean getMilestoneStats(@RequestParam Map<String, Object> filterParams) {
		return installBaseService.getMilestoneStats(filterParams);
	}

	/**
	 * This method returns the list of products to be displayed in Install Base
	 * Overview grid
	 * 
	 * @param filterParams
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public PagedResponseBean<ProductBean> getInstallBaseOverviewGrid(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request) throws InterruptedException, ExecutionException {
		int number = 0;
		int size = 200;

		if (filterParams.containsKey("number")) {
			number = Integer.parseInt((String) filterParams.get("number"));
		}
		if (filterParams.containsKey("size")) {
			size = Integer.parseInt((String) filterParams.get("size"));
		}
		filterParams.put("number", number);
		filterParams.put("size", size);

		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");

		if (filterParams.get("sortBy").equals("connectionAge")) {
			filterParams.put("sortBy", "lastConnectHome");
		}
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		PagedResponseBean<ProductBean> response = new PagedResponseBean<ProductBean>();
		Future<Integer> totalElements = installBaseService.getProductsTotal(filterParams);
		Future<List<ProductBean>> productList = installBaseService.getProducts(filterParams);

		List<ProductBean> productsValue = new ArrayList<ProductBean>();
		int totalElementsValue;
		try {
			productsValue = productList.get();
			totalElementsValue = totalElements.get();
		} catch (InterruptedException ex) {
			log.error("getInstallBaseOverviewGrid InterruptedException : " + ex.getMessage());
			throw ex;
		} catch (ExecutionException ex) {
			log.error("getInstallBaseOverviewGrid ExecutionException: " + ex.getMessage());
			throw ex;
		}
		int totalPages = totalElementsValue / size + 1;
		Page page = new Page(size, totalElementsValue, totalPages, number);

		response.setPage(page);
		response.setRows(productsValue);
		return response;
	}

	@RequestMapping(value = { "/products" }, method = { RequestMethod.GET, RequestMethod.POST }, produces = "text/csv")
	public void downloadInstallBaseOverviewGrid(@RequestParam Map<String, Object> filterParams,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		filterParams.putIfAbsent("sortBy", "siteDisplayName");
		filterParams.putIfAbsent("sortDir", "desc");
		filterParams.putIfAbsent("tzUTCOffset", 0);
		if (cpsdFilter){
			filterParams.put("cpsdFilter", "false");
		}

		if (filterParams.get("sortBy").equals("connectionAge")) {
			filterParams.put("sortBy", "lastConnectHome");
		}

		String columns = (String) filterParams.get("columns");
		ColumnWrapper colWrapper = (ColumnWrapper) mapper.readValue(columns, ColumnWrapper.class);

		response.addHeader("Content-disposition", "attachment;filename=Installbase_Overview_Export.csv");
		response.setContentType("txt/csv");
		try (OutputStream out = response.getOutputStream();) {
			installBaseService.getProducts(out, filterParams, colWrapper.getColumns());
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = {"/product/{serialNumber}/timeline"}, method = {RequestMethod.GET, RequestMethod.POST})
	public List<TimelineEntity> getTimelineData(@RequestParam Map<String, Object> filterParams,
			@PathVariable String serialNumber, HttpServletRequest request){
		
		filterParams.put("size", Integer.parseInt(filterParams.getOrDefault("size", "50").toString()));
		String filterBy = filterParams.getOrDefault("filterBy", "All").toString();
		Boolean advancedTimelineFilters = Boolean.parseBoolean(filterParams.getOrDefault("advancedTimelineFilters", "false").toString());
		
		Long tlvTimeRangeBefore = Long.parseLong(filterParams.getOrDefault("tlvTimeRangeBefore", 0).toString());
		Long tlvTimeRangeAfter = Long.parseLong(filterParams.getOrDefault("tlvTimeRangeAfter", 0).toString());
	
		ProductBean pb = this.getProductDetail(filterParams, serialNumber, request);
		
		List<TimelineEntity> timelineEntities = new ArrayList<>();		
		TimelineEntity today = new TimelineEntity();
		today.setEntityType("TODAY");
		//Setting today's timestamp to 11:59:59 PM for that particular date
		//so that the value will be same for each API call
		today.setTimeStamp(getMaxTimeStampToday(Integer.parseInt(filterParams.getOrDefault("tzUTCOffset", "0").toString())));
		Map<String,Object> todayMap = new HashMap<>();
		todayMap.put("lastConnectHome", pb.getLastConnectHome());
		todayMap.put("servicePlanLevel",pb.getServicePlanLevel());
		todayMap.put("contractEndDate", pb.getContractEndDate());
		todayMap.put("contractRenewalDate",pb.getContractRenewalDate());
		todayMap.put("connectFlag", pb.getConnectFlag());
		today.setEntity(todayMap);
		
		timelineEntities.add(today);
		
		//Added advancedTimelineFilters check to always return milestones data for old filters
		//The filterBy condition should only be applied for advanced filters
		if (pb.getEops() != null
				&& (!advancedTimelineFilters || filterBy.contains("eossDate") || filterBy.contains("All"))
				&& ((pb.getEops() >= tlvTimeRangeAfter && pb.getEops() <= tlvTimeRangeBefore)
				|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0))) {
			TimelineEntity eoss = new TimelineEntity();
			eoss.setEntityType("EOSS");
			eoss.setTimeStamp(pb.getEops());
			timelineEntities.add(eoss);
		}
		
		if (pb.getShipDate() != null
				&& (!advancedTimelineFilters || filterBy.contains("shipDate") || filterBy.contains("All"))
				&& ((pb.getShipDate() >= tlvTimeRangeAfter && pb.getShipDate() <= tlvTimeRangeBefore)
				|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0))) {
			TimelineEntity shipDate = new TimelineEntity();
			shipDate.setEntityType("SHIP_DATE");
			shipDate.setTimeStamp(pb.getShipDate());
			timelineEntities.add(shipDate);
		}
		
		if (pb.getPurchaseDate() != null
				&& (!advancedTimelineFilters || filterBy.contains("purchaseDate") || filterBy.contains("All"))
				&& ((pb.getPurchaseDate() >= tlvTimeRangeAfter && pb.getPurchaseDate() <= tlvTimeRangeBefore)
				|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0))) {
			TimelineEntity purchaseDate = new TimelineEntity();
			purchaseDate.setEntityType("PURCHASE_DATE");
			purchaseDate.setTimeStamp(pb.getPurchaseDate());
			timelineEntities.add(purchaseDate);
		}
				
		if (pb.getContractEndDate() != null
				&& (!advancedTimelineFilters || filterBy.contains("contractEndDate") || filterBy.contains("All"))
				&& ((pb.getContractEndDate() >= tlvTimeRangeAfter && pb.getContractEndDate() <= tlvTimeRangeBefore)
				|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0))){
			TimelineEntity contractEnd = new TimelineEntity();
			contractEnd.setEntityType("CONTRACT_END");
			contractEnd.setTimeStamp(pb.getContractEndDate());
			timelineEntities.add(contractEnd);
		}
		
		try{
			if (pb.getInstallDate() != null
					&& (!advancedTimelineFilters || filterBy.contains("installDate") || filterBy.contains("All"))
					&& ((Long.parseLong(pb.getInstallDate()) >= tlvTimeRangeAfter
							&& Long.parseLong(pb.getInstallDate()) <= tlvTimeRangeBefore)
					|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0))) {
				TimelineEntity installDate = new TimelineEntity();
				installDate.setEntityType("INSTALL_DATE");
				installDate.setTimeStamp(Long.parseLong(pb.getInstallDate()));
				timelineEntities.add(installDate);
			}
		}catch (Exception e){
			log.error("Invalid install date {}", pb.getInstallDate());
		}		
		
		//Add product change events
		Map<String, Object> changeEvents = installBaseService.getProductChangeEvent(Long.parseLong(pb.getInstanceNumber()));
		if(changeEvents != null && changeEvents.containsKey("locationChange") 
			    && (!advancedTimelineFilters || filterBy.contains("locationChange") || filterBy.contains("All"))) {
			List<Map<String, Object>> locationChanges = (List<Map<String, Object>>) changeEvents.get("locationChange");
			locationChanges.stream()
					.filter(lc -> ((Long.parseLong(lc.get("requestDate").toString()) >= tlvTimeRangeAfter
							&& Long.parseLong(lc.get("requestDate").toString()) <= tlvTimeRangeBefore)
							|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0)))
					.forEach(lc -> {
						TimelineEntity location = new TimelineEntity();
						location.setEntityType("LOCATION_CHANGE");
						location.setTimeStamp(Long.parseLong(lc.get("requestDate").toString()));
						location.setEntity(lc);
						timelineEntities.add(location);
					});
		}
		if(changeEvents != null && changeEvents.containsKey("contractRenewal") 
				&& (!advancedTimelineFilters || filterBy.contains("contractRenewal") || filterBy.contains("All"))) {
			List<Map<String, Object>>  contractRenewals = (List<Map<String, Object>>) changeEvents.get("contractRenewal");
			contractRenewals.stream()
					.filter(cr -> ((Long.parseLong(cr.get("contractSubmissionDate").toString()) >= tlvTimeRangeAfter
							&& Long.parseLong(cr.get("contractSubmissionDate").toString()) <= tlvTimeRangeBefore)
							|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0)))
					.forEach(cr -> {
						TimelineEntity contract = new TimelineEntity();
						contract.setEntityType("CONTRACT_RENEWAL");
						contract.setTimeStamp(Long.parseLong(cr.get("contractSubmissionDate").toString()));
						contract.setEntity(cr);
						timelineEntities.add(contract);
					});
		}
		if(changeEvents != null && changeEvents.containsKey("aliasChange") 
				&& (!advancedTimelineFilters || filterBy.contains("aliasChange") || filterBy.contains("All"))) {
			List<Map<String, Object>>  aliasChange = (List<Map<String, Object>>) changeEvents.get("aliasChange");
			aliasChange.stream()
					.filter(al -> ((Long.parseLong(al.get("updateDate").toString()) >= tlvTimeRangeAfter
							&& Long.parseLong(al.get("updateDate").toString()) <= tlvTimeRangeBefore)
							|| (tlvTimeRangeAfter == 0 && tlvTimeRangeBefore == 0)))
					.forEach(al -> {
						TimelineEntity alias = new TimelineEntity();
						alias.setEntityType("ALIAS_CHANGE");
						alias.setTimeStamp(Long.parseLong(al.get("updateDate").toString()));
						alias.setEntity(al);
						timelineEntities.add(alias);
					});
		}
		
		return timelineEntities;
	}
	
	/**
	 * This method returns the time at 11:59:59 PM today in milliseconds for user's time zone
	 * @return
	 */
	private Long getMaxTimeStampToday(int tzUTCOffset) {
		LocalDate tomorrow = LocalDate.now(ZoneId.ofOffset("UTC", ZoneOffset.ofTotalSeconds(tzUTCOffset * 60))).plus(1, ChronoUnit.DAYS);
		LocalTime midnight = LocalTime.MIDNIGHT;
		ZonedDateTime zonedDateTime = ZonedDateTime.of(tomorrow, midnight, ZoneId.ofOffset("UTC", ZoneOffset.ofTotalSeconds(tzUTCOffset * 60)));
		return zonedDateTime.toInstant().toEpochMilli() - 1L;
	}
	
	
	
	@RequestMapping(value={"/milestones/timeline/timerange"}, method=RequestMethod.POST)
	public Map<Long, Integer> getMilestonesTimelineRangeEventCount(@RequestParam Map<String, Object> filterParams) {
		return installBaseService.getMilestonesTimelineRangeEventCount(filterParams);
	}
	
	@RequestMapping(value={"/sites"},method = { RequestMethod.GET, RequestMethod.POST })
	public List<SiteBean> getSiteDetails(@RequestParam Map<String, Object> filterParams) {
		if(filterParams.containsKey("ucidIsIn") || filterParams.containsKey("siteNumberIsIn")) {
			return installBaseService.getSiteDetails(filterParams);	
		} else {
			throw new BadRequestException("invalid");
		}
	}
	
	@RequestMapping(value={"/warranties/{serialNumber}"},method = { RequestMethod.GET })
	public WarrantyResponse getWarranties(@PathVariable String serialNumber) {
		return installBaseService.getWarranties(serialNumber);
	}
	
	
}
